package T;

import android.util.Log;
import java.util.Locale;

public abstract class s {

    /* renamed from: a  reason: collision with root package name */
    public static final boolean f210a = Log.isLoggable("Volley", 2);
    public static final String b = s.class.getName();

    public static String a(String str, Object... objArr) {
        String str2;
        String format = String.format(Locale.US, str, objArr);
        StackTraceElement[] stackTrace = new Throwable().fillInStackTrace().getStackTrace();
        int i2 = 2;
        while (true) {
            if (i2 >= stackTrace.length) {
                str2 = "<unknown>";
                break;
            } else if (!stackTrace[i2].getClassName().equals(b)) {
                String className = stackTrace[i2].getClassName();
                String substring = className.substring(className.lastIndexOf(46) + 1);
                str2 = substring.substring(substring.lastIndexOf(36) + 1) + "." + stackTrace[i2].getMethodName();
                break;
            } else {
                i2++;
            }
        }
        Locale locale = Locale.US;
        return "[" + Thread.currentThread().getId() + "] " + str2 + ": " + format;
    }

    public static void b(String str, Object... objArr) {
        Log.d("Volley", a(str, objArr));
    }

    public static void c(String str, Object... objArr) {
        Log.e("Volley", a(str, objArr));
    }

    public static void d(String str, Object... objArr) {
        if (f210a) {
            Log.v("Volley", a(str, objArr));
        }
    }
}
