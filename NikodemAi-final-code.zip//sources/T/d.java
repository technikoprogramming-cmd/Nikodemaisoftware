package T;

import C.j;
import U.e;
import U.h;
import android.os.Process;
import java.util.concurrent.PriorityBlockingQueue;

public final class d extends Thread {

    /* renamed from: g  reason: collision with root package name */
    public static final boolean f177g = s.f210a;

    /* renamed from: a  reason: collision with root package name */
    public final PriorityBlockingQueue f178a;
    public final PriorityBlockingQueue b;

    /* renamed from: c  reason: collision with root package name */
    public final e f179c;

    /* renamed from: d  reason: collision with root package name */
    public final j f180d;

    /* renamed from: e  reason: collision with root package name */
    public volatile boolean f181e = false;
    public final t f;

    public d(PriorityBlockingQueue priorityBlockingQueue, PriorityBlockingQueue priorityBlockingQueue2, e eVar, j jVar) {
        this.f178a = priorityBlockingQueue;
        this.b = priorityBlockingQueue2;
        this.f179c = eVar;
        this.f180d = jVar;
        this.f = new t(this, priorityBlockingQueue2, jVar);
    }

    private void a() {
        boolean z2;
        h hVar = (h) this.f178a.take();
        hVar.a("cache-queue-take");
        hVar.j();
        try {
            synchronized (hVar.f233e) {
            }
            b a2 = this.f179c.a(hVar.d());
            if (a2 == null) {
                hVar.a("cache-miss");
                if (!this.f.e(hVar)) {
                    this.b.put(hVar);
                }
                hVar.j();
                return;
            }
            long currentTimeMillis = System.currentTimeMillis();
            boolean z3 = false;
            if (a2.f172e < currentTimeMillis) {
                z2 = true;
            } else {
                z2 = false;
            }
            if (z2) {
                hVar.a("cache-hit-expired");
                hVar.f239l = a2;
                if (!this.f.e(hVar)) {
                    this.b.put(hVar);
                }
                hVar.j();
                return;
            }
            hVar.a("cache-hit");
            k i2 = h.i(new k(a2.f169a, a2.f173g));
            hVar.a("cache-hit-parsed");
            if (((p) i2.f194d) == null) {
                z3 = true;
            }
            if (!z3) {
                hVar.a("cache-parsing-failed");
                e eVar = this.f179c;
                String d2 = hVar.d();
                synchronized (eVar) {
                    b a3 = eVar.a(d2);
                    if (a3 != null) {
                        a3.f = 0;
                        a3.f172e = 0;
                        eVar.f(d2, a3);
                    }
                }
                hVar.f239l = null;
                if (!this.f.e(hVar)) {
                    this.b.put(hVar);
                }
                hVar.j();
                return;
            }
            if (a2.f < currentTimeMillis) {
                hVar.a("cache-hit-refresh-needed");
                hVar.f239l = a2;
                i2.f192a = true;
                if (!this.f.e(hVar)) {
                    this.f180d.y(hVar, i2, new c(this, hVar));
                } else {
                    this.f180d.y(hVar, i2, (c) null);
                }
            } else {
                this.f180d.y(hVar, i2, (c) null);
            }
            hVar.j();
        } catch (Throwable th) {
            hVar.j();
            throw th;
        }
    }

    public final void run() {
        if (f177g) {
            s.d("start new dispatcher", new Object[0]);
        }
        Process.setThreadPriority(10);
        this.f179c.d();
        while (true) {
            try {
                a();
            } catch (InterruptedException unused) {
                if (this.f181e) {
                    Thread.currentThread().interrupt();
                    return;
                }
                s.c("Ignoring spurious interrupt of CacheDispatcher thread; use quit() to terminate it", new Object[0]);
            }
        }
    }
}
