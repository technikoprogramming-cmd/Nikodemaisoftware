package T;

import G.a;
import U.e;
import U.h;
import android.net.TrafficStats;
import android.os.Process;
import android.os.SystemClock;
import android.util.Log;
import java.util.concurrent.PriorityBlockingQueue;

public final class j extends Thread {

    /* renamed from: a  reason: collision with root package name */
    public final PriorityBlockingQueue f188a;
    public final a b;

    /* renamed from: c  reason: collision with root package name */
    public final e f189c;

    /* renamed from: d  reason: collision with root package name */
    public final C.j f190d;

    /* renamed from: e  reason: collision with root package name */
    public volatile boolean f191e = false;

    public j(PriorityBlockingQueue priorityBlockingQueue, a aVar, e eVar, C.j jVar) {
        this.f188a = priorityBlockingQueue;
        this.b = aVar;
        this.f189c = eVar;
        this.f190d = jVar;
    }

    /* JADX WARNING: type inference failed for: r4v4, types: [T.p, java.lang.Exception] */
    private void a() {
        b bVar;
        h hVar = (h) this.f188a.take();
        C.j jVar = this.f190d;
        SystemClock.elapsedRealtime();
        hVar.j();
        try {
            hVar.a("network-queue-take");
            synchronized (hVar.f233e) {
            }
            TrafficStats.setThreadStatsTag(hVar.f232d);
            k f = this.b.f(hVar);
            hVar.a("network-http-complete");
            if (!f.f192a || !hVar.f()) {
                k i2 = h.i(f);
                hVar.a("network-parse-complete");
                if (hVar.f236i && (bVar = (b) i2.f193c) != null) {
                    this.f189c.f(hVar.d(), bVar);
                    hVar.a("network-cache-written");
                }
                synchronized (hVar.f233e) {
                    hVar.f237j = true;
                }
                jVar.y(hVar, i2, (c) null);
                hVar.h(i2);
                hVar.j();
                return;
            }
            hVar.b("not-modified");
            hVar.g();
            hVar.j();
        } catch (p e2) {
            SystemClock.elapsedRealtime();
            jVar.getClass();
            hVar.a("post-error");
            ((g) jVar.b).execute(new h(hVar, new k(e2), (c) null));
            hVar.g();
            hVar.j();
        } catch (Exception e3) {
            Log.e("Volley", s.a("Unhandled exception %s", e3.toString()), e3);
            ? exc = new Exception(e3);
            SystemClock.elapsedRealtime();
            jVar.getClass();
            hVar.a("post-error");
            ((g) jVar.b).execute(new h(hVar, new k(exc), (c) null));
            hVar.g();
            hVar.j();
        } catch (Throwable th) {
            hVar.j();
            throw th;
        }
    }

    public final void run() {
        Process.setThreadPriority(10);
        while (true) {
            try {
                a();
            } catch (InterruptedException unused) {
                if (this.f191e) {
                    Thread.currentThread().interrupt();
                    return;
                }
                s.c("Ignoring spurious interrupt of NetworkDispatcher thread; use quit() to terminate it", new Object[0]);
            }
        }
    }
}
