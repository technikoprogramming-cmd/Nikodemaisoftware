package T;

import android.os.Handler;
import java.util.concurrent.Executor;

public final class g implements Executor {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ Handler f183a;

    public g(Handler handler) {
        this.f183a = handler;
    }

    public final void execute(Runnable runnable) {
        this.f183a.post(runnable);
    }
}
