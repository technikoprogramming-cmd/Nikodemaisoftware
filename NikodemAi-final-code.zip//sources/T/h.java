package T;

import C.j;
import F.d;
import V.g;
import android.os.Handler;
import android.util.Log;
import v.C0137c;
import v.C0138d;

public final class h implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f184a = 2;
    public Object b;

    /* renamed from: c  reason: collision with root package name */
    public Object f185c;

    /* renamed from: d  reason: collision with root package name */
    public Object f186d;

    public /* synthetic */ h() {
    }

    public final void run() {
        d dVar;
        o oVar;
        Object obj;
        switch (this.f184a) {
            case 0:
                synchronized (((U.h) this.b).f233e) {
                }
                k kVar = (k) this.f185c;
                p pVar = (p) kVar.f194d;
                if (pVar != null) {
                    U.h hVar = (U.h) this.b;
                    synchronized (hVar.f233e) {
                        dVar = hVar.f;
                    }
                    if (dVar != null) {
                        switch (dVar.f56a) {
                            case 9:
                                Log.d("Error Get JSON", "Error:" + pVar.toString());
                                break;
                            case 11:
                                Log.d("Error click", "Error:" + pVar.toString());
                                break;
                            case 12:
                                Log.d("Error Get JSON", "Error:" + pVar.toString());
                                break;
                            default:
                                Log.d("Error Get JSON", "Error:" + pVar.toString());
                                break;
                        }
                    }
                } else {
                    U.h hVar2 = (U.h) this.b;
                    String str = (String) kVar.b;
                    hVar2.getClass();
                    synchronized (hVar2.f241n) {
                        oVar = hVar2.f242o;
                    }
                    if (oVar != null) {
                        oVar.u(str);
                    }
                }
                if (((k) this.f185c).f192a) {
                    ((U.h) this.b).a("intermediate-response");
                } else {
                    ((U.h) this.b).b("done");
                }
                c cVar = (c) this.f186d;
                if (cVar != null) {
                    cVar.run();
                    return;
                }
                return;
            case 1:
                g gVar = (g) this.f186d;
                if (!gVar.f256e) {
                    gVar.f269s = Boolean.FALSE;
                    if (!gVar.f259i.equals("false")) {
                        D.g.C(gVar.b).a(new U.h(0, (String) this.b, new j(7, (Object) this), new d(12)));
                    }
                } else {
                    gVar.f254c = gVar.f;
                    gVar.f256e = false;
                }
                gVar.f255d.postDelayed(this, (long) gVar.f254c);
                if (gVar.f254c == gVar.f) {
                    gVar.f254c = gVar.f257g;
                    return;
                }
                return;
            default:
                try {
                    obj = ((C0137c) this.b).call();
                } catch (Exception unused) {
                    obj = null;
                }
                ((Handler) this.f186d).post(new c((C0138d) this.f185c, 5, obj));
                return;
        }
    }

    public h(U.h hVar, k kVar, c cVar) {
        this.b = hVar;
        this.f185c = kVar;
        this.f186d = cVar;
    }

    public h(g gVar, String str) {
        this.f186d = gVar;
        this.b = str;
    }
}
