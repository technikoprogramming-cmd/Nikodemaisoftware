package T;

public interface o {
    void u(String str);
}
