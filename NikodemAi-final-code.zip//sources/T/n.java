package T;

import C.j;
import G.a;
import U.e;
import U.h;
import android.os.Handler;
import android.os.Looper;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.atomic.AtomicInteger;

public final class n {

    /* renamed from: a  reason: collision with root package name */
    public final AtomicInteger f197a = new AtomicInteger();
    public final HashSet b = new HashSet();

    /* renamed from: c  reason: collision with root package name */
    public final PriorityBlockingQueue f198c = new PriorityBlockingQueue();

    /* renamed from: d  reason: collision with root package name */
    public final PriorityBlockingQueue f199d = new PriorityBlockingQueue();

    /* renamed from: e  reason: collision with root package name */
    public final e f200e;
    public final a f;

    /* renamed from: g  reason: collision with root package name */
    public final j f201g;

    /* renamed from: h  reason: collision with root package name */
    public final j[] f202h;

    /* renamed from: i  reason: collision with root package name */
    public d f203i;

    /* renamed from: j  reason: collision with root package name */
    public final ArrayList f204j = new ArrayList();

    /* renamed from: k  reason: collision with root package name */
    public final ArrayList f205k = new ArrayList();

    public n(e eVar, a aVar) {
        j jVar = new j(new Handler(Looper.getMainLooper()));
        this.f200e = eVar;
        this.f = aVar;
        this.f202h = new j[4];
        this.f201g = jVar;
    }

    public final void a(h hVar) {
        hVar.f235h = this;
        synchronized (this.b) {
            this.b.add(hVar);
        }
        hVar.f234g = Integer.valueOf(this.f197a.incrementAndGet());
        hVar.a("add-to-queue");
        b();
        if (!hVar.f236i) {
            this.f199d.add(hVar);
        } else {
            this.f198c.add(hVar);
        }
    }

    public final void b() {
        synchronized (this.f205k) {
            try {
                Iterator it = this.f205k.iterator();
                if (it.hasNext()) {
                    if (it.next() == null) {
                        throw null;
                    }
                    throw new ClassCastException();
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }
}
