package T;

import java.util.Collections;
import java.util.List;
import java.util.Map;

public final class b {

    /* renamed from: a  reason: collision with root package name */
    public byte[] f169a;
    public String b;

    /* renamed from: c  reason: collision with root package name */
    public long f170c;

    /* renamed from: d  reason: collision with root package name */
    public long f171d;

    /* renamed from: e  reason: collision with root package name */
    public long f172e;
    public long f;

    /* renamed from: g  reason: collision with root package name */
    public Map f173g = Collections.EMPTY_MAP;

    /* renamed from: h  reason: collision with root package name */
    public List f174h;
}
