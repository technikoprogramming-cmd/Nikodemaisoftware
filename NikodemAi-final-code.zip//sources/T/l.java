package T;

public final class l extends a {
}
