package T;

public final class f {

    /* renamed from: a  reason: collision with root package name */
    public int f182a;
    public int b;
}
