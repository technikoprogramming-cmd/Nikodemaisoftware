package T;

public final class q {

    /* renamed from: a  reason: collision with root package name */
    public final String f206a;
    public final long b;

    /* renamed from: c  reason: collision with root package name */
    public final long f207c;

    public q(String str, long j2, long j3) {
        this.f206a = str;
        this.b = j2;
        this.f207c = j3;
    }
}
