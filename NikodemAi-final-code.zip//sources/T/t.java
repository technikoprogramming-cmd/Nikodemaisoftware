package T;

import C.j;
import F.a;
import F.b;
import L.d;
import U.h;
import android.content.Context;
import android.graphics.Typeface;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuItem;
import androidx.emoji2.text.w;
import g.C0026a;
import g.C0030e;
import h.C;
import h.n;
import h.u;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.PriorityBlockingQueue;
import l.C0109k;
import t.C0129a;

public final class t {

    /* renamed from: a  reason: collision with root package name */
    public final Object f211a;
    public final Object b;

    /* renamed from: c  reason: collision with root package name */
    public final Object f212c;

    /* renamed from: d  reason: collision with root package name */
    public Object f213d;

    public t() {
        this.b = new ArrayList();
        this.f211a = new HashMap();
        this.f212c = new HashMap();
    }

    public void a() {
        for (Object a2 : ((HashMap) this.f211a).values()) {
            d.a(a2);
        }
    }

    public C0030e b(C0026a aVar) {
        ArrayList arrayList = (ArrayList) this.f212c;
        int size = arrayList.size();
        for (int i2 = 0; i2 < size; i2++) {
            C0030e eVar = (C0030e) arrayList.get(i2);
            if (eVar != null && eVar.b == aVar) {
                return eVar;
            }
        }
        C0030e eVar2 = new C0030e((Context) this.b, aVar);
        arrayList.add(eVar2);
        return eVar2;
    }

    public ArrayList c() {
        ArrayList arrayList = new ArrayList();
        for (Object a2 : ((HashMap) this.f211a).values()) {
            d.a(a2);
        }
        return arrayList;
    }

    public List d() {
        ArrayList arrayList;
        if (((ArrayList) this.b).isEmpty()) {
            return Collections.EMPTY_LIST;
        }
        synchronized (((ArrayList) this.b)) {
            arrayList = new ArrayList((ArrayList) this.b);
        }
        return arrayList;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:13:0x0040, code lost:
        return true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:25:0x005e, code lost:
        return false;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public synchronized boolean e(U.h r4) {
        /*
            r3 = this;
            monitor-enter(r3)
            java.lang.String r0 = r4.d()     // Catch:{ all -> 0x0021 }
            java.lang.Object r1 = r3.f211a     // Catch:{ all -> 0x0021 }
            java.util.HashMap r1 = (java.util.HashMap) r1     // Catch:{ all -> 0x0021 }
            boolean r1 = r1.containsKey(r0)     // Catch:{ all -> 0x0021 }
            if (r1 == 0) goto L_0x0042
            java.lang.Object r1 = r3.f211a     // Catch:{ all -> 0x0021 }
            java.util.HashMap r1 = (java.util.HashMap) r1     // Catch:{ all -> 0x0021 }
            java.lang.Object r1 = r1.get(r0)     // Catch:{ all -> 0x0021 }
            java.util.List r1 = (java.util.List) r1     // Catch:{ all -> 0x0021 }
            if (r1 != 0) goto L_0x0023
            java.util.ArrayList r1 = new java.util.ArrayList     // Catch:{ all -> 0x0021 }
            r1.<init>()     // Catch:{ all -> 0x0021 }
            goto L_0x0023
        L_0x0021:
            r4 = move-exception
            goto L_0x0063
        L_0x0023:
            java.lang.String r2 = "waiting-for-response"
            r4.a(r2)     // Catch:{ all -> 0x0021 }
            r1.add(r4)     // Catch:{ all -> 0x0021 }
            java.lang.Object r4 = r3.f211a     // Catch:{ all -> 0x0021 }
            java.util.HashMap r4 = (java.util.HashMap) r4     // Catch:{ all -> 0x0021 }
            r4.put(r0, r1)     // Catch:{ all -> 0x0021 }
            boolean r4 = T.s.f210a     // Catch:{ all -> 0x0021 }
            if (r4 == 0) goto L_0x003f
            java.lang.String r4 = "Request for cacheKey=%s is in flight, putting on hold."
            java.lang.Object[] r0 = new java.lang.Object[]{r0}     // Catch:{ all -> 0x0021 }
            T.s.b(r4, r0)     // Catch:{ all -> 0x0021 }
        L_0x003f:
            monitor-exit(r3)
            r4 = 1
            return r4
        L_0x0042:
            java.lang.Object r1 = r3.f211a     // Catch:{ all -> 0x0021 }
            java.util.HashMap r1 = (java.util.HashMap) r1     // Catch:{ all -> 0x0021 }
            r2 = 0
            r1.put(r0, r2)     // Catch:{ all -> 0x0021 }
            java.lang.Object r1 = r4.f233e     // Catch:{ all -> 0x0021 }
            monitor-enter(r1)     // Catch:{ all -> 0x0021 }
            r4.f240m = r3     // Catch:{ all -> 0x0060 }
            monitor-exit(r1)     // Catch:{ all -> 0x0060 }
            boolean r4 = T.s.f210a     // Catch:{ all -> 0x0021 }
            if (r4 == 0) goto L_0x005d
            java.lang.String r4 = "new request, sending to network %s"
            java.lang.Object[] r0 = new java.lang.Object[]{r0}     // Catch:{ all -> 0x0021 }
            T.s.b(r4, r0)     // Catch:{ all -> 0x0021 }
        L_0x005d:
            monitor-exit(r3)
            r4 = 0
            return r4
        L_0x0060:
            r4 = move-exception
            monitor-exit(r1)     // Catch:{ all -> 0x0060 }
            throw r4     // Catch:{ all -> 0x0021 }
        L_0x0063:
            monitor-exit(r3)     // Catch:{ all -> 0x0021 }
            throw r4
        */
        throw new UnsupportedOperationException("Method not decompiled: T.t.e(U.h):boolean");
    }

    public boolean f(C0026a aVar, MenuItem menuItem) {
        return ((ActionMode.Callback) this.f211a).onActionItemClicked(b(aVar), new u((Context) this.b, (C0129a) menuItem));
    }

    public boolean g(C0026a aVar, n nVar) {
        C0030e b2 = b(aVar);
        C0109k kVar = (C0109k) this.f213d;
        Menu menu = (Menu) kVar.getOrDefault(nVar, (Object) null);
        if (menu == null) {
            menu = new C((Context) this.b, nVar);
            kVar.put(nVar, menu);
        }
        return ((ActionMode.Callback) this.f211a).onCreateActionMode(b2, menu);
    }

    public synchronized void h(h hVar) {
        PriorityBlockingQueue priorityBlockingQueue;
        try {
            String d2 = hVar.d();
            List list = (List) ((HashMap) this.f211a).remove(d2);
            if (list != null && !list.isEmpty()) {
                if (s.f210a) {
                    s.d("%d waiting requests for cacheKey=%s; resend to network", Integer.valueOf(list.size()), d2);
                }
                h hVar2 = (h) list.remove(0);
                ((HashMap) this.f211a).put(d2, list);
                synchronized (hVar2.f233e) {
                    hVar2.f240m = this;
                }
                if (!(((d) this.f212c) == null || (priorityBlockingQueue = (PriorityBlockingQueue) this.f213d) == null)) {
                    priorityBlockingQueue.put(hVar2);
                }
            }
        } catch (InterruptedException e2) {
            s.c("Couldn't add request to queue. %s", e2.toString());
            Thread.currentThread().interrupt();
            d dVar = (d) this.f212c;
            dVar.f181e = true;
            dVar.interrupt();
        } catch (Throwable th) {
            while (true) {
                throw th;
            }
        }
    }

    public t(d dVar, PriorityBlockingQueue priorityBlockingQueue, j jVar) {
        this.f211a = new HashMap();
        this.b = jVar;
        this.f212c = dVar;
        this.f213d = priorityBlockingQueue;
    }

    public t(Typeface typeface, b bVar) {
        int i2;
        int i3;
        int i4;
        int i5;
        this.f213d = typeface;
        this.f211a = bVar;
        this.f212c = new androidx.emoji2.text.t(1024);
        int a2 = bVar.a(6);
        if (a2 != 0) {
            int i6 = a2 + bVar.f53a;
            i2 = ((ByteBuffer) bVar.f55d).getInt(((ByteBuffer) bVar.f55d).getInt(i6) + i6);
        } else {
            i2 = 0;
        }
        this.b = new char[(i2 * 2)];
        int a3 = bVar.a(6);
        if (a3 != 0) {
            int i7 = a3 + bVar.f53a;
            i3 = ((ByteBuffer) bVar.f55d).getInt(((ByteBuffer) bVar.f55d).getInt(i7) + i7);
        } else {
            i3 = 0;
        }
        int i8 = 0;
        while (i8 < i3) {
            w wVar = new w(this, i8);
            a b2 = wVar.b();
            int a4 = b2.a(4);
            Character.toChars(a4 != 0 ? ((ByteBuffer) b2.f55d).getInt(a4 + b2.f53a) : 0, (char[]) this.b, i8 * 2);
            a b3 = wVar.b();
            int a5 = b3.a(16);
            if (a5 != 0) {
                int i9 = a5 + b3.f53a;
                i4 = ((ByteBuffer) b3.f55d).getInt(((ByteBuffer) b3.f55d).getInt(i9) + i9);
            } else {
                i4 = 0;
            }
            if (i4 > 0) {
                a b4 = wVar.b();
                int a6 = b4.a(16);
                if (a6 != 0) {
                    int i10 = a6 + b4.f53a;
                    i5 = ((ByteBuffer) b4.f55d).getInt(((ByteBuffer) b4.f55d).getInt(i10) + i10);
                } else {
                    i5 = 0;
                }
                ((androidx.emoji2.text.t) this.f212c).a(wVar, 0, i5 - 1);
                i8++;
            } else {
                throw new IllegalArgumentException("invalid metadata codepoint length");
            }
        }
    }

    public t(Context context, ActionMode.Callback callback) {
        this.b = context;
        this.f211a = callback;
        this.f212c = new ArrayList();
        this.f213d = new C0109k();
    }
}
