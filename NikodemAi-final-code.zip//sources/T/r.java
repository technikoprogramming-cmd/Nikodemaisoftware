package T;

import android.os.SystemClock;
import java.util.ArrayList;

public final class r {

    /* renamed from: c  reason: collision with root package name */
    public static final boolean f208c = s.f210a;

    /* renamed from: a  reason: collision with root package name */
    public final ArrayList f209a = new ArrayList();
    public boolean b = false;

    /* JADX INFO: finally extract failed */
    public final synchronized void a(String str, long j2) {
        try {
            if (!this.b) {
                this.f209a.add(new q(str, j2, SystemClock.elapsedRealtime()));
            } else {
                throw new IllegalStateException("Marker added to finished log");
            }
        } catch (Throwable th) {
            throw th;
        }
    }

    public final synchronized void b(String str) {
        long j2;
        this.b = true;
        ArrayList arrayList = this.f209a;
        int i2 = 0;
        if (arrayList.size() == 0) {
            j2 = 0;
        } else {
            j2 = ((q) arrayList.get(arrayList.size() - 1)).f207c - ((q) arrayList.get(0)).f207c;
        }
        if (j2 > 0) {
            long j3 = ((q) this.f209a.get(0)).f207c;
            s.b("(%-4d ms) %s", Long.valueOf(j2), str);
            ArrayList arrayList2 = this.f209a;
            int size = arrayList2.size();
            while (i2 < size) {
                Object obj = arrayList2.get(i2);
                i2++;
                q qVar = (q) obj;
                long j4 = qVar.f207c;
                s.b("(+%-4d) [%2d] %s", Long.valueOf(j4 - j3), Long.valueOf(qVar.b), qVar.f206a);
                j3 = j4;
            }
        }
    }

    public final void finalize() {
        if (!this.b) {
            b("Request on the loose");
            s.c("Marker log finalized without finish() - uncaught exit point for request", new Object[0]);
        }
    }
}
