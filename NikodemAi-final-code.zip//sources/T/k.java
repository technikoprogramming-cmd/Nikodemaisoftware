package T;

import java.io.Serializable;

public final class k {

    /* renamed from: a  reason: collision with root package name */
    public boolean f192a;
    public final Serializable b;

    /* renamed from: c  reason: collision with root package name */
    public final Object f193c;

    /* renamed from: d  reason: collision with root package name */
    public final Object f194d;

    public k(String str, b bVar) {
        this.f192a = false;
        this.b = str;
        this.f193c = bVar;
        this.f194d = null;
    }

    public k(p pVar) {
        this.f192a = false;
        this.b = null;
        this.f193c = null;
        this.f194d = pVar;
    }

    /* JADX WARNING: type inference failed for: r1v0, types: [byte[], java.io.Serializable] */
    /* JADX WARNING: Unknown variable types count: 1 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public k(byte[] r1, java.util.Map r2, java.util.List r3, boolean r4) {
        /*
            r0 = this;
            r0.<init>()
            r0.b = r1
            r0.f193c = r2
            if (r3 != 0) goto L_0x000d
            r1 = 0
            r0.f194d = r1
            goto L_0x0013
        L_0x000d:
            java.util.List r1 = java.util.Collections.unmodifiableList(r3)
            r0.f194d = r1
        L_0x0013:
            r0.f192a = r4
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: T.k.<init>(byte[], java.util.Map, java.util.List, boolean):void");
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public k(byte[] r5, boolean r6, java.util.List r7) {
        /*
            r4 = this;
            if (r7 != 0) goto L_0x0004
            r0 = 0
            goto L_0x002c
        L_0x0004:
            boolean r0 = r7.isEmpty()
            if (r0 == 0) goto L_0x000d
            java.util.Map r0 = java.util.Collections.EMPTY_MAP
            goto L_0x002c
        L_0x000d:
            java.util.TreeMap r0 = new java.util.TreeMap
            java.util.Comparator r1 = java.lang.String.CASE_INSENSITIVE_ORDER
            r0.<init>(r1)
            java.util.Iterator r1 = r7.iterator()
        L_0x0018:
            boolean r2 = r1.hasNext()
            if (r2 == 0) goto L_0x002c
            java.lang.Object r2 = r1.next()
            T.i r2 = (T.i) r2
            java.lang.String r3 = r2.f187a
            java.lang.String r2 = r2.b
            r0.put(r3, r2)
            goto L_0x0018
        L_0x002c:
            r4.<init>(r5, r0, r7, r6)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: T.k.<init>(byte[], boolean, java.util.List):void");
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public k(byte[] r6, java.util.Map r7) {
        /*
            r5 = this;
            if (r7 != 0) goto L_0x0004
            r0 = 0
            goto L_0x003f
        L_0x0004:
            boolean r0 = r7.isEmpty()
            if (r0 == 0) goto L_0x000d
            java.util.List r0 = java.util.Collections.EMPTY_LIST
            goto L_0x003f
        L_0x000d:
            java.util.ArrayList r0 = new java.util.ArrayList
            int r1 = r7.size()
            r0.<init>(r1)
            java.util.Set r1 = r7.entrySet()
            java.util.Iterator r1 = r1.iterator()
        L_0x001e:
            boolean r2 = r1.hasNext()
            if (r2 == 0) goto L_0x003f
            java.lang.Object r2 = r1.next()
            java.util.Map$Entry r2 = (java.util.Map.Entry) r2
            T.i r3 = new T.i
            java.lang.Object r4 = r2.getKey()
            java.lang.String r4 = (java.lang.String) r4
            java.lang.Object r2 = r2.getValue()
            java.lang.String r2 = (java.lang.String) r2
            r3.<init>(r4, r2)
            r0.add(r3)
            goto L_0x001e
        L_0x003f:
            r1 = 0
            r5.<init>(r6, r7, r0, r1)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: T.k.<init>(byte[], java.util.Map):void");
    }
}
