package T;

public class p extends Exception {
}
