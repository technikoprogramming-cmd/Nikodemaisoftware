package T;

import U.h;

public final class m implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ String f195a;
    public final /* synthetic */ long b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ h f196c;

    public m(h hVar, String str, long j2) {
        this.f196c = hVar;
        this.f195a = str;
        this.b = j2;
    }

    public final void run() {
        h hVar = this.f196c;
        hVar.f230a.a(this.f195a, this.b);
        hVar.f230a.b(hVar.toString());
    }
}
