package T;

import C.j;
import U.h;
import android.app.Application;
import android.graphics.Typeface;
import android.util.Log;
import i.V;
import java.lang.reflect.Method;
import o.d;
import v.C0138d;

public final class c implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f175a;
    public final /* synthetic */ Object b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ Object f176c;

    public /* synthetic */ c(Object obj, int i2, Object obj2) {
        this.f175a = i2;
        this.b = obj;
        this.f176c = obj2;
    }

    public final void run() {
        switch (this.f175a) {
            case 0:
                try {
                    ((d) this.f176c).b.put((h) this.b);
                    return;
                } catch (InterruptedException unused) {
                    Thread.currentThread().interrupt();
                    return;
                }
            case 1:
                ((o.c) this.b).f1537a = this.f176c;
                return;
            case 2:
                ((Application) this.b).unregisterActivityLifecycleCallbacks((o.c) this.f176c);
                return;
            case 3:
                try {
                    Method method = d.f1543d;
                    Object obj = this.f176c;
                    Object obj2 = this.b;
                    if (method != null) {
                        method.invoke(obj2, new Object[]{obj, Boolean.FALSE, "AppCompat recreation"});
                        return;
                    } else {
                        d.f1544e.invoke(obj2, new Object[]{obj, Boolean.FALSE});
                        return;
                    }
                } catch (RuntimeException e2) {
                    if (e2.getClass() == RuntimeException.class && e2.getMessage() != null && e2.getMessage().startsWith("Unable to stop")) {
                        throw e2;
                    }
                    return;
                } catch (Throwable th) {
                    Log.e("ActivityRecreator", "Exception while invoking performStopActivity", th);
                    return;
                }
            case 4:
                V v2 = (V) ((j) this.b).b;
                if (v2 != null) {
                    v2.b((Typeface) this.f176c);
                    return;
                }
                return;
            default:
                ((C0138d) this.b).a(this.f176c);
                return;
        }
    }

    public c(d dVar, h hVar) {
        this.f175a = 0;
        this.f176c = dVar;
        this.b = hVar;
    }
}
