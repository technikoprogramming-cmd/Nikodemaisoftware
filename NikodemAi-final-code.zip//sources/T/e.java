package T;

public final class e extends a {
}
