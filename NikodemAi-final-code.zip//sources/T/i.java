package T;

import android.text.TextUtils;

public final class i {

    /* renamed from: a  reason: collision with root package name */
    public final String f187a;
    public final String b;

    public i(String str, String str2) {
        this.f187a = str;
        this.b = str2;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && i.class == obj.getClass()) {
            i iVar = (i) obj;
            if (!TextUtils.equals(this.f187a, iVar.f187a) || !TextUtils.equals(this.b, iVar.b)) {
                return false;
            }
            return true;
        }
        return false;
    }

    public final int hashCode() {
        return this.b.hashCode() + (this.f187a.hashCode() * 31);
    }

    public final String toString() {
        return "Header[name=" + this.f187a + ",value=" + this.b + "]";
    }
}
