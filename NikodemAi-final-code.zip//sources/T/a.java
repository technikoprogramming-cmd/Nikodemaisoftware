package T;

public class a extends p {
}
