package a0;

import Z.a;
import e0.c;

public class b extends a {
    /* JADX WARNING: type inference failed for: r0v1, types: [e0.a, java.lang.Object] */
    public final e0.a a() {
        Integer num = a.f292a;
        if (num == null || num.intValue() >= 34) {
            return new Object();
        }
        return new c();
    }
}
