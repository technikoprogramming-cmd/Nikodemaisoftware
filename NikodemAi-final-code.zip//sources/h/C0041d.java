package h;

import android.view.View;
import android.view.ViewTreeObserver;
import i.M0;
import i.P;
import i.T;
import java.util.ArrayList;

/* renamed from: h.d  reason: case insensitive filesystem */
public final class C0041d implements ViewTreeObserver.OnGlobalLayoutListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f1062a;
    public final /* synthetic */ Object b;

    public /* synthetic */ C0041d(int i2, Object obj) {
        this.f1062a = i2;
        this.b = obj;
    }

    public final void onGlobalLayout() {
        switch (this.f1062a) {
            case 0:
                h hVar = (h) this.b;
                if (hVar.a()) {
                    ArrayList arrayList = hVar.f1073h;
                    if (arrayList.size() > 0) {
                        int i2 = 0;
                        if (!((g) arrayList.get(0)).f1067a.f1213x) {
                            View view = hVar.f1080o;
                            if (view == null || !view.isShown()) {
                                hVar.dismiss();
                                return;
                            }
                            int size = arrayList.size();
                            while (i2 < size) {
                                Object obj = arrayList.get(i2);
                                i2++;
                                ((g) obj).f1067a.h();
                            }
                            return;
                        }
                        return;
                    }
                    return;
                }
                return;
            case 1:
                E e2 = (E) this.b;
                if (e2.a()) {
                    M0 m0 = e2.f1031h;
                    if (!m0.f1213x) {
                        View view2 = e2.f1036m;
                        if (view2 == null || !view2.isShown()) {
                            e2.dismiss();
                            return;
                        } else {
                            m0.h();
                            return;
                        }
                    } else {
                        return;
                    }
                } else {
                    return;
                }
            case 2:
                T t2 = (T) this.b;
                if (!t2.getInternalPopup().a()) {
                    t2.f.e(t2.getTextDirection(), t2.getTextAlignment());
                }
                ViewTreeObserver viewTreeObserver = t2.getViewTreeObserver();
                if (viewTreeObserver != null) {
                    viewTreeObserver.removeOnGlobalLayoutListener(this);
                    return;
                }
                return;
            default:
                P p2 = (P) this.b;
                T t3 = p2.f1245F;
                p2.getClass();
                if (!t3.isAttachedToWindow() || !t3.getGlobalVisibleRect(p2.f1243D)) {
                    p2.dismiss();
                    return;
                }
                p2.q();
                p2.h();
                return;
        }
    }
}
