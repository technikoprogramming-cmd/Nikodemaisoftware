package h;

/* renamed from: h.A  reason: case insensitive filesystem */
public interface C0037A {
    void c(p pVar);

    p getItemData();
}
