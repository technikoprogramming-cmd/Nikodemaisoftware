package i;

import android.database.DataSetObserver;

public final class E0 extends DataSetObserver {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ H0 f1183a;

    public E0(H0 h02) {
        this.f1183a = h02;
    }

    public final void onChanged() {
        H0 h02 = this.f1183a;
        if (h02.f1214y.isShowing()) {
            h02.h();
        }
    }

    public final void onInvalidated() {
        this.f1183a.dismiss();
    }
}
