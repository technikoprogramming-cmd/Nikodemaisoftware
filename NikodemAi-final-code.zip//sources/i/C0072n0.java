package i;

/* renamed from: i.n0  reason: case insensitive filesystem */
public interface C0072n0 {
}
