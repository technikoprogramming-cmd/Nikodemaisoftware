package i;

import h.n;
import h.p;

public interface I0 {
    void r(n nVar, p pVar);

    void t(n nVar, p pVar);
}
