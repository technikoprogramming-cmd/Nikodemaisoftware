package i;

import C.j;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.view.menu.ActionMenuItemView;
import androidx.appcompat.widget.ActionMenuView;
import h.B;
import h.C0037A;
import h.F;
import h.n;
import h.p;
import h.q;
import h.v;
import h.y;
import h.z;
import java.util.ArrayList;
import ncs.oprogramowanie.nikodemai.aos.R;

/* renamed from: i.l  reason: case insensitive filesystem */
public final class C0067l implements z {

    /* renamed from: a  reason: collision with root package name */
    public final Context f1353a;
    public Context b;

    /* renamed from: c  reason: collision with root package name */
    public n f1354c;

    /* renamed from: d  reason: collision with root package name */
    public final LayoutInflater f1355d;

    /* renamed from: e  reason: collision with root package name */
    public y f1356e;
    public final int f = R.layout.abc_action_menu_layout;

    /* renamed from: g  reason: collision with root package name */
    public final int f1357g = R.layout.abc_action_menu_item_layout;

    /* renamed from: h  reason: collision with root package name */
    public B f1358h;

    /* renamed from: i  reason: collision with root package name */
    public C0065k f1359i;

    /* renamed from: j  reason: collision with root package name */
    public Drawable f1360j;

    /* renamed from: k  reason: collision with root package name */
    public boolean f1361k;

    /* renamed from: l  reason: collision with root package name */
    public boolean f1362l;

    /* renamed from: m  reason: collision with root package name */
    public boolean f1363m;

    /* renamed from: n  reason: collision with root package name */
    public int f1364n;

    /* renamed from: o  reason: collision with root package name */
    public int f1365o;

    /* renamed from: p  reason: collision with root package name */
    public int f1366p;

    /* renamed from: q  reason: collision with root package name */
    public boolean f1367q;

    /* renamed from: r  reason: collision with root package name */
    public final SparseBooleanArray f1368r = new SparseBooleanArray();

    /* renamed from: s  reason: collision with root package name */
    public C0059h f1369s;

    /* renamed from: t  reason: collision with root package name */
    public C0059h f1370t;

    /* renamed from: u  reason: collision with root package name */
    public C0063j f1371u;

    /* renamed from: v  reason: collision with root package name */
    public C0061i f1372v;

    /* renamed from: w  reason: collision with root package name */
    public final j f1373w = new j(16, (Object) this);

    public C0067l(Context context) {
        this.f1353a = context;
        this.f1355d = LayoutInflater.from(context);
    }

    public final View a(p pVar, View view, ViewGroup viewGroup) {
        C0037A a2;
        View actionView = pVar.getActionView();
        int i2 = 0;
        if (actionView == null || pVar.e()) {
            if (view instanceof C0037A) {
                a2 = (C0037A) view;
            } else {
                a2 = (C0037A) this.f1355d.inflate(this.f1357g, viewGroup, false);
            }
            a2.c(pVar);
            ActionMenuItemView actionMenuItemView = (ActionMenuItemView) a2;
            actionMenuItemView.setItemInvoker((ActionMenuView) this.f1358h);
            if (this.f1372v == null) {
                this.f1372v = new C0061i(this);
            }
            actionMenuItemView.setPopupCallback(this.f1372v);
            actionView = (View) a2;
        }
        if (pVar.f1128C) {
            i2 = 8;
        }
        actionView.setVisibility(i2);
        ViewGroup.LayoutParams layoutParams = actionView.getLayoutParams();
        ((ActionMenuView) viewGroup).getClass();
        if (!(layoutParams instanceof C0071n)) {
            actionView.setLayoutParams(ActionMenuView.j(layoutParams));
        }
        return actionView;
    }

    public final void b(n nVar, boolean z2) {
        f();
        C0059h hVar = this.f1370t;
        if (hVar != null && hVar.b()) {
            hVar.f1168i.dismiss();
        }
        y yVar = this.f1356e;
        if (yVar != null) {
            yVar.b(nVar, z2);
        }
    }

    public final void c() {
        B b2;
        int i2;
        p pVar;
        ViewGroup viewGroup = (ViewGroup) this.f1358h;
        ArrayList arrayList = null;
        boolean z2 = false;
        if (viewGroup != null) {
            n nVar = this.f1354c;
            if (nVar != null) {
                nVar.i();
                ArrayList l2 = this.f1354c.l();
                int size = l2.size();
                i2 = 0;
                for (int i3 = 0; i3 < size; i3++) {
                    p pVar2 = (p) l2.get(i3);
                    if ((pVar2.f1150x & 32) == 32) {
                        View childAt = viewGroup.getChildAt(i2);
                        if (childAt instanceof C0037A) {
                            pVar = ((C0037A) childAt).getItemData();
                        } else {
                            pVar = null;
                        }
                        View a2 = a(pVar2, childAt, viewGroup);
                        if (pVar2 != pVar) {
                            a2.setPressed(false);
                            a2.jumpDrawablesToCurrentState();
                        }
                        if (a2 != childAt) {
                            ViewGroup viewGroup2 = (ViewGroup) a2.getParent();
                            if (viewGroup2 != null) {
                                viewGroup2.removeView(a2);
                            }
                            ((ViewGroup) this.f1358h).addView(a2, i2);
                        }
                        i2++;
                    }
                }
            } else {
                i2 = 0;
            }
            while (i2 < viewGroup.getChildCount()) {
                if (viewGroup.getChildAt(i2) == this.f1359i) {
                    i2++;
                } else {
                    viewGroup.removeViewAt(i2);
                }
            }
        }
        ((View) this.f1358h).requestLayout();
        n nVar2 = this.f1354c;
        if (nVar2 != null) {
            nVar2.i();
            ArrayList arrayList2 = nVar2.f1108i;
            int size2 = arrayList2.size();
            for (int i4 = 0; i4 < size2; i4++) {
                q qVar = ((p) arrayList2.get(i4)).f1126A;
            }
        }
        n nVar3 = this.f1354c;
        if (nVar3 != null) {
            nVar3.i();
            arrayList = nVar3.f1109j;
        }
        if (this.f1362l && arrayList != null) {
            int size3 = arrayList.size();
            if (size3 == 1) {
                z2 = !((p) arrayList.get(0)).f1128C;
            } else if (size3 > 0) {
                z2 = true;
            }
        }
        if (z2) {
            if (this.f1359i == null) {
                this.f1359i = new C0065k(this, this.f1353a);
            }
            ViewGroup viewGroup3 = (ViewGroup) this.f1359i.getParent();
            if (viewGroup3 != this.f1358h) {
                if (viewGroup3 != null) {
                    viewGroup3.removeView(this.f1359i);
                }
                ActionMenuView actionMenuView = (ActionMenuView) this.f1358h;
                C0065k kVar = this.f1359i;
                actionMenuView.getClass();
                C0071n i5 = ActionMenuView.i();
                i5.f1374a = true;
                actionMenuView.addView(kVar, i5);
            }
        } else {
            C0065k kVar2 = this.f1359i;
            if (kVar2 != null && kVar2.getParent() == (b2 = this.f1358h)) {
                ((ViewGroup) b2).removeView(this.f1359i);
            }
        }
        ((ActionMenuView) this.f1358h).setOverflowReserved(this.f1362l);
    }

    public final boolean d(p pVar) {
        return false;
    }

    public final void e(y yVar) {
        throw null;
    }

    public final boolean f() {
        B b2;
        C0063j jVar = this.f1371u;
        if (jVar == null || (b2 = this.f1358h) == null) {
            C0059h hVar = this.f1369s;
            if (hVar == null) {
                return false;
            }
            if (hVar.b()) {
                hVar.f1168i.dismiss();
            }
            return true;
        }
        ((View) b2).removeCallbacks(jVar);
        this.f1371u = null;
        return true;
    }

    public final void g(Context context, n nVar) {
        this.b = context;
        LayoutInflater.from(context);
        this.f1354c = nVar;
        Resources resources = context.getResources();
        if (!this.f1363m) {
            this.f1362l = true;
        }
        int i2 = 2;
        this.f1364n = context.getResources().getDisplayMetrics().widthPixels / 2;
        Configuration configuration = context.getResources().getConfiguration();
        int i3 = configuration.screenWidthDp;
        int i4 = configuration.screenHeightDp;
        if (configuration.smallestScreenWidthDp > 600 || i3 > 600 || ((i3 > 960 && i4 > 720) || (i3 > 720 && i4 > 960))) {
            i2 = 5;
        } else if (i3 >= 500 || ((i3 > 640 && i4 > 480) || (i3 > 480 && i4 > 640))) {
            i2 = 4;
        } else if (i3 >= 360) {
            i2 = 3;
        }
        this.f1366p = i2;
        int i5 = this.f1364n;
        if (this.f1362l) {
            if (this.f1359i == null) {
                C0065k kVar = new C0065k(this, this.f1353a);
                this.f1359i = kVar;
                if (this.f1361k) {
                    kVar.setImageDrawable(this.f1360j);
                    this.f1360j = null;
                    this.f1361k = false;
                }
                int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
                this.f1359i.measure(makeMeasureSpec, makeMeasureSpec);
            }
            i5 -= this.f1359i.getMeasuredWidth();
        } else {
            this.f1359i = null;
        }
        this.f1365o = i5;
        float f2 = resources.getDisplayMetrics().density;
    }

    public final boolean h() {
        C0059h hVar = this.f1369s;
        if (hVar == null || !hVar.b()) {
            return false;
        }
        return true;
    }

    public final boolean i() {
        int i2;
        ArrayList arrayList;
        int i3;
        boolean z2;
        boolean z3;
        boolean z4;
        boolean z5;
        C0067l lVar = this;
        n nVar = lVar.f1354c;
        if (nVar != null) {
            arrayList = nVar.l();
            i2 = arrayList.size();
        } else {
            i2 = 0;
            arrayList = null;
        }
        int i4 = lVar.f1366p;
        int i5 = lVar.f1365o;
        int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
        ViewGroup viewGroup = (ViewGroup) lVar.f1358h;
        int i6 = 0;
        boolean z6 = false;
        int i7 = 0;
        int i8 = 0;
        while (true) {
            i3 = 2;
            z2 = true;
            if (i6 >= i2) {
                break;
            }
            p pVar = (p) arrayList.get(i6);
            int i9 = pVar.f1151y;
            if ((i9 & 2) == 2) {
                i7++;
            } else if ((i9 & 1) == 1) {
                i8++;
            } else {
                z6 = true;
            }
            if (lVar.f1367q && pVar.f1128C) {
                i4 = 0;
            }
            i6++;
        }
        if (lVar.f1362l && (z6 || i8 + i7 > i4)) {
            i4--;
        }
        int i10 = i4 - i7;
        SparseBooleanArray sparseBooleanArray = lVar.f1368r;
        sparseBooleanArray.clear();
        int i11 = 0;
        int i12 = 0;
        while (i11 < i2) {
            p pVar2 = (p) arrayList.get(i11);
            int i13 = pVar2.f1151y;
            if ((i13 & 2) == i3) {
                z3 = z2;
            } else {
                z3 = false;
            }
            int i14 = pVar2.b;
            if (z3) {
                View a2 = lVar.a(pVar2, (View) null, viewGroup);
                a2.measure(makeMeasureSpec, makeMeasureSpec);
                int measuredWidth = a2.getMeasuredWidth();
                i5 -= measuredWidth;
                if (i12 == 0) {
                    i12 = measuredWidth;
                }
                if (i14 != 0) {
                    sparseBooleanArray.put(i14, z2);
                }
                pVar2.f(z2);
            } else if ((i13 & true) == z2) {
                boolean z7 = sparseBooleanArray.get(i14);
                if ((i10 > 0 || z7) && i5 > 0) {
                    z4 = z2;
                } else {
                    z4 = false;
                }
                if (z4) {
                    View a3 = lVar.a(pVar2, (View) null, viewGroup);
                    a3.measure(makeMeasureSpec, makeMeasureSpec);
                    int measuredWidth2 = a3.getMeasuredWidth();
                    i5 -= measuredWidth2;
                    if (i12 == 0) {
                        i12 = measuredWidth2;
                    }
                    if (i5 + i12 > 0) {
                        z5 = true;
                    } else {
                        z5 = false;
                    }
                    z4 &= z5;
                }
                if (z4 && i14 != 0) {
                    sparseBooleanArray.put(i14, true);
                } else if (z7) {
                    sparseBooleanArray.put(i14, false);
                    int i15 = 0;
                    while (i15 < i11) {
                        p pVar3 = (p) arrayList.get(i15);
                        if (pVar3.b == i14) {
                            if ((pVar3.f1150x & 32) == 32) {
                                i10++;
                            }
                            pVar3.f(false);
                        }
                        i15++;
                    }
                }
                if (z4) {
                    i10--;
                }
                pVar2.f(z4);
            } else {
                pVar2.f(false);
                i11++;
                i3 = 2;
                lVar = this;
                z2 = true;
            }
            i11++;
            i3 = 2;
            lVar = this;
            z2 = true;
        }
        return z2;
    }

    public final boolean j(F f2) {
        boolean z2;
        if (f2.hasVisibleItems()) {
            F f3 = f2;
            while (true) {
                n nVar = f3.f1045z;
                if (nVar == this.f1354c) {
                    break;
                }
                f3 = nVar;
            }
            ViewGroup viewGroup = (ViewGroup) this.f1358h;
            View view = null;
            if (viewGroup != null) {
                int childCount = viewGroup.getChildCount();
                int i2 = 0;
                while (true) {
                    if (i2 >= childCount) {
                        break;
                    }
                    View childAt = viewGroup.getChildAt(i2);
                    if ((childAt instanceof C0037A) && ((C0037A) childAt).getItemData() == f3.f1044A) {
                        view = childAt;
                        break;
                    }
                    i2++;
                }
            }
            if (view != null) {
                f2.f1044A.getClass();
                int size = f2.f.size();
                int i3 = 0;
                while (true) {
                    if (i3 >= size) {
                        z2 = false;
                        break;
                    }
                    MenuItem item = f2.getItem(i3);
                    if (item.isVisible() && item.getIcon() != null) {
                        z2 = true;
                        break;
                    }
                    i3++;
                }
                C0059h hVar = new C0059h(this, this.b, f2, view);
                this.f1370t = hVar;
                hVar.f1166g = z2;
                v vVar = hVar.f1168i;
                if (vVar != null) {
                    vVar.o(z2);
                }
                C0059h hVar2 = this.f1370t;
                if (!hVar2.b()) {
                    if (hVar2.f1165e != null) {
                        hVar2.d(0, 0, false, false);
                    } else {
                        throw new IllegalStateException("MenuPopupHelper cannot be used without an anchor");
                    }
                }
                y yVar = this.f1356e;
                if (yVar != null) {
                    yVar.m(f2);
                }
                return true;
            }
        }
        return false;
    }

    public final boolean k(p pVar) {
        return false;
    }

    public final boolean l() {
        n nVar;
        if (!this.f1362l || h() || (nVar = this.f1354c) == null || this.f1358h == null || this.f1371u != null) {
            return false;
        }
        nVar.i();
        if (nVar.f1109j.isEmpty()) {
            return false;
        }
        C0063j jVar = new C0063j(this, new C0059h(this, this.b, this.f1354c, (View) this.f1359i));
        this.f1371u = jVar;
        ((View) this.f1358h).post(jVar);
        return true;
    }
}
