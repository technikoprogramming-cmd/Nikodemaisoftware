package i;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.SeekBar;
import ncs.oprogramowanie.nikodemai.aos.R;

public final class H extends SeekBar {

    /* renamed from: a  reason: collision with root package name */
    public final I f1189a;

    public H(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, R.attr.seekBarStyle);
        T0.a(this, getContext());
        I i2 = new I(this);
        this.f1189a = i2;
        i2.b(attributeSet, R.attr.seekBarStyle);
    }

    public final void drawableStateChanged() {
        super.drawableStateChanged();
        I i2 = this.f1189a;
        Drawable drawable = i2.f;
        if (drawable != null && drawable.isStateful()) {
            H h2 = i2.f1215e;
            if (drawable.setState(h2.getDrawableState())) {
                h2.invalidateDrawable(drawable);
            }
        }
    }

    public final void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        Drawable drawable = this.f1189a.f;
        if (drawable != null) {
            drawable.jumpToCurrentState();
        }
    }

    public final synchronized void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        this.f1189a.g(canvas);
    }
}
