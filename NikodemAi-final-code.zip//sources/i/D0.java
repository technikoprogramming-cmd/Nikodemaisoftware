package i;

public final class D0 implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f1179a;
    public final /* synthetic */ H0 b;

    public /* synthetic */ D0(H0 h02, int i2) {
        this.f1179a = i2;
        this.b = h02;
    }

    public final void run() {
        switch (this.f1179a) {
            case 0:
                C0085u0 u0Var = this.b.f1193c;
                if (u0Var != null) {
                    u0Var.setListSelectionHidden(true);
                    u0Var.requestLayout();
                    return;
                }
                return;
            default:
                H0 h02 = this.b;
                C0085u0 u0Var2 = h02.f1193c;
                if (u0Var2 != null && u0Var2.isAttachedToWindow() && h02.f1193c.getCount() > h02.f1193c.getChildCount() && h02.f1193c.getChildCount() <= h02.f1202m) {
                    h02.f1214y.setInputMethodMode(2);
                    h02.h();
                    return;
                }
                return;
        }
    }
}
