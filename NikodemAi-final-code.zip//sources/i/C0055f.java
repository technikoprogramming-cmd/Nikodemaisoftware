package i;

import android.view.ViewGroup;

/* renamed from: i.f  reason: case insensitive filesystem */
public final class C0055f extends ViewGroup.MarginLayoutParams {
}
