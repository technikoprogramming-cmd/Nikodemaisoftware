package i;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import androidx.appcompat.widget.Toolbar;
import g.C0027b;
import h.F;
import h.n;
import h.p;
import h.r;
import h.z;
import java.util.ArrayList;

public final class a1 implements z {

    /* renamed from: a  reason: collision with root package name */
    public n f1289a;
    public p b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ Toolbar f1290c;

    public a1(Toolbar toolbar) {
        this.f1290c = toolbar;
    }

    public final void c() {
        if (this.b != null) {
            n nVar = this.f1289a;
            if (nVar != null) {
                int size = nVar.f.size();
                int i2 = 0;
                while (i2 < size) {
                    if (this.f1289a.getItem(i2) != this.b) {
                        i2++;
                    } else {
                        return;
                    }
                }
            }
            d(this.b);
        }
    }

    public final boolean d(p pVar) {
        Toolbar toolbar = this.f1290c;
        View view = toolbar.f480i;
        if (view instanceof C0027b) {
            ((r) ((C0027b) view)).f1155a.onActionViewCollapsed();
        }
        toolbar.removeView(toolbar.f480i);
        toolbar.removeView(toolbar.f479h);
        toolbar.f480i = null;
        ArrayList arrayList = toolbar.f461E;
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            toolbar.addView((View) arrayList.get(size));
        }
        arrayList.clear();
        this.b = null;
        toolbar.requestLayout();
        pVar.f1128C = false;
        pVar.f1140n.p(false);
        toolbar.t();
        return true;
    }

    public final void g(Context context, n nVar) {
        p pVar;
        n nVar2 = this.f1289a;
        if (!(nVar2 == null || (pVar = this.b) == null)) {
            nVar2.d(pVar);
        }
        this.f1289a = nVar;
    }

    public final boolean i() {
        return false;
    }

    public final boolean j(F f) {
        return false;
    }

    public final boolean k(p pVar) {
        Toolbar toolbar = this.f1290c;
        toolbar.c();
        ViewParent parent = toolbar.f479h.getParent();
        if (parent != toolbar) {
            if (parent instanceof ViewGroup) {
                ((ViewGroup) parent).removeView(toolbar.f479h);
            }
            toolbar.addView(toolbar.f479h);
        }
        View actionView = pVar.getActionView();
        toolbar.f480i = actionView;
        this.b = pVar;
        ViewParent parent2 = actionView.getParent();
        if (parent2 != toolbar) {
            if (parent2 instanceof ViewGroup) {
                ((ViewGroup) parent2).removeView(toolbar.f480i);
            }
            b1 h2 = Toolbar.h();
            h2.f1292a = (toolbar.f485n & 112) | 8388611;
            h2.b = 2;
            toolbar.f480i.setLayoutParams(h2);
            toolbar.addView(toolbar.f480i);
        }
        for (int childCount = toolbar.getChildCount() - 1; childCount >= 0; childCount--) {
            View childAt = toolbar.getChildAt(childCount);
            if (!(((b1) childAt.getLayoutParams()).b == 2 || childAt == toolbar.f474a)) {
                toolbar.removeViewAt(childCount);
                toolbar.f461E.add(childAt);
            }
        }
        toolbar.requestLayout();
        pVar.f1128C = true;
        pVar.f1140n.p(false);
        View view = toolbar.f480i;
        if (view instanceof C0027b) {
            ((r) ((C0027b) view)).f1155a.onActionViewExpanded();
        }
        toolbar.t();
        return true;
    }

    public final void b(n nVar, boolean z2) {
    }
}
