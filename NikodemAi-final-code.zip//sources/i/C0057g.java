package i;

import android.view.View;

/* renamed from: i.g  reason: case insensitive filesystem */
public final class C0057g extends View {
    public final int getWindowSystemUiVisibility() {
        return 0;
    }
}
