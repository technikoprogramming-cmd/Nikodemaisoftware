package i;

import android.view.ViewGroup;

public final class b1 extends ViewGroup.MarginLayoutParams {

    /* renamed from: a  reason: collision with root package name */
    public int f1292a = 0;
    public int b;

    public b1(b1 b1Var) {
        super(b1Var);
        this.f1292a = b1Var.f1292a;
    }

    public b1(ViewGroup.LayoutParams layoutParams) {
        super(layoutParams);
    }
}
