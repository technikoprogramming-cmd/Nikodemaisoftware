package i;

/* renamed from: i.m  reason: case insensitive filesystem */
public interface C0069m {
    boolean a();

    boolean b();
}
