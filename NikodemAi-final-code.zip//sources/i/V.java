package i;

import android.graphics.Typeface;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.widget.TextView;
import androidx.activity.d;
import java.lang.ref.WeakReference;

public final class V {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f1266a;
    public final /* synthetic */ int b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ WeakReference f1267c;

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ C0046a0 f1268d;

    public V(C0046a0 a0Var, int i2, int i3, WeakReference weakReference) {
        this.f1268d = a0Var;
        this.f1266a = i2;
        this.b = i3;
        this.f1267c = weakReference;
    }

    public final void a() {
        new Handler(Looper.getMainLooper()).post(new d(6, this));
    }

    public final void b(Typeface typeface) {
        int i2;
        boolean z2;
        if (Build.VERSION.SDK_INT >= 28 && (i2 = this.f1266a) != -1) {
            if ((this.b & 2) != 0) {
                z2 = true;
            } else {
                z2 = false;
            }
            typeface = Z.a(typeface, i2, z2);
        }
        C0046a0 a0Var = this.f1268d;
        if (a0Var.f1288m) {
            a0Var.f1287l = typeface;
            TextView textView = (TextView) this.f1267c.get();
            if (textView == null) {
                return;
            }
            if (textView.isAttachedToWindow()) {
                textView.post(new W(textView, typeface, a0Var.f1285j));
            } else {
                textView.setTypeface(typeface, a0Var.f1285j);
            }
        }
    }
}
