package i;

import C.b;
import C.c;
import C.h;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.TextView;
import d.C0010a;
import java.lang.ref.WeakReference;
import java.util.Arrays;

/* renamed from: i.a0  reason: case insensitive filesystem */
public final class C0046a0 {

    /* renamed from: a  reason: collision with root package name */
    public final TextView f1278a;
    public V0 b;

    /* renamed from: c  reason: collision with root package name */
    public V0 f1279c;

    /* renamed from: d  reason: collision with root package name */
    public V0 f1280d;

    /* renamed from: e  reason: collision with root package name */
    public V0 f1281e;
    public V0 f;

    /* renamed from: g  reason: collision with root package name */
    public V0 f1282g;

    /* renamed from: h  reason: collision with root package name */
    public V0 f1283h;

    /* renamed from: i  reason: collision with root package name */
    public final C0064j0 f1284i;

    /* renamed from: j  reason: collision with root package name */
    public int f1285j = 0;

    /* renamed from: k  reason: collision with root package name */
    public int f1286k = -1;

    /* renamed from: l  reason: collision with root package name */
    public Typeface f1287l;

    /* renamed from: m  reason: collision with root package name */
    public boolean f1288m;

    public C0046a0(TextView textView) {
        this.f1278a = textView;
        this.f1284i = new C0064j0(textView);
    }

    /* JADX WARNING: type inference failed for: r2v1, types: [java.lang.Object, i.V0] */
    public static V0 c(Context context, C0086v vVar, int i2) {
        ColorStateList f2;
        synchronized (vVar) {
            f2 = vVar.f1416a.f(context, i2);
        }
        if (f2 == null) {
            return null;
        }
        ? obj = new Object();
        obj.f1271d = true;
        obj.f1269a = f2;
        return obj;
    }

    public static void h(EditorInfo editorInfo, InputConnection inputConnection, TextView textView) {
        int i2;
        int i3;
        CharSequence charSequence;
        int i4 = Build.VERSION.SDK_INT;
        if (i4 < 30 && inputConnection != null) {
            CharSequence text = textView.getText();
            if (i4 >= 30) {
                b.a(editorInfo, text);
                return;
            }
            text.getClass();
            if (i4 >= 30) {
                b.a(editorInfo, text);
                return;
            }
            int i5 = editorInfo.initialSelStart;
            int i6 = editorInfo.initialSelEnd;
            if (i5 > i6) {
                i2 = i6;
            } else {
                i2 = i5;
            }
            if (i5 <= i6) {
                i5 = i6;
            }
            int length = text.length();
            if (i2 < 0 || i5 > length) {
                c.a(editorInfo, (CharSequence) null, 0, 0);
                return;
            }
            int i7 = editorInfo.inputType & 4095;
            if (i7 == 129 || i7 == 225 || i7 == 18) {
                c.a(editorInfo, (CharSequence) null, 0, 0);
            } else if (length <= 2048) {
                c.a(editorInfo, text, i2, i5);
            } else {
                int i8 = i5 - i2;
                if (i8 > 1024) {
                    i3 = 0;
                } else {
                    i3 = i8;
                }
                int i9 = 2048 - i3;
                int min = Math.min(text.length() - i5, i9 - Math.min(i2, (int) (((double) i9) * 0.8d)));
                int min2 = Math.min(i2, i9 - min);
                int i10 = i2 - min2;
                if (Character.isLowSurrogate(text.charAt(i10))) {
                    i10++;
                    min2--;
                }
                if (Character.isHighSurrogate(text.charAt((i5 + min) - 1))) {
                    min--;
                }
                int i11 = min2 + i3;
                int i12 = i11 + min;
                if (i3 != i8) {
                    charSequence = TextUtils.concat(new CharSequence[]{text.subSequence(i10, i10 + min2), text.subSequence(i5, min + i5)});
                } else {
                    charSequence = text.subSequence(i10, i12 + i10);
                }
                c.a(editorInfo, charSequence, min2, i11);
            }
        }
    }

    public final void a(Drawable drawable, V0 v0) {
        if (drawable != null && v0 != null) {
            C0086v.d(drawable, v0, this.f1278a.getDrawableState());
        }
    }

    public final void b() {
        V0 v0 = this.b;
        TextView textView = this.f1278a;
        if (!(v0 == null && this.f1279c == null && this.f1280d == null && this.f1281e == null)) {
            Drawable[] compoundDrawables = textView.getCompoundDrawables();
            a(compoundDrawables[0], this.b);
            a(compoundDrawables[1], this.f1279c);
            a(compoundDrawables[2], this.f1280d);
            a(compoundDrawables[3], this.f1281e);
        }
        if (this.f != null || this.f1282g != null) {
            Drawable[] compoundDrawablesRelative = textView.getCompoundDrawablesRelative();
            a(compoundDrawablesRelative[0], this.f);
            a(compoundDrawablesRelative[2], this.f1282g);
        }
    }

    public final ColorStateList d() {
        V0 v0 = this.f1283h;
        if (v0 != null) {
            return v0.f1269a;
        }
        return null;
    }

    public final PorterDuff.Mode e() {
        V0 v0 = this.f1283h;
        if (v0 != null) {
            return v0.b;
        }
        return null;
    }

    /* JADX WARNING: Removed duplicated region for block: B:214:0x03a0  */
    /* JADX WARNING: Removed duplicated region for block: B:216:0x03a5  */
    /* JADX WARNING: Removed duplicated region for block: B:219:0x03ac  */
    /* JADX WARNING: Removed duplicated region for block: B:229:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void f(android.util.AttributeSet r24, int r25) {
        /*
            r23 = this;
            r0 = r23
            r4 = r24
            r6 = r25
            android.widget.TextView r1 = r0.f1278a
            android.content.Context r7 = r1.getContext()
            i.v r8 = i.C0086v.a()
            int[] r3 = d.C0010a.f776h
            C.h r9 = C.h.m(r7, r4, r3, r6)
            android.content.Context r2 = r1.getContext()
            java.lang.Object r5 = r9.b
            android.content.res.TypedArray r5 = (android.content.res.TypedArray) r5
            y.K.g(r1, r2, r3, r4, r5, r6)
            r10 = r1
            java.lang.Object r1 = r9.b
            android.content.res.TypedArray r1 = (android.content.res.TypedArray) r1
            r11 = 0
            r12 = -1
            int r2 = r1.getResourceId(r11, r12)
            r13 = 3
            boolean r3 = r1.hasValue(r13)
            if (r3 == 0) goto L_0x003d
            int r3 = r1.getResourceId(r13, r11)
            i.V0 r3 = c(r7, r8, r3)
            r0.b = r3
        L_0x003d:
            r14 = 1
            boolean r3 = r1.hasValue(r14)
            if (r3 == 0) goto L_0x004e
            int r3 = r1.getResourceId(r14, r11)
            i.V0 r3 = c(r7, r8, r3)
            r0.f1279c = r3
        L_0x004e:
            r15 = 4
            boolean r3 = r1.hasValue(r15)
            if (r3 == 0) goto L_0x005f
            int r3 = r1.getResourceId(r15, r11)
            i.V0 r3 = c(r7, r8, r3)
            r0.f1280d = r3
        L_0x005f:
            r3 = 2
            boolean r5 = r1.hasValue(r3)
            if (r5 == 0) goto L_0x0070
            int r5 = r1.getResourceId(r3, r11)
            i.V0 r5 = c(r7, r8, r5)
            r0.f1281e = r5
        L_0x0070:
            r5 = 5
            boolean r16 = r1.hasValue(r5)
            if (r16 == 0) goto L_0x0081
            int r3 = r1.getResourceId(r5, r11)
            i.V0 r3 = c(r7, r8, r3)
            r0.f = r3
        L_0x0081:
            r3 = 6
            boolean r17 = r1.hasValue(r3)
            if (r17 == 0) goto L_0x0092
            int r1 = r1.getResourceId(r3, r11)
            i.V0 r1 = c(r7, r8, r1)
            r0.f1282g = r1
        L_0x0092:
            r9.r()
            android.text.method.TransformationMethod r1 = r10.getTransformationMethod()
            boolean r1 = r1 instanceof android.text.method.PasswordTransformationMethod
            int[] r9 = d.C0010a.f790v
            r13 = 15
            r3 = 26
            r5 = 14
            r14 = 13
            if (r2 == r12) goto L_0x00e9
            C.h r15 = new C.h
            android.content.res.TypedArray r2 = r7.obtainStyledAttributes(r2, r9)
            r15.<init>((android.content.Context) r7, (android.content.res.TypedArray) r2)
            if (r1 != 0) goto L_0x00c1
            boolean r20 = r2.hasValue(r5)
            if (r20 == 0) goto L_0x00c1
            boolean r20 = r2.getBoolean(r5, r11)
            r21 = r20
            r20 = 1
            goto L_0x00c5
        L_0x00c1:
            r20 = r11
            r21 = r20
        L_0x00c5:
            r0.n(r7, r15)
            int r12 = android.os.Build.VERSION.SDK_INT
            boolean r22 = r2.hasValue(r13)
            if (r22 == 0) goto L_0x00d5
            java.lang.String r22 = r2.getString(r13)
            goto L_0x00d7
        L_0x00d5:
            r22 = 0
        L_0x00d7:
            if (r12 < r3) goto L_0x00e4
            boolean r12 = r2.hasValue(r14)
            if (r12 == 0) goto L_0x00e4
            java.lang.String r2 = r2.getString(r14)
            goto L_0x00e5
        L_0x00e4:
            r2 = 0
        L_0x00e5:
            r15.r()
            goto L_0x00f0
        L_0x00e9:
            r20 = r11
            r21 = r20
            r2 = 0
            r22 = 0
        L_0x00f0:
            C.h r12 = new C.h
            android.content.res.TypedArray r9 = r7.obtainStyledAttributes(r4, r9, r6, r11)
            r12.<init>((android.content.Context) r7, (android.content.res.TypedArray) r9)
            if (r1 != 0) goto L_0x0107
            boolean r15 = r9.hasValue(r5)
            if (r15 == 0) goto L_0x0107
            boolean r21 = r9.getBoolean(r5, r11)
            r20 = 1
        L_0x0107:
            r5 = r21
            int r15 = android.os.Build.VERSION.SDK_INT
            boolean r21 = r9.hasValue(r13)
            if (r21 == 0) goto L_0x0115
            java.lang.String r22 = r9.getString(r13)
        L_0x0115:
            if (r15 < r3) goto L_0x0121
            boolean r3 = r9.hasValue(r14)
            if (r3 == 0) goto L_0x0121
            java.lang.String r2 = r9.getString(r14)
        L_0x0121:
            r3 = 28
            if (r15 < r3) goto L_0x0136
            boolean r3 = r9.hasValue(r11)
            if (r3 == 0) goto L_0x0136
            r3 = -1
            int r9 = r9.getDimensionPixelSize(r11, r3)
            if (r9 != 0) goto L_0x0136
            r3 = 0
            r10.setTextSize(r11, r3)
        L_0x0136:
            r0.n(r7, r12)
            r12.r()
            if (r1 != 0) goto L_0x0143
            if (r20 == 0) goto L_0x0143
            r10.setAllCaps(r5)
        L_0x0143:
            android.graphics.Typeface r1 = r0.f1287l
            if (r1 == 0) goto L_0x0155
            int r3 = r0.f1286k
            r5 = -1
            if (r3 != r5) goto L_0x0152
            int r3 = r0.f1285j
            r10.setTypeface(r1, r3)
            goto L_0x0155
        L_0x0152:
            r10.setTypeface(r1)
        L_0x0155:
            if (r2 == 0) goto L_0x015a
            i.Y.d(r10, r2)
        L_0x015a:
            if (r22 == 0) goto L_0x0163
            android.os.LocaleList r1 = i.X.a(r22)
            i.X.b(r10, r1)
        L_0x0163:
            int[] r3 = d.C0010a.f777i
            i.j0 r9 = r0.f1284i
            android.content.Context r12 = r9.f1342j
            android.content.res.TypedArray r5 = r12.obtainStyledAttributes(r4, r3, r6, r11)
            android.widget.TextView r1 = r9.f1341i
            android.content.Context r2 = r1.getContext()
            r13 = 5
            r15 = 2
            y.K.g(r1, r2, r3, r4, r5, r6)
            boolean r1 = r5.hasValue(r13)
            if (r1 == 0) goto L_0x0184
            int r1 = r5.getInt(r13, r11)
            r9.f1335a = r1
        L_0x0184:
            r1 = 4
            boolean r2 = r5.hasValue(r1)
            r6 = -1082130432(0xffffffffbf800000, float:-1.0)
            if (r2 == 0) goto L_0x0192
            float r1 = r5.getDimension(r1, r6)
            goto L_0x0193
        L_0x0192:
            r1 = r6
        L_0x0193:
            boolean r2 = r5.hasValue(r15)
            if (r2 == 0) goto L_0x019f
            float r2 = r5.getDimension(r15, r6)
        L_0x019d:
            r13 = 1
            goto L_0x01a1
        L_0x019f:
            r2 = r6
            goto L_0x019d
        L_0x01a1:
            boolean r18 = r5.hasValue(r13)
            if (r18 == 0) goto L_0x01ad
            float r18 = r5.getDimension(r13, r6)
        L_0x01ab:
            r13 = 3
            goto L_0x01b0
        L_0x01ad:
            r18 = r6
            goto L_0x01ab
        L_0x01b0:
            boolean r17 = r5.hasValue(r13)
            r25 = r6
            if (r17 == 0) goto L_0x01e7
            int r6 = r5.getResourceId(r13, r11)
            if (r6 <= 0) goto L_0x01e7
            android.content.res.Resources r13 = r5.getResources()
            android.content.res.TypedArray r6 = r13.obtainTypedArray(r6)
            int r13 = r6.length()
            int[] r14 = new int[r13]
            if (r13 <= 0) goto L_0x01e4
        L_0x01ce:
            if (r11 >= r13) goto L_0x01db
            r15 = -1
            int r22 = r6.getDimensionPixelSize(r11, r15)
            r14[r11] = r22
            int r11 = r11 + 1
            r15 = 2
            goto L_0x01ce
        L_0x01db:
            int[] r11 = i.C0064j0.b(r14)
            r9.f = r11
            r9.i()
        L_0x01e4:
            r6.recycle()
        L_0x01e7:
            r5.recycle()
            boolean r5 = r9.j()
            if (r5 == 0) goto L_0x0227
            int r5 = r9.f1335a
            r13 = 1
            if (r5 != r13) goto L_0x022a
            boolean r5 = r9.f1339g
            if (r5 != 0) goto L_0x0223
            android.content.res.Resources r5 = r12.getResources()
            android.util.DisplayMetrics r5 = r5.getDisplayMetrics()
            int r6 = (r2 > r25 ? 1 : (r2 == r25 ? 0 : -1))
            if (r6 != 0) goto L_0x020d
            r2 = 1094713344(0x41400000, float:12.0)
            r15 = 2
            float r2 = android.util.TypedValue.applyDimension(r15, r2, r5)
            goto L_0x020e
        L_0x020d:
            r15 = 2
        L_0x020e:
            int r6 = (r18 > r25 ? 1 : (r18 == r25 ? 0 : -1))
            if (r6 != 0) goto L_0x0218
            r6 = 1121976320(0x42e00000, float:112.0)
            float r18 = android.util.TypedValue.applyDimension(r15, r6, r5)
        L_0x0218:
            r5 = r18
            int r6 = (r1 > r25 ? 1 : (r1 == r25 ? 0 : -1))
            if (r6 != 0) goto L_0x0220
            r1 = 1065353216(0x3f800000, float:1.0)
        L_0x0220:
            r9.k(r2, r5, r1)
        L_0x0223:
            r9.h()
            goto L_0x022a
        L_0x0227:
            r1 = 0
            r9.f1335a = r1
        L_0x022a:
            boolean r1 = i.n1.f1379c
            if (r1 == 0) goto L_0x025b
            int r1 = r9.f1335a
            if (r1 == 0) goto L_0x025b
            int[] r1 = r9.f
            int r2 = r1.length
            if (r2 <= 0) goto L_0x025b
            int r2 = i.Y.a(r10)
            float r2 = (float) r2
            int r2 = (r2 > r25 ? 1 : (r2 == r25 ? 0 : -1))
            if (r2 == 0) goto L_0x0257
            float r1 = r9.f1337d
            int r1 = java.lang.Math.round(r1)
            float r2 = r9.f1338e
            int r2 = java.lang.Math.round(r2)
            float r5 = r9.f1336c
            int r5 = java.lang.Math.round(r5)
            r6 = 0
            i.Y.b(r10, r1, r2, r5, r6)
            goto L_0x025b
        L_0x0257:
            r6 = 0
            i.Y.c(r10, r1, r6)
        L_0x025b:
            android.content.res.TypedArray r1 = r7.obtainStyledAttributes(r4, r3)
            r2 = 8
            r15 = -1
            int r2 = r1.getResourceId(r2, r15)
            if (r2 == r15) goto L_0x026f
            android.graphics.drawable.Drawable r2 = r8.b(r7, r2)
        L_0x026c:
            r3 = 13
            goto L_0x0271
        L_0x026f:
            r2 = 0
            goto L_0x026c
        L_0x0271:
            int r3 = r1.getResourceId(r3, r15)
            if (r3 == r15) goto L_0x027c
            android.graphics.drawable.Drawable r3 = r8.b(r7, r3)
            goto L_0x027d
        L_0x027c:
            r3 = 0
        L_0x027d:
            r4 = 9
            int r4 = r1.getResourceId(r4, r15)
            if (r4 == r15) goto L_0x028b
            android.graphics.drawable.Drawable r4 = r8.b(r7, r4)
        L_0x0289:
            r5 = 6
            goto L_0x028d
        L_0x028b:
            r4 = 0
            goto L_0x0289
        L_0x028d:
            int r5 = r1.getResourceId(r5, r15)
            if (r5 == r15) goto L_0x0298
            android.graphics.drawable.Drawable r5 = r8.b(r7, r5)
            goto L_0x0299
        L_0x0298:
            r5 = 0
        L_0x0299:
            r6 = 10
            int r6 = r1.getResourceId(r6, r15)
            if (r6 == r15) goto L_0x02a6
            android.graphics.drawable.Drawable r6 = r8.b(r7, r6)
            goto L_0x02a7
        L_0x02a6:
            r6 = 0
        L_0x02a7:
            r9 = 7
            int r9 = r1.getResourceId(r9, r15)
            if (r9 == r15) goto L_0x02b3
            android.graphics.drawable.Drawable r8 = r8.b(r7, r9)
            goto L_0x02b4
        L_0x02b3:
            r8 = 0
        L_0x02b4:
            if (r6 != 0) goto L_0x030b
            if (r8 == 0) goto L_0x02b9
            goto L_0x030b
        L_0x02b9:
            if (r2 != 0) goto L_0x02c1
            if (r3 != 0) goto L_0x02c1
            if (r4 != 0) goto L_0x02c1
            if (r5 == 0) goto L_0x032e
        L_0x02c1:
            android.graphics.drawable.Drawable[] r6 = r10.getCompoundDrawablesRelative()
            r20 = 0
            r8 = r6[r20]
            if (r8 != 0) goto L_0x02d1
            r21 = 2
            r9 = r6[r21]
            if (r9 == 0) goto L_0x02d4
        L_0x02d1:
            r17 = 3
            goto L_0x02f6
        L_0x02d4:
            android.graphics.drawable.Drawable[] r6 = r10.getCompoundDrawables()
            if (r2 == 0) goto L_0x02db
            goto L_0x02dd
        L_0x02db:
            r2 = r6[r20]
        L_0x02dd:
            if (r3 == 0) goto L_0x02e0
            goto L_0x02e4
        L_0x02e0:
            r19 = 1
            r3 = r6[r19]
        L_0x02e4:
            if (r4 == 0) goto L_0x02e7
            goto L_0x02eb
        L_0x02e7:
            r21 = 2
            r4 = r6[r21]
        L_0x02eb:
            if (r5 == 0) goto L_0x02ee
            goto L_0x02f2
        L_0x02ee:
            r17 = 3
            r5 = r6[r17]
        L_0x02f2:
            r10.setCompoundDrawablesWithIntrinsicBounds(r2, r3, r4, r5)
            goto L_0x032e
        L_0x02f6:
            if (r3 == 0) goto L_0x02f9
            goto L_0x02fd
        L_0x02f9:
            r19 = 1
            r3 = r6[r19]
        L_0x02fd:
            if (r5 == 0) goto L_0x0302
        L_0x02ff:
            r21 = 2
            goto L_0x0305
        L_0x0302:
            r5 = r6[r17]
            goto L_0x02ff
        L_0x0305:
            r2 = r6[r21]
            r10.setCompoundDrawablesRelativeWithIntrinsicBounds(r8, r3, r2, r5)
            goto L_0x032e
        L_0x030b:
            android.graphics.drawable.Drawable[] r2 = r10.getCompoundDrawablesRelative()
            if (r6 == 0) goto L_0x0312
            goto L_0x0316
        L_0x0312:
            r20 = 0
            r6 = r2[r20]
        L_0x0316:
            if (r3 == 0) goto L_0x0319
            goto L_0x031d
        L_0x0319:
            r19 = 1
            r3 = r2[r19]
        L_0x031d:
            if (r8 == 0) goto L_0x0320
            goto L_0x0324
        L_0x0320:
            r21 = 2
            r8 = r2[r21]
        L_0x0324:
            if (r5 == 0) goto L_0x0327
            goto L_0x032b
        L_0x0327:
            r17 = 3
            r5 = r2[r17]
        L_0x032b:
            r10.setCompoundDrawablesRelativeWithIntrinsicBounds(r6, r3, r8, r5)
        L_0x032e:
            r2 = 11
            boolean r3 = r1.hasValue(r2)
            if (r3 == 0) goto L_0x0351
            boolean r3 = r1.hasValue(r2)
            if (r3 == 0) goto L_0x034a
            r6 = 0
            int r3 = r1.getResourceId(r2, r6)
            if (r3 == 0) goto L_0x034a
            android.content.res.ColorStateList r3 = D.g.q(r7, r3)
            if (r3 == 0) goto L_0x034a
            goto L_0x034e
        L_0x034a:
            android.content.res.ColorStateList r3 = r1.getColorStateList(r2)
        L_0x034e:
            D.p.f(r10, r3)
        L_0x0351:
            r2 = 12
            boolean r3 = r1.hasValue(r2)
            r15 = -1
            if (r3 == 0) goto L_0x0366
            int r2 = r1.getInt(r2, r15)
            r3 = 0
            android.graphics.PorterDuff$Mode r2 = i.C0074o0.b(r2, r3)
            D.p.g(r10, r2)
        L_0x0366:
            r2 = 15
            int r2 = r1.getDimensionPixelSize(r2, r15)
            r3 = 18
            int r3 = r1.getDimensionPixelSize(r3, r15)
            r4 = 19
            boolean r5 = r1.hasValue(r4)
            if (r5 == 0) goto L_0x0397
            android.util.TypedValue r5 = r1.peekValue(r4)
            if (r5 == 0) goto L_0x038f
            int r6 = r5.type
            r13 = 5
            if (r6 != r13) goto L_0x038f
            int r4 = r5.data
            r5 = r4 & 15
            float r4 = android.util.TypedValue.complexToFloat(r4)
            r15 = -1
            goto L_0x039b
        L_0x038f:
            r15 = -1
            int r4 = r1.getDimensionPixelSize(r4, r15)
            float r4 = (float) r4
        L_0x0395:
            r5 = r15
            goto L_0x039b
        L_0x0397:
            r15 = -1
            r4 = r25
            goto L_0x0395
        L_0x039b:
            r1.recycle()
            if (r2 == r15) goto L_0x03a3
            D.g.P(r10, r2)
        L_0x03a3:
            if (r3 == r15) goto L_0x03a8
            D.g.Q(r10, r3)
        L_0x03a8:
            int r1 = (r4 > r25 ? 1 : (r4 == r25 ? 0 : -1))
            if (r1 == 0) goto L_0x03d0
            if (r5 != r15) goto L_0x03b3
            int r1 = (int) r4
            D.g.R(r10, r1)
            return
        L_0x03b3:
            int r1 = android.os.Build.VERSION.SDK_INT
            r2 = 34
            if (r1 < r2) goto L_0x03bd
            D.s.a(r10, r5, r4)
            return
        L_0x03bd:
            android.content.res.Resources r1 = r10.getResources()
            android.util.DisplayMetrics r1 = r1.getDisplayMetrics()
            float r1 = android.util.TypedValue.applyDimension(r5, r4, r1)
            int r1 = java.lang.Math.round(r1)
            D.g.R(r10, r1)
        L_0x03d0:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: i.C0046a0.f(android.util.AttributeSet, int):void");
    }

    public final void g(Context context, int i2) {
        String string;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(i2, C0010a.f790v);
        h hVar = new h(context, obtainStyledAttributes);
        boolean hasValue = obtainStyledAttributes.hasValue(14);
        TextView textView = this.f1278a;
        if (hasValue) {
            textView.setAllCaps(obtainStyledAttributes.getBoolean(14, false));
        }
        int i3 = Build.VERSION.SDK_INT;
        if (obtainStyledAttributes.hasValue(0) && obtainStyledAttributes.getDimensionPixelSize(0, -1) == 0) {
            textView.setTextSize(0, 0.0f);
        }
        n(context, hVar);
        if (i3 >= 26 && obtainStyledAttributes.hasValue(13) && (string = obtainStyledAttributes.getString(13)) != null) {
            Y.d(textView, string);
        }
        hVar.r();
        Typeface typeface = this.f1287l;
        if (typeface != null) {
            textView.setTypeface(typeface, this.f1285j);
        }
    }

    public final void i(int i2, int i3, int i4, int i5) {
        C0064j0 j0Var = this.f1284i;
        if (j0Var.j()) {
            DisplayMetrics displayMetrics = j0Var.f1342j.getResources().getDisplayMetrics();
            j0Var.k(TypedValue.applyDimension(i5, (float) i2, displayMetrics), TypedValue.applyDimension(i5, (float) i3, displayMetrics), TypedValue.applyDimension(i5, (float) i4, displayMetrics));
            if (j0Var.h()) {
                j0Var.a();
            }
        }
    }

    public final void j(int[] iArr, int i2) {
        C0064j0 j0Var = this.f1284i;
        if (j0Var.j()) {
            int length = iArr.length;
            if (length > 0) {
                int[] iArr2 = new int[length];
                if (i2 == 0) {
                    iArr2 = Arrays.copyOf(iArr, length);
                } else {
                    DisplayMetrics displayMetrics = j0Var.f1342j.getResources().getDisplayMetrics();
                    for (int i3 = 0; i3 < length; i3++) {
                        iArr2[i3] = Math.round(TypedValue.applyDimension(i2, (float) iArr[i3], displayMetrics));
                    }
                }
                j0Var.f = C0064j0.b(iArr2);
                if (!j0Var.i()) {
                    throw new IllegalArgumentException("None of the preset sizes is valid: " + Arrays.toString(iArr));
                }
            } else {
                j0Var.f1339g = false;
            }
            if (j0Var.h()) {
                j0Var.a();
            }
        }
    }

    public final void k(int i2) {
        C0064j0 j0Var = this.f1284i;
        if (!j0Var.j()) {
            return;
        }
        if (i2 == 0) {
            j0Var.f1335a = 0;
            j0Var.f1337d = -1.0f;
            j0Var.f1338e = -1.0f;
            j0Var.f1336c = -1.0f;
            j0Var.f = new int[0];
            j0Var.b = false;
        } else if (i2 == 1) {
            DisplayMetrics displayMetrics = j0Var.f1342j.getResources().getDisplayMetrics();
            j0Var.k(TypedValue.applyDimension(2, 12.0f, displayMetrics), TypedValue.applyDimension(2, 112.0f, displayMetrics), 1.0f);
            if (j0Var.h()) {
                j0Var.a();
            }
        } else {
            throw new IllegalArgumentException("Unknown auto-size text type: " + i2);
        }
    }

    /* JADX WARNING: type inference failed for: r0v2, types: [java.lang.Object, i.V0] */
    public final void l(ColorStateList colorStateList) {
        boolean z2;
        if (this.f1283h == null) {
            this.f1283h = new Object();
        }
        V0 v0 = this.f1283h;
        v0.f1269a = colorStateList;
        if (colorStateList != null) {
            z2 = true;
        } else {
            z2 = false;
        }
        v0.f1271d = z2;
        this.b = v0;
        this.f1279c = v0;
        this.f1280d = v0;
        this.f1281e = v0;
        this.f = v0;
        this.f1282g = v0;
    }

    /* JADX WARNING: type inference failed for: r0v2, types: [java.lang.Object, i.V0] */
    public final void m(PorterDuff.Mode mode) {
        boolean z2;
        if (this.f1283h == null) {
            this.f1283h = new Object();
        }
        V0 v0 = this.f1283h;
        v0.b = mode;
        if (mode != null) {
            z2 = true;
        } else {
            z2 = false;
        }
        v0.f1270c = z2;
        this.b = v0;
        this.f1279c = v0;
        this.f1280d = v0;
        this.f1281e = v0;
        this.f = v0;
        this.f1282g = v0;
    }

    public final void n(Context context, h hVar) {
        String string;
        boolean z2;
        boolean z3;
        int i2 = this.f1285j;
        TypedArray typedArray = (TypedArray) hVar.b;
        this.f1285j = typedArray.getInt(2, i2);
        int i3 = Build.VERSION.SDK_INT;
        if (i3 >= 28) {
            int i4 = typedArray.getInt(11, -1);
            this.f1286k = i4;
            if (i4 != -1) {
                this.f1285j &= 2;
            }
        }
        int i5 = 10;
        boolean z4 = false;
        if (typedArray.hasValue(10) || typedArray.hasValue(12)) {
            this.f1287l = null;
            if (typedArray.hasValue(12)) {
                i5 = 12;
            }
            int i6 = this.f1286k;
            int i7 = this.f1285j;
            if (!context.isRestricted()) {
                try {
                    Typeface k2 = hVar.k(i5, this.f1285j, new V(this, i6, i7, new WeakReference(this.f1278a)));
                    if (k2 != null) {
                        if (i3 < 28 || this.f1286k == -1) {
                            this.f1287l = k2;
                        } else {
                            Typeface create = Typeface.create(k2, 0);
                            int i8 = this.f1286k;
                            if ((this.f1285j & 2) != 0) {
                                z3 = true;
                            } else {
                                z3 = false;
                            }
                            this.f1287l = Z.a(create, i8, z3);
                        }
                    }
                    if (this.f1287l == null) {
                        z2 = true;
                    } else {
                        z2 = false;
                    }
                    this.f1288m = z2;
                } catch (Resources.NotFoundException | UnsupportedOperationException unused) {
                }
            }
            if (this.f1287l == null && (string = typedArray.getString(i5)) != null) {
                if (Build.VERSION.SDK_INT < 28 || this.f1286k == -1) {
                    this.f1287l = Typeface.create(string, this.f1285j);
                    return;
                }
                Typeface create2 = Typeface.create(string, 0);
                int i9 = this.f1286k;
                if ((this.f1285j & 2) != 0) {
                    z4 = true;
                }
                this.f1287l = Z.a(create2, i9, z4);
            }
        } else if (typedArray.hasValue(1)) {
            this.f1288m = false;
            int i10 = typedArray.getInt(1, 1);
            if (i10 == 1) {
                this.f1287l = Typeface.SANS_SERIF;
            } else if (i10 == 2) {
                this.f1287l = Typeface.SERIF;
            } else if (i10 == 3) {
                this.f1287l = Typeface.MONOSPACE;
            }
        }
    }
}
