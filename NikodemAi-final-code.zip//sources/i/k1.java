package i;

public abstract class k1 extends P0 {

    /* renamed from: a  reason: collision with root package name */
    public static final /* synthetic */ int f1352a = 0;
}
