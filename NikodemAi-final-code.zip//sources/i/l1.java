package i;

public interface l1 {
}
