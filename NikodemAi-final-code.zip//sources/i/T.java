package i;

import D.g;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Parcelable;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.ListAdapter;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.ThemedSpinnerAdapter;
import h.C0041d;

public final class T extends Spinner {

    /* renamed from: i  reason: collision with root package name */
    public static final int[] f1253i = {16843505};

    /* renamed from: a  reason: collision with root package name */
    public final C0077q f1254a;
    public final Context b;

    /* renamed from: c  reason: collision with root package name */
    public final J f1255c;

    /* renamed from: d  reason: collision with root package name */
    public SpinnerAdapter f1256d;

    /* renamed from: e  reason: collision with root package name */
    public final boolean f1257e;
    public final S f;

    /* renamed from: g  reason: collision with root package name */
    public int f1258g;

    /* renamed from: h  reason: collision with root package name */
    public final Rect f1259h = new Rect();

    /* JADX WARNING: Code restructure failed: missing block: B:21:0x0060, code lost:
        if (r7 != null) goto L_0x0050;
     */
    /* JADX WARNING: Removed duplicated region for block: B:36:0x00d7  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public T(android.content.Context r13, android.util.AttributeSet r14) {
        /*
            r12 = this;
            r0 = 2130903273(0x7f0300e9, float:1.741336E38)
            r12.<init>(r13, r14, r0)
            android.graphics.Rect r1 = new android.graphics.Rect
            r1.<init>()
            r12.f1259h = r1
            android.content.Context r1 = r12.getContext()
            i.T0.a(r12, r1)
            int[] r1 = d.C0010a.f789u
            C.h r2 = C.h.m(r13, r14, r1, r0)
            i.q r3 = new i.q
            r3.<init>(r12)
            r12.f1254a = r3
            java.lang.Object r3 = r2.b
            android.content.res.TypedArray r3 = (android.content.res.TypedArray) r3
            r4 = 4
            r5 = 0
            int r4 = r3.getResourceId(r4, r5)
            if (r4 == 0) goto L_0x0035
            g.c r6 = new g.c
            r6.<init>(r13, r4)
            r12.b = r6
            goto L_0x0037
        L_0x0035:
            r12.b = r13
        L_0x0037:
            r4 = -1
            r6 = 0
            int[] r7 = f1253i     // Catch:{ Exception -> 0x0057, all -> 0x0054 }
            android.content.res.TypedArray r7 = r13.obtainStyledAttributes(r14, r7, r0, r5)     // Catch:{ Exception -> 0x0057, all -> 0x0054 }
            boolean r8 = r7.hasValue(r5)     // Catch:{ Exception -> 0x004e }
            if (r8 == 0) goto L_0x0050
            int r4 = r7.getInt(r5, r5)     // Catch:{ Exception -> 0x004e }
            goto L_0x0050
        L_0x004a:
            r13 = move-exception
            r6 = r7
            goto L_0x00d5
        L_0x004e:
            r8 = move-exception
            goto L_0x0059
        L_0x0050:
            r7.recycle()
            goto L_0x0063
        L_0x0054:
            r13 = move-exception
            goto L_0x00d5
        L_0x0057:
            r8 = move-exception
            r7 = r6
        L_0x0059:
            java.lang.String r9 = "AppCompatSpinner"
            java.lang.String r10 = "Could not read android:spinnerMode"
            android.util.Log.i(r9, r10, r8)     // Catch:{ all -> 0x004a }
            if (r7 == 0) goto L_0x0063
            goto L_0x0050
        L_0x0063:
            r7 = 2
            r8 = 1
            if (r4 == 0) goto L_0x009d
            if (r4 == r8) goto L_0x006a
            goto L_0x00aa
        L_0x006a:
            i.P r4 = new i.P
            android.content.Context r9 = r12.b
            r4.<init>(r12, r9, r14)
            android.content.Context r9 = r12.b
            C.h r1 = C.h.m(r9, r14, r1, r0)
            r9 = 3
            r10 = -2
            java.lang.Object r11 = r1.b
            android.content.res.TypedArray r11 = (android.content.res.TypedArray) r11
            int r9 = r11.getLayoutDimension(r9, r10)
            r12.f1258g = r9
            android.graphics.drawable.Drawable r9 = r1.i(r8)
            r4.j(r9)
            java.lang.String r7 = r3.getString(r7)
            r4.f1241B = r7
            r1.r()
            r12.f = r4
            i.J r1 = new i.J
            r1.<init>(r12, r12, r4)
            r12.f1255c = r1
            goto L_0x00aa
        L_0x009d:
            i.L r1 = new i.L
            r1.<init>(r12)
            r12.f = r1
            java.lang.String r4 = r3.getString(r7)
            r1.f1224d = r4
        L_0x00aa:
            java.lang.CharSequence[] r1 = r3.getTextArray(r5)
            if (r1 == 0) goto L_0x00c1
            android.widget.ArrayAdapter r3 = new android.widget.ArrayAdapter
            r4 = 17367048(0x1090008, float:2.5162948E-38)
            r3.<init>(r13, r4, r1)
            r13 = 2131427372(0x7f0b002c, float:1.8476358E38)
            r3.setDropDownViewResource(r13)
            r12.setAdapter((android.widget.SpinnerAdapter) r3)
        L_0x00c1:
            r2.r()
            r12.f1257e = r8
            android.widget.SpinnerAdapter r13 = r12.f1256d
            if (r13 == 0) goto L_0x00cf
            r12.setAdapter((android.widget.SpinnerAdapter) r13)
            r12.f1256d = r6
        L_0x00cf:
            i.q r13 = r12.f1254a
            r13.d(r14, r0)
            return
        L_0x00d5:
            if (r6 == 0) goto L_0x00da
            r6.recycle()
        L_0x00da:
            throw r13
        */
        throw new UnsupportedOperationException("Method not decompiled: i.T.<init>(android.content.Context, android.util.AttributeSet):void");
    }

    public final int a(SpinnerAdapter spinnerAdapter, Drawable drawable) {
        int i2 = 0;
        if (spinnerAdapter == null) {
            return 0;
        }
        int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 0);
        int makeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 0);
        int max = Math.max(0, getSelectedItemPosition());
        int min = Math.min(spinnerAdapter.getCount(), max + 15);
        View view = null;
        int i3 = 0;
        for (int max2 = Math.max(0, max - (15 - (min - max))); max2 < min; max2++) {
            int itemViewType = spinnerAdapter.getItemViewType(max2);
            if (itemViewType != i2) {
                view = null;
                i2 = itemViewType;
            }
            view = spinnerAdapter.getView(max2, view, this);
            if (view.getLayoutParams() == null) {
                view.setLayoutParams(new ViewGroup.LayoutParams(-2, -2));
            }
            view.measure(makeMeasureSpec, makeMeasureSpec2);
            i3 = Math.max(i3, view.getMeasuredWidth());
        }
        if (drawable == null) {
            return i3;
        }
        Rect rect = this.f1259h;
        drawable.getPadding(rect);
        return rect.left + rect.right + i3;
    }

    public final void drawableStateChanged() {
        super.drawableStateChanged();
        C0077q qVar = this.f1254a;
        if (qVar != null) {
            qVar.a();
        }
    }

    public int getDropDownHorizontalOffset() {
        S s2 = this.f;
        if (s2 != null) {
            return s2.d();
        }
        return super.getDropDownHorizontalOffset();
    }

    public int getDropDownVerticalOffset() {
        S s2 = this.f;
        if (s2 != null) {
            return s2.i();
        }
        return super.getDropDownVerticalOffset();
    }

    public int getDropDownWidth() {
        if (this.f != null) {
            return this.f1258g;
        }
        return super.getDropDownWidth();
    }

    public final S getInternalPopup() {
        return this.f;
    }

    public Drawable getPopupBackground() {
        S s2 = this.f;
        if (s2 != null) {
            return s2.l();
        }
        return super.getPopupBackground();
    }

    public Context getPopupContext() {
        return this.b;
    }

    public CharSequence getPrompt() {
        S s2 = this.f;
        if (s2 != null) {
            return s2.b();
        }
        return super.getPrompt();
    }

    public ColorStateList getSupportBackgroundTintList() {
        C0077q qVar = this.f1254a;
        if (qVar != null) {
            return qVar.b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0077q qVar = this.f1254a;
        if (qVar != null) {
            return qVar.c();
        }
        return null;
    }

    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        S s2 = this.f;
        if (s2 != null && s2.a()) {
            s2.dismiss();
        }
    }

    public final void onMeasure(int i2, int i3) {
        super.onMeasure(i2, i3);
        if (this.f != null && View.MeasureSpec.getMode(i2) == Integer.MIN_VALUE) {
            setMeasuredDimension(Math.min(Math.max(getMeasuredWidth(), a(getAdapter(), getBackground())), View.MeasureSpec.getSize(i2)), getMeasuredHeight());
        }
    }

    public final void onRestoreInstanceState(Parcelable parcelable) {
        ViewTreeObserver viewTreeObserver;
        Q q2 = (Q) parcelable;
        super.onRestoreInstanceState(q2.getSuperState());
        if (q2.f1246a && (viewTreeObserver = getViewTreeObserver()) != null) {
            viewTreeObserver.addOnGlobalLayoutListener(new C0041d(2, this));
        }
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [android.view.View$BaseSavedState, android.os.Parcelable, i.Q] */
    public final Parcelable onSaveInstanceState() {
        boolean z2;
        ? baseSavedState = new View.BaseSavedState(super.onSaveInstanceState());
        S s2 = this.f;
        if (s2 == null || !s2.a()) {
            z2 = false;
        } else {
            z2 = true;
        }
        baseSavedState.f1246a = z2;
        return baseSavedState;
    }

    public final boolean onTouchEvent(MotionEvent motionEvent) {
        J j2 = this.f1255c;
        if (j2 == null || !j2.onTouch(this, motionEvent)) {
            return super.onTouchEvent(motionEvent);
        }
        return true;
    }

    public final boolean performClick() {
        S s2 = this.f;
        if (s2 == null) {
            return super.performClick();
        }
        if (s2.a()) {
            return true;
        }
        this.f.e(getTextDirection(), getTextAlignment());
        return true;
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0077q qVar = this.f1254a;
        if (qVar != null) {
            qVar.e();
        }
    }

    public void setBackgroundResource(int i2) {
        super.setBackgroundResource(i2);
        C0077q qVar = this.f1254a;
        if (qVar != null) {
            qVar.f(i2);
        }
    }

    public void setDropDownHorizontalOffset(int i2) {
        S s2 = this.f;
        if (s2 != null) {
            s2.n(i2);
            s2.c(i2);
            return;
        }
        super.setDropDownHorizontalOffset(i2);
    }

    public void setDropDownVerticalOffset(int i2) {
        S s2 = this.f;
        if (s2 != null) {
            s2.k(i2);
        } else {
            super.setDropDownVerticalOffset(i2);
        }
    }

    public void setDropDownWidth(int i2) {
        if (this.f != null) {
            this.f1258g = i2;
        } else {
            super.setDropDownWidth(i2);
        }
    }

    public void setPopupBackgroundDrawable(Drawable drawable) {
        S s2 = this.f;
        if (s2 != null) {
            s2.j(drawable);
        } else {
            super.setPopupBackgroundDrawable(drawable);
        }
    }

    public void setPopupBackgroundResource(int i2) {
        setPopupBackgroundDrawable(g.s(getPopupContext(), i2));
    }

    public void setPrompt(CharSequence charSequence) {
        S s2 = this.f;
        if (s2 != null) {
            s2.g(charSequence);
        } else {
            super.setPrompt(charSequence);
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C0077q qVar = this.f1254a;
        if (qVar != null) {
            qVar.h(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C0077q qVar = this.f1254a;
        if (qVar != null) {
            qVar.i(mode);
        }
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [android.widget.ListAdapter, i.M, java.lang.Object] */
    public void setAdapter(SpinnerAdapter spinnerAdapter) {
        if (!this.f1257e) {
            this.f1256d = spinnerAdapter;
            return;
        }
        super.setAdapter(spinnerAdapter);
        S s2 = this.f;
        if (s2 != null) {
            Context context = this.b;
            if (context == null) {
                context = getContext();
            }
            Resources.Theme theme = context.getTheme();
            ? obj = new Object();
            obj.f1230a = spinnerAdapter;
            if (spinnerAdapter instanceof ListAdapter) {
                obj.b = (ListAdapter) spinnerAdapter;
            }
            if (theme != null && (spinnerAdapter instanceof ThemedSpinnerAdapter)) {
                K.a((ThemedSpinnerAdapter) spinnerAdapter, theme);
            }
            s2.m(obj);
        }
    }
}
