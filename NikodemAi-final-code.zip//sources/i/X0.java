package i;

import androidx.appcompat.widget.Toolbar;
import h.p;

public final /* synthetic */ class X0 implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f1274a;
    public final /* synthetic */ Toolbar b;

    public /* synthetic */ X0(Toolbar toolbar, int i2) {
        this.f1274a = i2;
        this.b = toolbar;
    }

    public final void run() {
        p pVar;
        switch (this.f1274a) {
            case 0:
                a1 a1Var = this.b.f468L;
                if (a1Var == null) {
                    pVar = null;
                } else {
                    pVar = a1Var.b;
                }
                if (pVar != null) {
                    pVar.collapseActionView();
                    return;
                }
                return;
            default:
                this.b.m();
                return;
        }
    }
}
