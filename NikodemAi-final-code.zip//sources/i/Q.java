package i;

import D.m;
import android.os.Parcel;
import android.os.Parcelable;
import android.view.View;

public final class Q extends View.BaseSavedState {
    public static final Parcelable.Creator<Q> CREATOR = new m(9);

    /* renamed from: a  reason: collision with root package name */
    public boolean f1246a;

    public final void writeToParcel(Parcel parcel, int i2) {
        super.writeToParcel(parcel, i2);
        parcel.writeByte(this.f1246a ? (byte) 1 : 0);
    }
}
