package i;

import C.h;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.LinearLayout;
import d.C0010a;
import y.K;

/* renamed from: i.z0  reason: case insensitive filesystem */
public abstract class C0095z0 extends ViewGroup {

    /* renamed from: a  reason: collision with root package name */
    public boolean f1433a = true;
    public int b = -1;

    /* renamed from: c  reason: collision with root package name */
    public int f1434c = 0;

    /* renamed from: d  reason: collision with root package name */
    public int f1435d;

    /* renamed from: e  reason: collision with root package name */
    public int f1436e = 8388659;
    public int f;

    /* renamed from: g  reason: collision with root package name */
    public float f1437g;

    /* renamed from: h  reason: collision with root package name */
    public boolean f1438h;

    /* renamed from: i  reason: collision with root package name */
    public int[] f1439i;

    /* renamed from: j  reason: collision with root package name */
    public int[] f1440j;

    /* renamed from: k  reason: collision with root package name */
    public Drawable f1441k;

    /* renamed from: l  reason: collision with root package name */
    public int f1442l;

    /* renamed from: m  reason: collision with root package name */
    public int f1443m;

    /* renamed from: n  reason: collision with root package name */
    public int f1444n;

    /* renamed from: o  reason: collision with root package name */
    public int f1445o;

    public C0095z0(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        int[] iArr = C0010a.f782n;
        h m2 = h.m(context, attributeSet, iArr, 0);
        K.g(this, context, iArr, attributeSet, (TypedArray) m2.b, 0);
        TypedArray typedArray = (TypedArray) m2.b;
        int i2 = typedArray.getInt(1, -1);
        if (i2 >= 0) {
            setOrientation(i2);
        }
        int i3 = typedArray.getInt(0, -1);
        if (i3 >= 0) {
            setGravity(i3);
        }
        boolean z2 = typedArray.getBoolean(2, true);
        if (!z2) {
            setBaselineAligned(z2);
        }
        this.f1437g = typedArray.getFloat(4, -1.0f);
        this.b = typedArray.getInt(3, -1);
        this.f1438h = typedArray.getBoolean(7, false);
        setDividerDrawable(m2.i(5));
        this.f1444n = typedArray.getInt(8, 0);
        this.f1445o = typedArray.getDimensionPixelSize(6, 0);
        m2.r();
    }

    public final void c(Canvas canvas, int i2) {
        this.f1441k.setBounds(getPaddingLeft() + this.f1445o, i2, (getWidth() - getPaddingRight()) - this.f1445o, this.f1443m + i2);
        this.f1441k.draw(canvas);
    }

    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof C0093y0;
    }

    public final void d(Canvas canvas, int i2) {
        this.f1441k.setBounds(i2, getPaddingTop() + this.f1445o, this.f1442l + i2, (getHeight() - getPaddingBottom()) - this.f1445o);
        this.f1441k.draw(canvas);
    }

    /* JADX WARNING: type inference failed for: r0v2, types: [android.widget.LinearLayout$LayoutParams, i.y0] */
    /* JADX WARNING: type inference failed for: r0v3, types: [android.widget.LinearLayout$LayoutParams, i.y0] */
    /* renamed from: e */
    public C0093y0 generateDefaultLayoutParams() {
        int i2 = this.f1435d;
        if (i2 == 0) {
            return new LinearLayout.LayoutParams(-2, -2);
        }
        if (i2 == 1) {
            return new LinearLayout.LayoutParams(-1, -2);
        }
        return null;
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [android.widget.LinearLayout$LayoutParams, i.y0] */
    /* renamed from: f */
    public C0093y0 generateLayoutParams(AttributeSet attributeSet) {
        return new LinearLayout.LayoutParams(getContext(), attributeSet);
    }

    /* JADX WARNING: type inference failed for: r0v2, types: [android.widget.LinearLayout$LayoutParams, i.y0] */
    /* JADX WARNING: type inference failed for: r0v3, types: [android.widget.LinearLayout$LayoutParams, i.y0] */
    /* JADX WARNING: type inference failed for: r0v4, types: [android.widget.LinearLayout$LayoutParams, i.y0] */
    /* renamed from: g */
    public C0093y0 generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams instanceof C0093y0) {
            return new LinearLayout.LayoutParams((C0093y0) layoutParams);
        }
        if (layoutParams instanceof ViewGroup.MarginLayoutParams) {
            return new LinearLayout.LayoutParams((ViewGroup.MarginLayoutParams) layoutParams);
        }
        return new LinearLayout.LayoutParams(layoutParams);
    }

    public int getBaseline() {
        int i2;
        if (this.b < 0) {
            return super.getBaseline();
        }
        int childCount = getChildCount();
        int i3 = this.b;
        if (childCount > i3) {
            View childAt = getChildAt(i3);
            int baseline = childAt.getBaseline();
            if (baseline != -1) {
                int i4 = this.f1434c;
                if (this.f1435d == 1 && (i2 = this.f1436e & 112) != 48) {
                    if (i2 == 16) {
                        i4 += ((((getBottom() - getTop()) - getPaddingTop()) - getPaddingBottom()) - this.f) / 2;
                    } else if (i2 == 80) {
                        i4 = ((getBottom() - getTop()) - getPaddingBottom()) - this.f;
                    }
                }
                return i4 + ((C0093y0) childAt.getLayoutParams()).topMargin + baseline;
            } else if (this.b == 0) {
                return -1;
            } else {
                throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout points to a View that doesn't know how to get its baseline.");
            }
        } else {
            throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout set to an index that is out of bounds.");
        }
    }

    public int getBaselineAlignedChildIndex() {
        return this.b;
    }

    public Drawable getDividerDrawable() {
        return this.f1441k;
    }

    public int getDividerPadding() {
        return this.f1445o;
    }

    public int getDividerWidth() {
        return this.f1442l;
    }

    public int getGravity() {
        return this.f1436e;
    }

    public int getOrientation() {
        return this.f1435d;
    }

    public int getShowDividers() {
        return this.f1444n;
    }

    public int getVirtualChildCount() {
        return getChildCount();
    }

    public float getWeightSum() {
        return this.f1437g;
    }

    public final boolean h(int i2) {
        if (i2 == 0) {
            if ((this.f1444n & 1) != 0) {
                return true;
            }
            return false;
        } else if (i2 != getChildCount()) {
            if ((this.f1444n & 2) != 0) {
                for (int i3 = i2 - 1; i3 >= 0; i3--) {
                    if (getChildAt(i3).getVisibility() != 8) {
                        return true;
                    }
                }
            }
            return false;
        } else if ((this.f1444n & 4) != 0) {
            return true;
        } else {
            return false;
        }
    }

    public final void onDraw(Canvas canvas) {
        boolean z2;
        int i2;
        int left;
        int i3;
        int i4;
        int i5;
        if (this.f1441k != null) {
            int i6 = 0;
            if (this.f1435d == 1) {
                int virtualChildCount = getVirtualChildCount();
                while (i6 < virtualChildCount) {
                    View childAt = getChildAt(i6);
                    if (!(childAt == null || childAt.getVisibility() == 8 || !h(i6))) {
                        c(canvas, (childAt.getTop() - ((C0093y0) childAt.getLayoutParams()).topMargin) - this.f1443m);
                    }
                    i6++;
                }
                if (h(virtualChildCount)) {
                    View childAt2 = getChildAt(virtualChildCount - 1);
                    if (childAt2 == null) {
                        i5 = (getHeight() - getPaddingBottom()) - this.f1443m;
                    } else {
                        i5 = childAt2.getBottom() + ((C0093y0) childAt2.getLayoutParams()).bottomMargin;
                    }
                    c(canvas, i5);
                    return;
                }
                return;
            }
            int virtualChildCount2 = getVirtualChildCount();
            boolean z3 = n1.f1378a;
            if (getLayoutDirection() == 1) {
                z2 = true;
            } else {
                z2 = false;
            }
            while (i6 < virtualChildCount2) {
                View childAt3 = getChildAt(i6);
                if (!(childAt3 == null || childAt3.getVisibility() == 8 || !h(i6))) {
                    C0093y0 y0Var = (C0093y0) childAt3.getLayoutParams();
                    if (z2) {
                        i4 = childAt3.getRight() + y0Var.rightMargin;
                    } else {
                        i4 = (childAt3.getLeft() - y0Var.leftMargin) - this.f1442l;
                    }
                    d(canvas, i4);
                }
                i6++;
            }
            if (h(virtualChildCount2)) {
                View childAt4 = getChildAt(virtualChildCount2 - 1);
                if (childAt4 != null) {
                    C0093y0 y0Var2 = (C0093y0) childAt4.getLayoutParams();
                    if (z2) {
                        left = childAt4.getLeft() - y0Var2.leftMargin;
                        i3 = this.f1442l;
                    } else {
                        i2 = childAt4.getRight() + y0Var2.rightMargin;
                        d(canvas, i2);
                    }
                } else if (z2) {
                    i2 = getPaddingLeft();
                    d(canvas, i2);
                } else {
                    left = getWidth() - getPaddingRight();
                    i3 = this.f1442l;
                }
                i2 = left - i3;
                d(canvas, i2);
            }
        }
    }

    public final void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName("androidx.appcompat.widget.LinearLayoutCompat");
    }

    public final void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName("androidx.appcompat.widget.LinearLayoutCompat");
    }

    /* JADX WARNING: Removed duplicated region for block: B:27:0x009d  */
    /* JADX WARNING: Removed duplicated region for block: B:60:0x0159  */
    /* JADX WARNING: Removed duplicated region for block: B:63:0x0162  */
    /* JADX WARNING: Removed duplicated region for block: B:75:0x0190  */
    /* JADX WARNING: Removed duplicated region for block: B:78:0x01a3  */
    /* JADX WARNING: Removed duplicated region for block: B:79:0x01a8  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onLayout(boolean r23, int r24, int r25, int r26, int r27) {
        /*
            r22 = this;
            r0 = r22
            int r1 = r0.f1435d
            r2 = 5
            r3 = 8
            r5 = 80
            r6 = 2
            r7 = 16
            r8 = 8388615(0x800007, float:1.1754953E-38)
            r9 = 1
            if (r1 != r9) goto L_0x00b4
            int r1 = r0.getPaddingLeft()
            int r10 = r26 - r24
            int r11 = r0.getPaddingRight()
            int r11 = r10 - r11
            int r10 = r10 - r1
            int r12 = r0.getPaddingRight()
            int r10 = r10 - r12
            int r12 = r0.getVirtualChildCount()
            int r13 = r0.f1436e
            r14 = r13 & 112(0x70, float:1.57E-43)
            r8 = r8 & r13
            if (r14 == r7) goto L_0x0042
            if (r14 == r5) goto L_0x0036
            int r5 = r0.getPaddingTop()
            goto L_0x004d
        L_0x0036:
            int r5 = r0.getPaddingTop()
            int r5 = r5 + r27
            int r5 = r5 - r25
            int r7 = r0.f
            int r5 = r5 - r7
            goto L_0x004d
        L_0x0042:
            int r5 = r0.getPaddingTop()
            int r7 = r27 - r25
            int r13 = r0.f
            int r7 = r7 - r13
            int r7 = r7 / r6
            int r5 = r5 + r7
        L_0x004d:
            r4 = 0
        L_0x004e:
            if (r4 >= r12) goto L_0x01cb
            android.view.View r7 = r0.getChildAt(r4)
            if (r7 != 0) goto L_0x0059
        L_0x0056:
            r23 = r6
            goto L_0x00ae
        L_0x0059:
            int r13 = r7.getVisibility()
            if (r13 == r3) goto L_0x0056
            int r13 = r7.getMeasuredWidth()
            int r14 = r7.getMeasuredHeight()
            android.view.ViewGroup$LayoutParams r15 = r7.getLayoutParams()
            i.y0 r15 = (i.C0093y0) r15
            r23 = r6
            int r6 = r15.gravity
            if (r6 >= 0) goto L_0x0074
            r6 = r8
        L_0x0074:
            int r3 = r0.getLayoutDirection()
            int r3 = android.view.Gravity.getAbsoluteGravity(r6, r3)
            r3 = r3 & 7
            if (r3 == r9) goto L_0x008c
            if (r3 == r2) goto L_0x0086
            int r3 = r15.leftMargin
            int r3 = r3 + r1
            goto L_0x0097
        L_0x0086:
            int r3 = r11 - r13
            int r6 = r15.rightMargin
        L_0x008a:
            int r3 = r3 - r6
            goto L_0x0097
        L_0x008c:
            int r3 = r10 - r13
            int r3 = r3 / 2
            int r3 = r3 + r1
            int r6 = r15.leftMargin
            int r3 = r3 + r6
            int r6 = r15.rightMargin
            goto L_0x008a
        L_0x0097:
            boolean r6 = r0.h(r4)
            if (r6 == 0) goto L_0x00a0
            int r6 = r0.f1443m
            int r5 = r5 + r6
        L_0x00a0:
            int r6 = r15.topMargin
            int r5 = r5 + r6
            int r13 = r13 + r3
            int r6 = r5 + r14
            r7.layout(r3, r5, r13, r6)
            int r3 = r15.bottomMargin
            int r14 = r14 + r3
            int r14 = r14 + r5
            r5 = r14
        L_0x00ae:
            int r4 = r4 + r9
            r6 = r23
            r3 = 8
            goto L_0x004e
        L_0x00b4:
            r23 = r6
            boolean r1 = i.n1.f1378a
            int r1 = r0.getLayoutDirection()
            if (r1 != r9) goto L_0x00c0
            r1 = r9
            goto L_0x00c1
        L_0x00c0:
            r1 = 0
        L_0x00c1:
            int r3 = r0.getPaddingTop()
            int r6 = r27 - r25
            int r10 = r0.getPaddingBottom()
            int r10 = r6 - r10
            int r6 = r6 - r3
            int r11 = r0.getPaddingBottom()
            int r6 = r6 - r11
            int r11 = r0.getVirtualChildCount()
            int r12 = r0.f1436e
            r8 = r8 & r12
            r12 = r12 & 112(0x70, float:1.57E-43)
            boolean r13 = r0.f1433a
            int[] r14 = r0.f1439i
            int[] r15 = r0.f1440j
            int r4 = r0.getLayoutDirection()
            int r4 = android.view.Gravity.getAbsoluteGravity(r8, r4)
            if (r4 == r9) goto L_0x00ff
            if (r4 == r2) goto L_0x00f3
            int r2 = r0.getPaddingLeft()
            goto L_0x010b
        L_0x00f3:
            int r2 = r0.getPaddingLeft()
            int r2 = r2 + r26
            int r2 = r2 - r24
            int r4 = r0.f
            int r2 = r2 - r4
            goto L_0x010b
        L_0x00ff:
            int r2 = r0.getPaddingLeft()
            int r4 = r26 - r24
            int r8 = r0.f
            int r4 = r4 - r8
            int r4 = r4 / 2
            int r2 = r2 + r4
        L_0x010b:
            if (r1 == 0) goto L_0x0111
            int r1 = r11 + -1
            r8 = -1
            goto L_0x0113
        L_0x0111:
            r8 = r9
            r1 = 0
        L_0x0113:
            r17 = r9
            r9 = 0
        L_0x0116:
            if (r9 >= r11) goto L_0x01cb
            int r18 = r8 * r9
            int r5 = r18 + r1
            android.view.View r7 = r0.getChildAt(r5)
            if (r7 != 0) goto L_0x0128
            r25 = r1
        L_0x0124:
            r19 = r3
            goto L_0x01bf
        L_0x0128:
            int r4 = r7.getVisibility()
            r25 = r1
            r1 = 8
            if (r4 == r1) goto L_0x01bb
            int r4 = r7.getMeasuredWidth()
            int r16 = r7.getMeasuredHeight()
            android.view.ViewGroup$LayoutParams r19 = r7.getLayoutParams()
            r1 = r19
            i.y0 r1 = (i.C0093y0) r1
            r27 = r2
            if (r13 == 0) goto L_0x0152
            int r2 = r1.height
            r19 = r3
            r3 = -1
            if (r2 == r3) goto L_0x0154
            int r3 = r7.getBaseline()
            goto L_0x0155
        L_0x0152:
            r19 = r3
        L_0x0154:
            r3 = -1
        L_0x0155:
            int r2 = r1.gravity
            if (r2 >= 0) goto L_0x015a
            r2 = r12
        L_0x015a:
            r2 = r2 & 112(0x70, float:1.57E-43)
            r20 = r4
            r4 = 16
            if (r2 == r4) goto L_0x0190
            r4 = 48
            if (r2 == r4) goto L_0x0182
            r4 = 80
            if (r2 == r4) goto L_0x016e
            r2 = r19
            r4 = -1
            goto L_0x019d
        L_0x016e:
            int r2 = r10 - r16
            int r4 = r1.bottomMargin
            int r2 = r2 - r4
            r4 = -1
            if (r3 == r4) goto L_0x019d
            int r21 = r7.getMeasuredHeight()
            int r21 = r21 - r3
            r3 = r15[r23]
            int r3 = r3 - r21
        L_0x0180:
            int r2 = r2 - r3
            goto L_0x019d
        L_0x0182:
            r4 = -1
            int r2 = r1.topMargin
            int r2 = r19 + r2
            if (r3 == r4) goto L_0x019d
            r21 = r14[r17]
            int r21 = r21 - r3
            int r2 = r21 + r2
            goto L_0x019d
        L_0x0190:
            r4 = -1
            int r2 = r6 - r16
            int r2 = r2 / 2
            int r2 = r2 + r19
            int r3 = r1.topMargin
            int r2 = r2 + r3
            int r3 = r1.bottomMargin
            goto L_0x0180
        L_0x019d:
            boolean r3 = r0.h(r5)
            if (r3 == 0) goto L_0x01a8
            int r3 = r0.f1442l
            int r3 = r27 + r3
            goto L_0x01aa
        L_0x01a8:
            r3 = r27
        L_0x01aa:
            int r5 = r1.leftMargin
            int r3 = r3 + r5
            int r5 = r3 + r20
            int r4 = r2 + r16
            r7.layout(r3, r2, r5, r4)
            int r1 = r1.rightMargin
            int r4 = r20 + r1
            int r4 = r4 + r3
            r2 = r4
            goto L_0x01bf
        L_0x01bb:
            r27 = r2
            goto L_0x0124
        L_0x01bf:
            int r9 = r9 + 1
            r1 = r25
            r3 = r19
            r5 = 80
            r7 = 16
            goto L_0x0116
        L_0x01cb:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: i.C0095z0.onLayout(boolean, int, int, int, int):void");
    }

    /* JADX WARNING: Removed duplicated region for block: B:216:0x04df  */
    /* JADX WARNING: Removed duplicated region for block: B:217:0x04e4  */
    /* JADX WARNING: Removed duplicated region for block: B:220:0x04f9  */
    /* JADX WARNING: Removed duplicated region for block: B:226:0x0527  */
    /* JADX WARNING: Removed duplicated region for block: B:231:0x0534  */
    /* JADX WARNING: Removed duplicated region for block: B:232:0x0537  */
    /* JADX WARNING: Removed duplicated region for block: B:235:0x053e  */
    /* JADX WARNING: Removed duplicated region for block: B:238:0x0548  */
    /* JADX WARNING: Removed duplicated region for block: B:342:0x077b  */
    /* JADX WARNING: Removed duplicated region for block: B:346:0x079d  */
    /* JADX WARNING: Removed duplicated region for block: B:61:0x013f  */
    /* JADX WARNING: Removed duplicated region for block: B:64:0x0148  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onMeasure(int r39, int r40) {
        /*
            r38 = this;
            r0 = r38
            int r1 = r0.f1435d
            r7 = -2
            r8 = 1073741824(0x40000000, float:2.0)
            r9 = 8
            r13 = 0
            r14 = 1
            if (r1 != r14) goto L_0x0350
            r0.f = r13
            int r15 = r0.getVirtualChildCount()
            int r1 = android.view.View.MeasureSpec.getMode(r39)
            int r2 = android.view.View.MeasureSpec.getMode(r40)
            int r3 = r0.b
            boolean r4 = r0.f1438h
            r5 = r13
            r6 = r5
            r12 = r6
            r19 = r12
            r22 = r19
            r23 = r22
            r20 = r14
            r24 = r20
            r16 = 0
            r17 = 16777215(0xffffff, float:2.3509886E-38)
            r18 = 0
            r14 = r23
        L_0x0035:
            if (r5 >= r15) goto L_0x0162
            r25 = r1
            android.view.View r1 = r0.getChildAt(r5)
            if (r1 != 0) goto L_0x0051
            int r1 = r0.f
            r0.f = r1
        L_0x0043:
            r29 = r2
            r7 = r3
            r28 = r4
            r11 = r5
            r10 = r25
            r2 = r39
            r4 = r40
            goto L_0x0153
        L_0x0051:
            int r10 = r1.getVisibility()
            if (r10 != r9) goto L_0x0058
            goto L_0x0043
        L_0x0058:
            boolean r10 = r0.h(r5)
            if (r10 == 0) goto L_0x0065
            int r10 = r0.f
            int r9 = r0.f1443m
            int r10 = r10 + r9
            r0.f = r10
        L_0x0065:
            android.view.ViewGroup$LayoutParams r9 = r1.getLayoutParams()
            i.y0 r9 = (i.C0093y0) r9
            float r10 = r9.weight
            float r16 = r16 + r10
            if (r2 != r8) goto L_0x0098
            int r8 = r9.height
            if (r8 != 0) goto L_0x0098
            int r8 = (r10 > r18 ? 1 : (r10 == r18 ? 0 : -1))
            if (r8 <= 0) goto L_0x0098
            int r8 = r0.f
            int r10 = r9.topMargin
            int r10 = r10 + r8
            int r11 = r9.bottomMargin
            int r10 = r10 + r11
            int r8 = java.lang.Math.max(r8, r10)
            r0.f = r8
            r30 = r1
            r29 = r2
            r7 = r3
            r28 = r4
            r11 = r5
            r19 = r20
            r10 = r25
            r2 = r39
            r4 = r40
            goto L_0x00e6
        L_0x0098:
            int r8 = r9.height
            if (r8 != 0) goto L_0x00a4
            int r8 = (r10 > r18 ? 1 : (r10 == r18 ? 0 : -1))
            if (r8 <= 0) goto L_0x00a4
            r9.height = r7
            r8 = 0
            goto L_0x00a6
        L_0x00a4:
            r8 = -2147483648(0xffffffff80000000, float:-0.0)
        L_0x00a6:
            int r10 = (r16 > r18 ? 1 : (r16 == r18 ? 0 : -1))
            if (r10 != 0) goto L_0x00b1
            int r10 = r0.f
            r11 = r10
            r10 = r5
            r5 = r11
        L_0x00af:
            r11 = r3
            goto L_0x00b4
        L_0x00b1:
            r10 = r5
            r5 = 0
            goto L_0x00af
        L_0x00b4:
            r3 = 0
            r29 = r2
            r28 = r4
            r7 = r11
            r2 = r39
            r4 = r40
            r11 = r10
            r10 = r25
            r0.measureChildWithMargins(r1, r2, r3, r4, r5)
            r3 = -2147483648(0xffffffff80000000, float:-0.0)
            if (r8 == r3) goto L_0x00ca
            r9.height = r8
        L_0x00ca:
            int r3 = r1.getMeasuredHeight()
            int r5 = r0.f
            int r8 = r5 + r3
            r30 = r1
            int r1 = r9.topMargin
            int r8 = r8 + r1
            int r1 = r9.bottomMargin
            int r8 = r8 + r1
            int r1 = java.lang.Math.max(r5, r8)
            r0.f = r1
            if (r28 == 0) goto L_0x00e6
            int r14 = java.lang.Math.max(r3, r14)
        L_0x00e6:
            if (r7 < 0) goto L_0x00f0
            int r5 = r11 + 1
            if (r7 != r5) goto L_0x00f0
            int r1 = r0.f
            r0.f1434c = r1
        L_0x00f0:
            if (r11 >= r7) goto L_0x00f8
            float r1 = r9.weight
            int r1 = (r1 > r18 ? 1 : (r1 == r18 ? 0 : -1))
            if (r1 > 0) goto L_0x00fb
        L_0x00f8:
            r1 = 1073741824(0x40000000, float:2.0)
            goto L_0x0103
        L_0x00fb:
            java.lang.RuntimeException r1 = new java.lang.RuntimeException
            java.lang.String r2 = "A child of LinearLayout with index less than mBaselineAlignedChildIndex has weight > 0, which won't work.  Either remove the weight, or don't set mBaselineAlignedChildIndex."
            r1.<init>(r2)
            throw r1
        L_0x0103:
            if (r10 == r1) goto L_0x010f
            int r1 = r9.width
            r3 = -1
            if (r1 != r3) goto L_0x010f
            r1 = r20
            r23 = r1
            goto L_0x0110
        L_0x010f:
            r1 = 0
        L_0x0110:
            int r3 = r9.leftMargin
            int r5 = r9.rightMargin
            int r3 = r3 + r5
            int r5 = r30.getMeasuredWidth()
            int r5 = r5 + r3
            int r8 = java.lang.Math.max(r13, r5)
            int r13 = r30.getMeasuredState()
            r30 = r1
            r1 = r22
            int r1 = android.view.View.combineMeasuredStates(r1, r13)
            if (r24 == 0) goto L_0x0136
            int r13 = r9.width
            r22 = r1
            r1 = -1
            if (r13 != r1) goto L_0x0138
            r1 = r20
            goto L_0x0139
        L_0x0136:
            r22 = r1
        L_0x0138:
            r1 = 0
        L_0x0139:
            float r9 = r9.weight
            int r9 = (r9 > r18 ? 1 : (r9 == r18 ? 0 : -1))
            if (r9 <= 0) goto L_0x0148
            if (r30 == 0) goto L_0x0142
            goto L_0x0143
        L_0x0142:
            r3 = r5
        L_0x0143:
            int r12 = java.lang.Math.max(r12, r3)
            goto L_0x0150
        L_0x0148:
            if (r30 == 0) goto L_0x014b
            goto L_0x014c
        L_0x014b:
            r3 = r5
        L_0x014c:
            int r6 = java.lang.Math.max(r6, r3)
        L_0x0150:
            r24 = r1
            r13 = r8
        L_0x0153:
            int r5 = r11 + 1
            r3 = r7
            r1 = r10
            r4 = r28
            r2 = r29
            r7 = -2
            r8 = 1073741824(0x40000000, float:2.0)
            r9 = 8
            goto L_0x0035
        L_0x0162:
            r10 = r1
            r29 = r2
            r28 = r4
            r1 = r22
            r2 = r39
            r4 = r40
            int r3 = r0.f
            if (r3 <= 0) goto L_0x017e
            boolean r3 = r0.h(r15)
            if (r3 == 0) goto L_0x017e
            int r3 = r0.f
            int r5 = r0.f1443m
            int r3 = r3 + r5
            r0.f = r3
        L_0x017e:
            r5 = r29
            if (r28 == 0) goto L_0x01bb
            r3 = -2147483648(0xffffffff80000000, float:-0.0)
            if (r5 == r3) goto L_0x0188
            if (r5 != 0) goto L_0x01bb
        L_0x0188:
            r3 = 0
            r0.f = r3
            r3 = 0
        L_0x018c:
            if (r3 >= r15) goto L_0x01bb
            android.view.View r7 = r0.getChildAt(r3)
            if (r7 != 0) goto L_0x0199
            int r7 = r0.f
            r0.f = r7
            goto L_0x01b8
        L_0x0199:
            int r8 = r7.getVisibility()
            r9 = 8
            if (r8 != r9) goto L_0x01a2
            goto L_0x01b8
        L_0x01a2:
            android.view.ViewGroup$LayoutParams r7 = r7.getLayoutParams()
            i.y0 r7 = (i.C0093y0) r7
            int r8 = r0.f
            int r9 = r8 + r14
            int r11 = r7.topMargin
            int r9 = r9 + r11
            int r7 = r7.bottomMargin
            int r9 = r9 + r7
            int r7 = java.lang.Math.max(r8, r9)
            r0.f = r7
        L_0x01b8:
            int r3 = r3 + 1
            goto L_0x018c
        L_0x01bb:
            int r3 = r0.f
            int r7 = r0.getPaddingTop()
            int r8 = r0.getPaddingBottom()
            int r8 = r8 + r7
            int r8 = r8 + r3
            r0.f = r8
            int r3 = r0.getSuggestedMinimumHeight()
            int r3 = java.lang.Math.max(r8, r3)
            r7 = 0
            int r3 = android.view.View.resolveSizeAndState(r3, r4, r7)
            r7 = r3 & r17
            int r8 = r0.f
            int r7 = r7 - r8
            if (r19 != 0) goto L_0x0220
            if (r7 == 0) goto L_0x01e4
            int r8 = (r16 > r18 ? 1 : (r16 == r18 ? 0 : -1))
            if (r8 <= 0) goto L_0x01e4
            goto L_0x0220
        L_0x01e4:
            int r6 = java.lang.Math.max(r6, r12)
            if (r28 == 0) goto L_0x02f4
            r7 = 1073741824(0x40000000, float:2.0)
            if (r5 == r7) goto L_0x02f4
            r5 = 0
        L_0x01ef:
            if (r5 >= r15) goto L_0x02f4
            android.view.View r7 = r0.getChildAt(r5)
            if (r7 == 0) goto L_0x021d
            int r8 = r7.getVisibility()
            r9 = 8
            if (r8 != r9) goto L_0x0200
            goto L_0x021d
        L_0x0200:
            android.view.ViewGroup$LayoutParams r8 = r7.getLayoutParams()
            i.y0 r8 = (i.C0093y0) r8
            float r8 = r8.weight
            int r8 = (r8 > r18 ? 1 : (r8 == r18 ? 0 : -1))
            if (r8 <= 0) goto L_0x021d
            int r8 = r7.getMeasuredWidth()
            r9 = 1073741824(0x40000000, float:2.0)
            int r8 = android.view.View.MeasureSpec.makeMeasureSpec(r8, r9)
            int r11 = android.view.View.MeasureSpec.makeMeasureSpec(r14, r9)
            r7.measure(r8, r11)
        L_0x021d:
            int r5 = r5 + 1
            goto L_0x01ef
        L_0x0220:
            float r8 = r0.f1437g
            int r9 = (r8 > r18 ? 1 : (r8 == r18 ? 0 : -1))
            if (r9 <= 0) goto L_0x0228
            r16 = r8
        L_0x0228:
            r8 = 0
            r0.f = r8
            r8 = r1
            r1 = 0
        L_0x022d:
            if (r1 >= r15) goto L_0x02e5
            android.view.View r9 = r0.getChildAt(r1)
            int r11 = r9.getVisibility()
            r12 = 8
            if (r11 != r12) goto L_0x023f
            r17 = r1
            goto L_0x02e1
        L_0x023f:
            android.view.ViewGroup$LayoutParams r11 = r9.getLayoutParams()
            i.y0 r11 = (i.C0093y0) r11
            float r12 = r11.weight
            int r14 = (r12 > r18 ? 1 : (r12 == r18 ? 0 : -1))
            if (r14 <= 0) goto L_0x029f
            float r14 = (float) r7
            float r14 = r14 * r12
            float r14 = r14 / r16
            int r14 = (int) r14
            float r16 = r16 - r12
            int r7 = r7 - r14
            int r12 = r0.getPaddingLeft()
            int r17 = r0.getPaddingRight()
            int r17 = r17 + r12
            int r12 = r11.leftMargin
            int r17 = r17 + r12
            int r12 = r11.rightMargin
            int r12 = r17 + r12
            r17 = r1
            int r1 = r11.width
            int r1 = android.view.ViewGroup.getChildMeasureSpec(r2, r12, r1)
            int r12 = r11.height
            if (r12 != 0) goto L_0x0282
            r12 = 1073741824(0x40000000, float:2.0)
            if (r5 == r12) goto L_0x0276
            goto L_0x0284
        L_0x0276:
            if (r14 <= 0) goto L_0x0279
            goto L_0x027a
        L_0x0279:
            r14 = 0
        L_0x027a:
            int r14 = android.view.View.MeasureSpec.makeMeasureSpec(r14, r12)
            r9.measure(r1, r14)
            goto L_0x0294
        L_0x0282:
            r12 = 1073741824(0x40000000, float:2.0)
        L_0x0284:
            int r19 = r9.getMeasuredHeight()
            int r14 = r19 + r14
            if (r14 >= 0) goto L_0x028d
            r14 = 0
        L_0x028d:
            int r14 = android.view.View.MeasureSpec.makeMeasureSpec(r14, r12)
            r9.measure(r1, r14)
        L_0x0294:
            int r1 = r9.getMeasuredState()
            r1 = r1 & -256(0xffffffffffffff00, float:NaN)
            int r8 = android.view.View.combineMeasuredStates(r8, r1)
            goto L_0x02a1
        L_0x029f:
            r17 = r1
        L_0x02a1:
            int r1 = r11.leftMargin
            int r12 = r11.rightMargin
            int r1 = r1 + r12
            int r12 = r9.getMeasuredWidth()
            int r12 = r12 + r1
            int r13 = java.lang.Math.max(r13, r12)
            r14 = 1073741824(0x40000000, float:2.0)
            if (r10 == r14) goto L_0x02bd
            int r14 = r11.width
            r19 = r1
            r1 = -1
            if (r14 != r1) goto L_0x02be
            r12 = r19
            goto L_0x02be
        L_0x02bd:
            r1 = -1
        L_0x02be:
            int r6 = java.lang.Math.max(r6, r12)
            if (r24 == 0) goto L_0x02cb
            int r12 = r11.width
            if (r12 != r1) goto L_0x02cb
            r1 = r20
            goto L_0x02cc
        L_0x02cb:
            r1 = 0
        L_0x02cc:
            int r12 = r0.f
            int r9 = r9.getMeasuredHeight()
            int r9 = r9 + r12
            int r14 = r11.topMargin
            int r9 = r9 + r14
            int r11 = r11.bottomMargin
            int r9 = r9 + r11
            int r9 = java.lang.Math.max(r12, r9)
            r0.f = r9
            r24 = r1
        L_0x02e1:
            int r1 = r17 + 1
            goto L_0x022d
        L_0x02e5:
            int r1 = r0.f
            int r5 = r0.getPaddingTop()
            int r7 = r0.getPaddingBottom()
            int r7 = r7 + r5
            int r7 = r7 + r1
            r0.f = r7
            r1 = r8
        L_0x02f4:
            if (r24 != 0) goto L_0x02fb
            r14 = 1073741824(0x40000000, float:2.0)
            if (r10 == r14) goto L_0x02fb
            goto L_0x02fc
        L_0x02fb:
            r6 = r13
        L_0x02fc:
            int r5 = r0.getPaddingLeft()
            int r7 = r0.getPaddingRight()
            int r7 = r7 + r5
            int r7 = r7 + r6
            int r5 = r0.getSuggestedMinimumWidth()
            int r5 = java.lang.Math.max(r7, r5)
            int r1 = android.view.View.resolveSizeAndState(r5, r2, r1)
            r0.setMeasuredDimension(r1, r3)
            if (r23 == 0) goto L_0x0866
            int r1 = r0.getMeasuredWidth()
            r14 = 1073741824(0x40000000, float:2.0)
            int r2 = android.view.View.MeasureSpec.makeMeasureSpec(r1, r14)
            r13 = 0
        L_0x0322:
            if (r13 >= r15) goto L_0x0866
            android.view.View r1 = r0.getChildAt(r13)
            int r3 = r1.getVisibility()
            r9 = 8
            if (r3 == r9) goto L_0x034b
            android.view.ViewGroup$LayoutParams r3 = r1.getLayoutParams()
            r6 = r3
            i.y0 r6 = (i.C0093y0) r6
            int r3 = r6.width
            r5 = -1
            if (r3 != r5) goto L_0x034b
            int r7 = r6.height
            int r3 = r1.getMeasuredHeight()
            r6.height = r3
            r3 = 0
            r5 = 0
            r0.measureChildWithMargins(r1, r2, r3, r4, r5)
            r6.height = r7
        L_0x034b:
            int r13 = r13 + 1
            r4 = r40
            goto L_0x0322
        L_0x0350:
            r2 = r39
            r3 = r13
            r20 = r14
            r17 = 16777215(0xffffff, float:2.3509886E-38)
            r18 = 0
            r0.f = r3
            int r6 = r0.getVirtualChildCount()
            int r7 = android.view.View.MeasureSpec.getMode(r2)
            int r8 = android.view.View.MeasureSpec.getMode(r40)
            int[] r1 = r0.f1439i
            r9 = 4
            if (r1 == 0) goto L_0x0371
            int[] r1 = r0.f1440j
            if (r1 != 0) goto L_0x0379
        L_0x0371:
            int[] r1 = new int[r9]
            r0.f1439i = r1
            int[] r1 = new int[r9]
            r0.f1440j = r1
        L_0x0379:
            int[] r10 = r0.f1439i
            int[] r11 = r0.f1440j
            r12 = 3
            r26 = -1
            r10[r12] = r26
            r13 = 2
            r10[r13] = r26
            r10[r20] = r26
            r21 = 0
            r10[r21] = r26
            r11[r12] = r26
            r11[r13] = r26
            r11[r20] = r26
            r11[r21] = r26
            boolean r14 = r0.f1433a
            boolean r15 = r0.f1438h
            r1 = 1073741824(0x40000000, float:2.0)
            if (r7 != r1) goto L_0x039e
            r16 = r20
            goto L_0x03a0
        L_0x039e:
            r16 = 0
        L_0x03a0:
            r23 = r9
            r24 = r12
            r28 = r18
            r29 = r20
            r1 = 0
            r3 = 0
            r4 = 0
            r5 = 0
            r9 = 0
            r12 = 0
            r19 = 0
            r22 = 0
        L_0x03b2:
            if (r1 >= r6) goto L_0x0568
            r30 = r13
            android.view.View r13 = r0.getChildAt(r1)
            if (r13 != 0) goto L_0x03cf
            int r13 = r0.f
            r0.f = r13
            r33 = r1
            r1 = r4
            r31 = r10
            r32 = r11
            r34 = r14
            r35 = r15
            r4 = r40
            goto L_0x0558
        L_0x03cf:
            int r2 = r13.getVisibility()
            r31 = r3
            r3 = 8
            if (r2 != r3) goto L_0x03ec
            r2 = r39
            r33 = r1
            r1 = r4
            r32 = r11
            r34 = r14
            r35 = r15
            r3 = r31
            r4 = r40
            r31 = r10
            goto L_0x0558
        L_0x03ec:
            boolean r2 = r0.h(r1)
            if (r2 == 0) goto L_0x03f9
            int r2 = r0.f
            int r3 = r0.f1442l
            int r2 = r2 + r3
            r0.f = r2
        L_0x03f9:
            android.view.ViewGroup$LayoutParams r2 = r13.getLayoutParams()
            i.y0 r2 = (i.C0093y0) r2
            float r3 = r2.weight
            float r28 = r28 + r3
            r32 = r1
            r1 = 1073741824(0x40000000, float:2.0)
            if (r7 != r1) goto L_0x046e
            int r1 = r2.width
            if (r1 != 0) goto L_0x046e
            int r1 = (r3 > r18 ? 1 : (r3 == r18 ? 0 : -1))
            if (r1 <= 0) goto L_0x046e
            if (r16 == 0) goto L_0x0421
            int r1 = r0.f
            int r3 = r2.leftMargin
            r33 = r1
            int r1 = r2.rightMargin
            int r3 = r3 + r1
            int r3 = r3 + r33
            r0.f = r3
            goto L_0x0432
        L_0x0421:
            int r1 = r0.f
            int r3 = r2.leftMargin
            int r3 = r3 + r1
            r33 = r3
            int r3 = r2.rightMargin
            int r3 = r33 + r3
            int r1 = java.lang.Math.max(r1, r3)
            r0.f = r1
        L_0x0432:
            if (r14 == 0) goto L_0x0453
            r3 = 0
            int r1 = android.view.View.MeasureSpec.makeMeasureSpec(r3, r3)
            r13.measure(r1, r1)
            r36 = r13
            r34 = r14
            r35 = r15
            r13 = r31
            r33 = r32
            r14 = r2
            r31 = r10
            r32 = r11
            r2 = r39
            r10 = r4
            r11 = r5
            r4 = r40
            goto L_0x04d6
        L_0x0453:
            r36 = r13
            r34 = r14
            r35 = r15
            r22 = r20
            r13 = r31
            r33 = r32
            r1 = 1073741824(0x40000000, float:2.0)
            r14 = r2
            r31 = r10
            r32 = r11
            r2 = r39
            r10 = r4
            r11 = r5
            r4 = r40
            goto L_0x04d8
        L_0x046e:
            int r1 = r2.width
            if (r1 != 0) goto L_0x047b
            int r1 = (r3 > r18 ? 1 : (r3 == r18 ? 0 : -1))
            if (r1 <= 0) goto L_0x047b
            r1 = -2
            r2.width = r1
            r1 = 0
            goto L_0x047d
        L_0x047b:
            r1 = -2147483648(0xffffffff80000000, float:-0.0)
        L_0x047d:
            int r3 = (r28 > r18 ? 1 : (r28 == r18 ? 0 : -1))
            if (r3 != 0) goto L_0x0486
            int r3 = r0.f
        L_0x0483:
            r33 = r5
            goto L_0x0488
        L_0x0486:
            r3 = 0
            goto L_0x0483
        L_0x0488:
            r5 = 0
            r34 = r32
            r32 = r11
            r11 = r33
            r33 = r34
            r34 = r14
            r35 = r15
            r15 = r1
            r14 = r2
            r1 = r13
            r13 = r31
            r2 = r39
            r31 = r10
            r10 = r4
            r4 = r40
            r0.measureChildWithMargins(r1, r2, r3, r4, r5)
            r3 = -2147483648(0xffffffff80000000, float:-0.0)
            if (r15 == r3) goto L_0x04aa
            r14.width = r15
        L_0x04aa:
            int r3 = r1.getMeasuredWidth()
            if (r16 == 0) goto L_0x04be
            int r5 = r0.f
            int r15 = r14.leftMargin
            int r15 = r15 + r3
            r36 = r1
            int r1 = r14.rightMargin
            int r15 = r15 + r1
            int r15 = r15 + r5
            r0.f = r15
            goto L_0x04d0
        L_0x04be:
            r36 = r1
            int r1 = r0.f
            int r5 = r1 + r3
            int r15 = r14.leftMargin
            int r5 = r5 + r15
            int r15 = r14.rightMargin
            int r5 = r5 + r15
            int r1 = java.lang.Math.max(r1, r5)
            r0.f = r1
        L_0x04d0:
            if (r35 == 0) goto L_0x04d6
            int r9 = java.lang.Math.max(r3, r9)
        L_0x04d6:
            r1 = 1073741824(0x40000000, float:2.0)
        L_0x04d8:
            if (r8 == r1) goto L_0x04e4
            int r1 = r14.height
            r3 = -1
            if (r1 != r3) goto L_0x04e4
            r1 = r20
            r19 = r1
            goto L_0x04e5
        L_0x04e4:
            r1 = 0
        L_0x04e5:
            int r3 = r14.topMargin
            int r5 = r14.bottomMargin
            int r3 = r3 + r5
            int r5 = r36.getMeasuredHeight()
            int r5 = r5 + r3
            int r15 = r36.getMeasuredState()
            int r12 = android.view.View.combineMeasuredStates(r12, r15)
            if (r34 == 0) goto L_0x0527
            int r15 = r36.getBaseline()
            r36 = r1
            r1 = -1
            if (r15 == r1) goto L_0x0529
            int r1 = r14.gravity
            if (r1 >= 0) goto L_0x0508
            int r1 = r0.f1436e
        L_0x0508:
            r1 = r1 & 112(0x70, float:1.57E-43)
            int r1 = r1 >> 4
            r25 = -2
            r1 = r1 & -2
            int r1 = r1 >> 1
            r37 = r1
            r1 = r31[r37]
            int r1 = java.lang.Math.max(r1, r15)
            r31[r37] = r1
            r1 = r32[r37]
            int r15 = r5 - r15
            int r1 = java.lang.Math.max(r1, r15)
            r32[r37] = r1
            goto L_0x0529
        L_0x0527:
            r36 = r1
        L_0x0529:
            int r1 = java.lang.Math.max(r13, r5)
            if (r29 == 0) goto L_0x0537
            int r13 = r14.height
            r15 = -1
            if (r13 != r15) goto L_0x0537
            r13 = r20
            goto L_0x0538
        L_0x0537:
            r13 = 0
        L_0x0538:
            float r14 = r14.weight
            int r14 = (r14 > r18 ? 1 : (r14 == r18 ? 0 : -1))
            if (r14 <= 0) goto L_0x0548
            if (r36 == 0) goto L_0x0541
            goto L_0x0542
        L_0x0541:
            r3 = r5
        L_0x0542:
            int r5 = java.lang.Math.max(r11, r3)
            r3 = r10
            goto L_0x0551
        L_0x0548:
            if (r36 == 0) goto L_0x054b
            goto L_0x054c
        L_0x054b:
            r3 = r5
        L_0x054c:
            int r3 = java.lang.Math.max(r10, r3)
            r5 = r11
        L_0x0551:
            r29 = r3
            r3 = r1
            r1 = r29
            r29 = r13
        L_0x0558:
            int r10 = r33 + 1
            r4 = r1
            r1 = r10
            r13 = r30
            r10 = r31
            r11 = r32
            r14 = r34
            r15 = r35
            goto L_0x03b2
        L_0x0568:
            r31 = r10
            r32 = r11
            r30 = r13
            r34 = r14
            r35 = r15
            r13 = r3
            r10 = r4
            r11 = r5
            r4 = r40
            int r1 = r0.f
            if (r1 <= 0) goto L_0x0588
            boolean r1 = r0.h(r6)
            if (r1 == 0) goto L_0x0588
            int r1 = r0.f
            int r3 = r0.f1442l
            int r1 = r1 + r3
            r0.f = r1
        L_0x0588:
            r1 = r31[r20]
            r3 = -1
            if (r1 != r3) goto L_0x059e
            r21 = 0
            r5 = r31[r21]
            if (r5 != r3) goto L_0x059e
            r5 = r31[r30]
            if (r5 != r3) goto L_0x059e
            r5 = r31[r24]
            if (r5 == r3) goto L_0x059c
            goto L_0x059e
        L_0x059c:
            r3 = r13
            goto L_0x05cb
        L_0x059e:
            r3 = r31[r24]
            r21 = 0
            r5 = r31[r21]
            r14 = r31[r30]
            int r1 = java.lang.Math.max(r1, r14)
            int r1 = java.lang.Math.max(r5, r1)
            int r1 = java.lang.Math.max(r3, r1)
            r3 = r32[r24]
            r5 = r32[r21]
            r14 = r32[r20]
            r15 = r32[r30]
            int r14 = java.lang.Math.max(r14, r15)
            int r5 = java.lang.Math.max(r5, r14)
            int r3 = java.lang.Math.max(r3, r5)
            int r3 = r3 + r1
            int r3 = java.lang.Math.max(r13, r3)
        L_0x05cb:
            if (r35 == 0) goto L_0x0614
            r1 = -2147483648(0xffffffff80000000, float:-0.0)
            if (r7 == r1) goto L_0x05d3
            if (r7 != 0) goto L_0x0614
        L_0x05d3:
            r1 = 0
            r0.f = r1
            r1 = 0
        L_0x05d7:
            if (r1 >= r6) goto L_0x0614
            android.view.View r5 = r0.getChildAt(r1)
            if (r5 != 0) goto L_0x05e4
            int r5 = r0.f
            r0.f = r5
            goto L_0x0611
        L_0x05e4:
            int r13 = r5.getVisibility()
            r14 = 8
            if (r13 != r14) goto L_0x05ed
            goto L_0x0611
        L_0x05ed:
            android.view.ViewGroup$LayoutParams r5 = r5.getLayoutParams()
            i.y0 r5 = (i.C0093y0) r5
            if (r16 == 0) goto L_0x0601
            int r13 = r0.f
            int r14 = r5.leftMargin
            int r14 = r14 + r9
            int r5 = r5.rightMargin
            int r14 = r14 + r5
            int r14 = r14 + r13
            r0.f = r14
            goto L_0x0611
        L_0x0601:
            int r13 = r0.f
            int r14 = r13 + r9
            int r15 = r5.leftMargin
            int r14 = r14 + r15
            int r5 = r5.rightMargin
            int r14 = r14 + r5
            int r5 = java.lang.Math.max(r13, r14)
            r0.f = r5
        L_0x0611:
            int r1 = r1 + 1
            goto L_0x05d7
        L_0x0614:
            int r1 = r0.f
            int r5 = r0.getPaddingLeft()
            int r13 = r0.getPaddingRight()
            int r13 = r13 + r5
            int r13 = r13 + r1
            r0.f = r13
            int r1 = r0.getSuggestedMinimumWidth()
            int r1 = java.lang.Math.max(r13, r1)
            r5 = 0
            int r1 = android.view.View.resolveSizeAndState(r1, r2, r5)
            r5 = r1 & r17
            int r13 = r0.f
            int r5 = r5 - r13
            if (r22 != 0) goto L_0x0681
            if (r5 == 0) goto L_0x063d
            int r14 = (r28 > r18 ? 1 : (r28 == r18 ? 0 : -1))
            if (r14 <= 0) goto L_0x063d
            goto L_0x0681
        L_0x063d:
            int r5 = java.lang.Math.max(r10, r11)
            if (r35 == 0) goto L_0x0679
            r14 = 1073741824(0x40000000, float:2.0)
            if (r7 == r14) goto L_0x0679
            r7 = 0
        L_0x0648:
            if (r7 >= r6) goto L_0x0679
            android.view.View r10 = r0.getChildAt(r7)
            if (r10 == 0) goto L_0x0676
            int r11 = r10.getVisibility()
            r14 = 8
            if (r11 != r14) goto L_0x0659
            goto L_0x0676
        L_0x0659:
            android.view.ViewGroup$LayoutParams r11 = r10.getLayoutParams()
            i.y0 r11 = (i.C0093y0) r11
            float r11 = r11.weight
            int r11 = (r11 > r18 ? 1 : (r11 == r18 ? 0 : -1))
            if (r11 <= 0) goto L_0x0676
            r14 = 1073741824(0x40000000, float:2.0)
            int r11 = android.view.View.MeasureSpec.makeMeasureSpec(r9, r14)
            int r15 = r10.getMeasuredHeight()
            int r15 = android.view.View.MeasureSpec.makeMeasureSpec(r15, r14)
            r10.measure(r11, r15)
        L_0x0676:
            int r7 = r7 + 1
            goto L_0x0648
        L_0x0679:
            r22 = r1
            r17 = -16777216(0xffffffffff000000, float:-1.7014118E38)
            r21 = 0
            goto L_0x0800
        L_0x0681:
            float r3 = r0.f1437g
            int r9 = (r3 > r18 ? 1 : (r3 == r18 ? 0 : -1))
            if (r9 <= 0) goto L_0x0689
            r28 = r3
        L_0x0689:
            r26 = -1
            r31[r24] = r26
            r31[r30] = r26
            r31[r20] = r26
            r3 = 0
            r31[r3] = r26
            r32[r24] = r26
            r32[r30] = r26
            r32[r20] = r26
            r32[r3] = r26
            r0.f = r3
            r3 = -1
            r9 = 0
        L_0x06a0:
            if (r9 >= r6) goto L_0x07a8
            android.view.View r11 = r0.getChildAt(r9)
            if (r11 == 0) goto L_0x06b0
            int r14 = r11.getVisibility()
            r15 = 8
            if (r14 != r15) goto L_0x06b8
        L_0x06b0:
            r22 = r1
            r17 = -16777216(0xffffffffff000000, float:-1.7014118E38)
            r25 = -2
            goto L_0x07a2
        L_0x06b8:
            android.view.ViewGroup$LayoutParams r14 = r11.getLayoutParams()
            i.y0 r14 = (i.C0093y0) r14
            float r15 = r14.weight
            int r17 = (r15 > r18 ? 1 : (r15 == r18 ? 0 : -1))
            if (r17 <= 0) goto L_0x071a
            r17 = -16777216(0xffffffffff000000, float:-1.7014118E38)
            float r13 = (float) r5
            float r13 = r13 * r15
            float r13 = r13 / r28
            int r13 = (int) r13
            float r28 = r28 - r15
            int r5 = r5 - r13
            int r15 = r0.getPaddingTop()
            int r22 = r0.getPaddingBottom()
            int r22 = r22 + r15
            int r15 = r14.topMargin
            int r22 = r22 + r15
            int r15 = r14.bottomMargin
            int r15 = r22 + r15
            r22 = r1
            int r1 = r14.height
            int r1 = android.view.ViewGroup.getChildMeasureSpec(r4, r15, r1)
            int r15 = r14.width
            if (r15 != 0) goto L_0x06fd
            r15 = 1073741824(0x40000000, float:2.0)
            if (r7 == r15) goto L_0x06f1
            goto L_0x06ff
        L_0x06f1:
            if (r13 <= 0) goto L_0x06f4
            goto L_0x06f5
        L_0x06f4:
            r13 = 0
        L_0x06f5:
            int r13 = android.view.View.MeasureSpec.makeMeasureSpec(r13, r15)
            r11.measure(r13, r1)
            goto L_0x070f
        L_0x06fd:
            r15 = 1073741824(0x40000000, float:2.0)
        L_0x06ff:
            int r27 = r11.getMeasuredWidth()
            int r13 = r27 + r13
            if (r13 >= 0) goto L_0x0708
            r13 = 0
        L_0x0708:
            int r13 = android.view.View.MeasureSpec.makeMeasureSpec(r13, r15)
            r11.measure(r13, r1)
        L_0x070f:
            int r1 = r11.getMeasuredState()
            r1 = r1 & r17
            int r12 = android.view.View.combineMeasuredStates(r12, r1)
            goto L_0x071e
        L_0x071a:
            r22 = r1
            r17 = -16777216(0xffffffffff000000, float:-1.7014118E38)
        L_0x071e:
            if (r16 == 0) goto L_0x0732
            int r1 = r0.f
            int r13 = r11.getMeasuredWidth()
            int r15 = r14.leftMargin
            int r13 = r13 + r15
            int r15 = r14.rightMargin
            int r13 = r13 + r15
            int r13 = r13 + r1
            r0.f = r13
        L_0x072f:
            r1 = 1073741824(0x40000000, float:2.0)
            goto L_0x0746
        L_0x0732:
            int r1 = r0.f
            int r13 = r11.getMeasuredWidth()
            int r13 = r13 + r1
            int r15 = r14.leftMargin
            int r13 = r13 + r15
            int r15 = r14.rightMargin
            int r13 = r13 + r15
            int r1 = java.lang.Math.max(r1, r13)
            r0.f = r1
            goto L_0x072f
        L_0x0746:
            if (r8 == r1) goto L_0x0750
            int r1 = r14.height
            r15 = -1
            if (r1 != r15) goto L_0x0750
            r1 = r20
            goto L_0x0751
        L_0x0750:
            r1 = 0
        L_0x0751:
            int r13 = r14.topMargin
            int r15 = r14.bottomMargin
            int r13 = r13 + r15
            int r15 = r11.getMeasuredHeight()
            int r15 = r15 + r13
            int r3 = java.lang.Math.max(r3, r15)
            if (r1 == 0) goto L_0x0762
            goto L_0x0763
        L_0x0762:
            r13 = r15
        L_0x0763:
            int r1 = java.lang.Math.max(r10, r13)
            if (r29 == 0) goto L_0x0771
            int r10 = r14.height
            r13 = -1
            if (r10 != r13) goto L_0x0772
            r10 = r20
            goto L_0x0773
        L_0x0771:
            r13 = -1
        L_0x0772:
            r10 = 0
        L_0x0773:
            if (r34 == 0) goto L_0x079d
            int r11 = r11.getBaseline()
            if (r11 == r13) goto L_0x079d
            int r13 = r14.gravity
            if (r13 >= 0) goto L_0x0781
            int r13 = r0.f1436e
        L_0x0781:
            r13 = r13 & 112(0x70, float:1.57E-43)
            int r13 = r13 >> 4
            r25 = -2
            r13 = r13 & -2
            int r13 = r13 >> 1
            r14 = r31[r13]
            int r14 = java.lang.Math.max(r14, r11)
            r31[r13] = r14
            r14 = r32[r13]
            int r15 = r15 - r11
            int r11 = java.lang.Math.max(r14, r15)
            r32[r13] = r11
            goto L_0x079f
        L_0x079d:
            r25 = -2
        L_0x079f:
            r29 = r10
            r10 = r1
        L_0x07a2:
            int r9 = r9 + 1
            r1 = r22
            goto L_0x06a0
        L_0x07a8:
            r22 = r1
            r17 = -16777216(0xffffffffff000000, float:-1.7014118E38)
            int r1 = r0.f
            int r5 = r0.getPaddingLeft()
            int r7 = r0.getPaddingRight()
            int r7 = r7 + r5
            int r7 = r7 + r1
            r0.f = r7
            r1 = r31[r20]
            r15 = -1
            if (r1 != r15) goto L_0x07d1
            r21 = 0
            r5 = r31[r21]
            if (r5 != r15) goto L_0x07d1
            r5 = r31[r30]
            if (r5 != r15) goto L_0x07d1
            r5 = r31[r24]
            if (r5 == r15) goto L_0x07ce
            goto L_0x07d1
        L_0x07ce:
            r21 = 0
            goto L_0x07ff
        L_0x07d1:
            r5 = r31[r24]
            r21 = 0
            r7 = r31[r21]
            r9 = r31[r30]
            int r1 = java.lang.Math.max(r1, r9)
            int r1 = java.lang.Math.max(r7, r1)
            int r1 = java.lang.Math.max(r5, r1)
            r5 = r32[r24]
            r7 = r32[r21]
            r9 = r32[r20]
            r11 = r32[r30]
            int r9 = java.lang.Math.max(r9, r11)
            int r7 = java.lang.Math.max(r7, r9)
            int r5 = java.lang.Math.max(r5, r7)
            int r5 = r5 + r1
            int r1 = java.lang.Math.max(r3, r5)
            r3 = r1
        L_0x07ff:
            r5 = r10
        L_0x0800:
            if (r29 != 0) goto L_0x0807
            r14 = 1073741824(0x40000000, float:2.0)
            if (r8 == r14) goto L_0x0807
            r3 = r5
        L_0x0807:
            int r1 = r0.getPaddingTop()
            int r5 = r0.getPaddingBottom()
            int r5 = r5 + r1
            int r5 = r5 + r3
            int r1 = r0.getSuggestedMinimumHeight()
            int r1 = java.lang.Math.max(r5, r1)
            r3 = r12 & r17
            r3 = r22 | r3
            int r5 = r12 << 16
            int r1 = android.view.View.resolveSizeAndState(r1, r4, r5)
            r0.setMeasuredDimension(r3, r1)
            if (r19 == 0) goto L_0x0866
            int r1 = r0.getMeasuredHeight()
            r14 = 1073741824(0x40000000, float:2.0)
            int r4 = android.view.View.MeasureSpec.makeMeasureSpec(r1, r14)
            r13 = r21
        L_0x0834:
            if (r13 >= r6) goto L_0x0866
            android.view.View r1 = r0.getChildAt(r13)
            int r3 = r1.getVisibility()
            r9 = 8
            if (r3 == r9) goto L_0x085e
            android.view.ViewGroup$LayoutParams r3 = r1.getLayoutParams()
            r7 = r3
            i.y0 r7 = (i.C0093y0) r7
            int r3 = r7.height
            r15 = -1
            if (r3 != r15) goto L_0x085f
            int r8 = r7.width
            int r3 = r1.getMeasuredWidth()
            r7.width = r3
            r3 = 0
            r5 = 0
            r0.measureChildWithMargins(r1, r2, r3, r4, r5)
            r7.width = r8
            goto L_0x085f
        L_0x085e:
            r15 = -1
        L_0x085f:
            int r13 = r13 + 1
            r0 = r38
            r2 = r39
            goto L_0x0834
        L_0x0866:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: i.C0095z0.onMeasure(int, int):void");
    }

    public void setBaselineAligned(boolean z2) {
        this.f1433a = z2;
    }

    public void setBaselineAlignedChildIndex(int i2) {
        if (i2 < 0 || i2 >= getChildCount()) {
            throw new IllegalArgumentException("base aligned child index out of range (0, " + getChildCount() + ")");
        }
        this.b = i2;
    }

    public void setDividerDrawable(Drawable drawable) {
        if (drawable != this.f1441k) {
            this.f1441k = drawable;
            boolean z2 = false;
            if (drawable != null) {
                this.f1442l = drawable.getIntrinsicWidth();
                this.f1443m = drawable.getIntrinsicHeight();
            } else {
                this.f1442l = 0;
                this.f1443m = 0;
            }
            if (drawable == null) {
                z2 = true;
            }
            setWillNotDraw(z2);
            requestLayout();
        }
    }

    public void setDividerPadding(int i2) {
        this.f1445o = i2;
    }

    public void setGravity(int i2) {
        if (this.f1436e != i2) {
            if ((8388615 & i2) == 0) {
                i2 |= 8388611;
            }
            if ((i2 & 112) == 0) {
                i2 |= 48;
            }
            this.f1436e = i2;
            requestLayout();
        }
    }

    public void setHorizontalGravity(int i2) {
        int i3 = i2 & 8388615;
        int i4 = this.f1436e;
        if ((8388615 & i4) != i3) {
            this.f1436e = i3 | (-8388616 & i4);
            requestLayout();
        }
    }

    public void setMeasureWithLargestChildEnabled(boolean z2) {
        this.f1438h = z2;
    }

    public void setOrientation(int i2) {
        if (this.f1435d != i2) {
            this.f1435d = i2;
            requestLayout();
        }
    }

    public void setShowDividers(int i2) {
        if (i2 != this.f1444n) {
            requestLayout();
        }
        this.f1444n = i2;
    }

    public void setVerticalGravity(int i2) {
        int i3 = i2 & 112;
        int i4 = this.f1436e;
        if ((i4 & 112) != i3) {
            this.f1436e = i3 | (i4 & -113);
            requestLayout();
        }
    }

    public void setWeightSum(float f2) {
        this.f1437g = Math.max(0.0f, f2);
    }

    public final boolean shouldDelayChildPressedState() {
        return false;
    }
}
