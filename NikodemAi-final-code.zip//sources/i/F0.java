package i;

import android.os.Handler;
import android.widget.AbsListView;

public final class F0 implements AbsListView.OnScrollListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ H0 f1187a;

    public F0(H0 h02) {
        this.f1187a = h02;
    }

    public final void onScrollStateChanged(AbsListView absListView, int i2) {
        if (i2 == 1) {
            H0 h02 = this.f1187a;
            if (h02.f1214y.getInputMethodMode() != 2 && h02.f1214y.getContentView() != null) {
                Handler handler = h02.f1210u;
                D0 d02 = h02.f1206q;
                handler.removeCallbacks(d02);
                d02.run();
            }
        }
    }

    public final void onScroll(AbsListView absListView, int i2, int i3, int i4) {
    }
}
