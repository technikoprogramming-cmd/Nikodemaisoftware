package i;

import C.j;
import D.g;
import D.p;
import D.s;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.InputFilter;
import android.text.TextDirectionHeuristic;
import android.text.TextDirectionHeuristics;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.ActionMode;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.view.textclassifier.TextClassifier;
import android.widget.TextView;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import r.f;
import w.C0145b;
import w.C0146c;

/* renamed from: i.e0  reason: case insensitive filesystem */
public class C0054e0 extends TextView {

    /* renamed from: a  reason: collision with root package name */
    public final C0077q f1299a;
    public final C0046a0 b;

    /* renamed from: c  reason: collision with root package name */
    public final E f1300c;

    /* renamed from: d  reason: collision with root package name */
    public C0092y f1301d;

    /* renamed from: e  reason: collision with root package name */
    public boolean f1302e;
    public j f;

    /* renamed from: g  reason: collision with root package name */
    public Future f1303g;

    public C0054e0(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 16842884);
    }

    private C0092y getEmojiTextViewHelper() {
        if (this.f1301d == null) {
            this.f1301d = new C0092y(this);
        }
        return this.f1301d;
    }

    public final void drawableStateChanged() {
        super.drawableStateChanged();
        C0077q qVar = this.f1299a;
        if (qVar != null) {
            qVar.a();
        }
        C0046a0 a0Var = this.b;
        if (a0Var != null) {
            a0Var.b();
        }
    }

    public final void g() {
        Future future = this.f1303g;
        if (future != null) {
            try {
                this.f1303g = null;
                if (future.get() != null) {
                    throw new ClassCastException();
                } else if (Build.VERSION.SDK_INT >= 29) {
                    throw null;
                } else {
                    g.y(this);
                    throw null;
                }
            } catch (InterruptedException | ExecutionException unused) {
            }
        }
    }

    public int getAutoSizeMaxTextSize() {
        if (n1.f1379c) {
            return super.getAutoSizeMaxTextSize();
        }
        C0046a0 a0Var = this.b;
        if (a0Var != null) {
            return Math.round(a0Var.f1284i.f1338e);
        }
        return -1;
    }

    public int getAutoSizeMinTextSize() {
        if (n1.f1379c) {
            return super.getAutoSizeMinTextSize();
        }
        C0046a0 a0Var = this.b;
        if (a0Var != null) {
            return Math.round(a0Var.f1284i.f1337d);
        }
        return -1;
    }

    public int getAutoSizeStepGranularity() {
        if (n1.f1379c) {
            return super.getAutoSizeStepGranularity();
        }
        C0046a0 a0Var = this.b;
        if (a0Var != null) {
            return Math.round(a0Var.f1284i.f1336c);
        }
        return -1;
    }

    public int[] getAutoSizeTextAvailableSizes() {
        if (n1.f1379c) {
            return super.getAutoSizeTextAvailableSizes();
        }
        C0046a0 a0Var = this.b;
        if (a0Var != null) {
            return a0Var.f1284i.f;
        }
        return new int[0];
    }

    public int getAutoSizeTextType() {
        if (!n1.f1379c) {
            C0046a0 a0Var = this.b;
            if (a0Var != null) {
                return a0Var.f1284i.f1335a;
            }
            return 0;
        } else if (super.getAutoSizeTextType() == 1) {
            return 1;
        } else {
            return 0;
        }
    }

    public ActionMode.Callback getCustomSelectionActionModeCallback() {
        return g.T(super.getCustomSelectionActionModeCallback());
    }

    public int getFirstBaselineToTopHeight() {
        return getPaddingTop() - getPaint().getFontMetricsInt().top;
    }

    public int getLastBaselineToBottomHeight() {
        return getPaddingBottom() + getPaint().getFontMetricsInt().bottom;
    }

    public C0048b0 getSuperCaller() {
        if (this.f == null) {
            int i2 = Build.VERSION.SDK_INT;
            if (i2 >= 34) {
                this.f = new C0052d0(this);
            } else if (i2 >= 28) {
                this.f = new C0050c0(this);
            } else if (i2 >= 26) {
                this.f = new j(18, (Object) this);
            }
        }
        return this.f;
    }

    public ColorStateList getSupportBackgroundTintList() {
        C0077q qVar = this.f1299a;
        if (qVar != null) {
            return qVar.b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0077q qVar = this.f1299a;
        if (qVar != null) {
            return qVar.c();
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.b.d();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.b.e();
    }

    public CharSequence getText() {
        g();
        return super.getText();
    }

    public TextClassifier getTextClassifier() {
        E e2;
        if (Build.VERSION.SDK_INT >= 28 || (e2 = this.f1300c) == null) {
            return super.getTextClassifier();
        }
        TextClassifier textClassifier = (TextClassifier) e2.f1182c;
        if (textClassifier == null) {
            return U.a((TextView) e2.b);
        }
        return textClassifier;
    }

    public C0145b getTextMetricsParamsCompat() {
        return g.y(this);
    }

    public final InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        InputConnection onCreateInputConnection = super.onCreateInputConnection(editorInfo);
        this.b.getClass();
        C0046a0.h(editorInfo, onCreateInputConnection, this);
        g.D(editorInfo, onCreateInputConnection, this);
        return onCreateInputConnection;
    }

    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 30 && i2 < 33 && onCheckIsTextEditor()) {
            ((InputMethodManager) getContext().getSystemService("input_method")).isActive(this);
        }
    }

    public final void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        super.onLayout(z2, i2, i3, i4, i5);
        C0046a0 a0Var = this.b;
        if (a0Var != null && !n1.f1379c) {
            a0Var.f1284i.a();
        }
    }

    public void onMeasure(int i2, int i3) {
        g();
        super.onMeasure(i2, i3);
    }

    public final void onTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
        super.onTextChanged(charSequence, i2, i3, i4);
        C0046a0 a0Var = this.b;
        if (a0Var != null && !n1.f1379c) {
            C0064j0 j0Var = a0Var.f1284i;
            if (j0Var.f()) {
                j0Var.a();
            }
        }
    }

    public void setAllCaps(boolean z2) {
        super.setAllCaps(z2);
        getEmojiTextViewHelper().b(z2);
    }

    public final void setAutoSizeTextTypeUniformWithConfiguration(int i2, int i3, int i4, int i5) {
        if (n1.f1379c) {
            super.setAutoSizeTextTypeUniformWithConfiguration(i2, i3, i4, i5);
            return;
        }
        C0046a0 a0Var = this.b;
        if (a0Var != null) {
            a0Var.i(i2, i3, i4, i5);
        }
    }

    public final void setAutoSizeTextTypeUniformWithPresetSizes(int[] iArr, int i2) {
        if (n1.f1379c) {
            super.setAutoSizeTextTypeUniformWithPresetSizes(iArr, i2);
            return;
        }
        C0046a0 a0Var = this.b;
        if (a0Var != null) {
            a0Var.j(iArr, i2);
        }
    }

    public void setAutoSizeTextTypeWithDefaults(int i2) {
        if (n1.f1379c) {
            super.setAutoSizeTextTypeWithDefaults(i2);
            return;
        }
        C0046a0 a0Var = this.b;
        if (a0Var != null) {
            a0Var.k(i2);
        }
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0077q qVar = this.f1299a;
        if (qVar != null) {
            qVar.e();
        }
    }

    public void setBackgroundResource(int i2) {
        super.setBackgroundResource(i2);
        C0077q qVar = this.f1299a;
        if (qVar != null) {
            qVar.f(i2);
        }
    }

    public final void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        C0046a0 a0Var = this.b;
        if (a0Var != null) {
            a0Var.b();
        }
    }

    public final void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        C0046a0 a0Var = this.b;
        if (a0Var != null) {
            a0Var.b();
        }
    }

    public final void setCompoundDrawablesRelativeWithIntrinsicBounds(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelativeWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
        C0046a0 a0Var = this.b;
        if (a0Var != null) {
            a0Var.b();
        }
    }

    public final void setCompoundDrawablesWithIntrinsicBounds(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
        C0046a0 a0Var = this.b;
        if (a0Var != null) {
            a0Var.b();
        }
    }

    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(g.U(callback, this));
    }

    public void setEmojiCompatEnabled(boolean z2) {
        getEmojiTextViewHelper().c(z2);
    }

    public void setFilters(InputFilter[] inputFilterArr) {
        super.setFilters(((g) getEmojiTextViewHelper().b.b).u(inputFilterArr));
    }

    public void setFirstBaselineToTopHeight(int i2) {
        if (Build.VERSION.SDK_INT >= 28) {
            getSuperCaller().d(i2);
        } else {
            g.P(this, i2);
        }
    }

    public void setLastBaselineToBottomHeight(int i2) {
        if (Build.VERSION.SDK_INT >= 28) {
            getSuperCaller().v(i2);
        } else {
            g.Q(this, i2);
        }
    }

    public void setLineHeight(int i2) {
        g.R(this, i2);
    }

    public void setPrecomputedText(C0146c cVar) {
        if (Build.VERSION.SDK_INT >= 29) {
            throw null;
        }
        g.y(this);
        throw null;
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C0077q qVar = this.f1299a;
        if (qVar != null) {
            qVar.h(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C0077q qVar = this.f1299a;
        if (qVar != null) {
            qVar.i(mode);
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        C0046a0 a0Var = this.b;
        a0Var.l(colorStateList);
        a0Var.b();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        C0046a0 a0Var = this.b;
        a0Var.m(mode);
        a0Var.b();
    }

    public final void setTextAppearance(Context context, int i2) {
        super.setTextAppearance(context, i2);
        C0046a0 a0Var = this.b;
        if (a0Var != null) {
            a0Var.g(context, i2);
        }
    }

    public void setTextClassifier(TextClassifier textClassifier) {
        E e2;
        if (Build.VERSION.SDK_INT >= 28 || (e2 = this.f1300c) == null) {
            super.setTextClassifier(textClassifier);
        } else {
            e2.f1182c = textClassifier;
        }
    }

    public void setTextFuture(Future<C0146c> future) {
        this.f1303g = future;
        if (future != null) {
            requestLayout();
        }
    }

    public void setTextMetricsParamsCompat(C0145b bVar) {
        TextDirectionHeuristic textDirectionHeuristic;
        TextDirectionHeuristic textDirectionHeuristic2 = bVar.b;
        TextDirectionHeuristic textDirectionHeuristic3 = TextDirectionHeuristics.FIRSTSTRONG_RTL;
        int i2 = 1;
        if (!(textDirectionHeuristic2 == textDirectionHeuristic3 || textDirectionHeuristic2 == (textDirectionHeuristic = TextDirectionHeuristics.FIRSTSTRONG_LTR))) {
            if (textDirectionHeuristic2 == TextDirectionHeuristics.ANYRTL_LTR) {
                i2 = 2;
            } else if (textDirectionHeuristic2 == TextDirectionHeuristics.LTR) {
                i2 = 3;
            } else if (textDirectionHeuristic2 == TextDirectionHeuristics.RTL) {
                i2 = 4;
            } else if (textDirectionHeuristic2 == TextDirectionHeuristics.LOCALE) {
                i2 = 5;
            } else if (textDirectionHeuristic2 == textDirectionHeuristic) {
                i2 = 6;
            } else if (textDirectionHeuristic2 == textDirectionHeuristic3) {
                i2 = 7;
            }
        }
        setTextDirection(i2);
        getPaint().set(bVar.f1626a);
        p.e(this, bVar.f1627c);
        p.h(this, bVar.f1628d);
    }

    public final void setTextSize(int i2, float f2) {
        boolean z2 = n1.f1379c;
        if (z2) {
            super.setTextSize(i2, f2);
            return;
        }
        C0046a0 a0Var = this.b;
        if (a0Var != null && !z2) {
            C0064j0 j0Var = a0Var.f1284i;
            if (!j0Var.f()) {
                j0Var.g(i2, f2);
            }
        }
    }

    public final void setTypeface(Typeface typeface, int i2) {
        Typeface typeface2;
        if (!this.f1302e) {
            if (typeface == null || i2 <= 0) {
                typeface2 = null;
            } else {
                Context context = getContext();
                g gVar = f.f1590a;
                if (context != null) {
                    typeface2 = Typeface.create(typeface, i2);
                } else {
                    throw new IllegalArgumentException("Context cannot be null");
                }
            }
            this.f1302e = true;
            if (typeface2 != null) {
                typeface = typeface2;
            }
            try {
                super.setTypeface(typeface, i2);
            } finally {
                this.f1302e = false;
            }
        }
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public C0054e0(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        U0.a(context);
        this.f1302e = false;
        this.f = null;
        T0.a(this, getContext());
        C0077q qVar = new C0077q(this);
        this.f1299a = qVar;
        qVar.d(attributeSet, i2);
        C0046a0 a0Var = new C0046a0(this);
        this.b = a0Var;
        a0Var.f(attributeSet, i2);
        a0Var.b();
        E e2 = new E();
        e2.b = this;
        this.f1300c = e2;
        getEmojiTextViewHelper().a(attributeSet, i2);
    }

    public final void setLineHeight(int i2, float f2) {
        int i3 = Build.VERSION.SDK_INT;
        if (i3 >= 34) {
            getSuperCaller().o(i2, f2);
        } else if (i3 >= 34) {
            s.a(this, i2, f2);
        } else {
            g.R(this, Math.round(TypedValue.applyDimension(i2, f2, getResources().getDisplayMetrics())));
        }
    }

    public final void setCompoundDrawablesRelativeWithIntrinsicBounds(int i2, int i3, int i4, int i5) {
        Context context = getContext();
        Drawable drawable = null;
        Drawable s2 = i2 != 0 ? g.s(context, i2) : null;
        Drawable s3 = i3 != 0 ? g.s(context, i3) : null;
        Drawable s4 = i4 != 0 ? g.s(context, i4) : null;
        if (i5 != 0) {
            drawable = g.s(context, i5);
        }
        setCompoundDrawablesRelativeWithIntrinsicBounds(s2, s3, s4, drawable);
        C0046a0 a0Var = this.b;
        if (a0Var != null) {
            a0Var.b();
        }
    }

    public final void setCompoundDrawablesWithIntrinsicBounds(int i2, int i3, int i4, int i5) {
        Context context = getContext();
        Drawable drawable = null;
        Drawable s2 = i2 != 0 ? g.s(context, i2) : null;
        Drawable s3 = i3 != 0 ? g.s(context, i3) : null;
        Drawable s4 = i4 != 0 ? g.s(context, i4) : null;
        if (i5 != 0) {
            drawable = g.s(context, i5);
        }
        setCompoundDrawablesWithIntrinsicBounds(s2, s3, s4, drawable);
        C0046a0 a0Var = this.b;
        if (a0Var != null) {
            a0Var.b();
        }
    }
}
