package i;

import C.h;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.AbsSeekBar;
import d.C0010a;
import ncs.oprogramowanie.nikodemai.aos.R;
import s.C0126a;
import s.C0127b;
import y.K;

public final class I extends E {

    /* renamed from: e  reason: collision with root package name */
    public final H f1215e;
    public Drawable f;

    /* renamed from: g  reason: collision with root package name */
    public ColorStateList f1216g = null;

    /* renamed from: h  reason: collision with root package name */
    public PorterDuff.Mode f1217h = null;

    /* renamed from: i  reason: collision with root package name */
    public boolean f1218i = false;

    /* renamed from: j  reason: collision with root package name */
    public boolean f1219j = false;

    public I(H h2) {
        super((AbsSeekBar) h2);
        this.f1215e = h2;
    }

    public final void b(AttributeSet attributeSet, int i2) {
        super.b(attributeSet, R.attr.seekBarStyle);
        H h2 = this.f1215e;
        Context context = h2.getContext();
        int[] iArr = C0010a.f775g;
        h m2 = h.m(context, attributeSet, iArr, R.attr.seekBarStyle);
        K.g(h2, h2.getContext(), iArr, attributeSet, (TypedArray) m2.b, R.attr.seekBarStyle);
        Drawable j2 = m2.j(0);
        if (j2 != null) {
            h2.setThumb(j2);
        }
        Drawable i3 = m2.i(1);
        Drawable drawable = this.f;
        if (drawable != null) {
            drawable.setCallback((Drawable.Callback) null);
        }
        this.f = i3;
        if (i3 != null) {
            i3.setCallback(h2);
            C0127b.b(i3, h2.getLayoutDirection());
            if (i3.isStateful()) {
                i3.setState(h2.getDrawableState());
            }
            f();
        }
        h2.invalidate();
        TypedArray typedArray = (TypedArray) m2.b;
        if (typedArray.hasValue(3)) {
            this.f1217h = C0074o0.b(typedArray.getInt(3, -1), this.f1217h);
            this.f1219j = true;
        }
        if (typedArray.hasValue(2)) {
            this.f1216g = m2.h(2);
            this.f1218i = true;
        }
        m2.r();
        f();
    }

    public final void f() {
        Drawable drawable = this.f;
        if (drawable == null) {
            return;
        }
        if (this.f1218i || this.f1219j) {
            Drawable mutate = drawable.mutate();
            this.f = mutate;
            if (this.f1218i) {
                C0126a.h(mutate, this.f1216g);
            }
            if (this.f1219j) {
                C0126a.i(this.f, this.f1217h);
            }
            if (this.f.isStateful()) {
                this.f.setState(this.f1215e.getDrawableState());
            }
        }
    }

    public final void g(Canvas canvas) {
        int i2;
        if (this.f != null) {
            H h2 = this.f1215e;
            int max = h2.getMax();
            int i3 = 1;
            if (max > 1) {
                int intrinsicWidth = this.f.getIntrinsicWidth();
                int intrinsicHeight = this.f.getIntrinsicHeight();
                if (intrinsicWidth >= 0) {
                    i2 = intrinsicWidth / 2;
                } else {
                    i2 = 1;
                }
                if (intrinsicHeight >= 0) {
                    i3 = intrinsicHeight / 2;
                }
                this.f.setBounds(-i2, -i3, i2, i3);
                float width = ((float) ((h2.getWidth() - h2.getPaddingLeft()) - h2.getPaddingRight())) / ((float) max);
                int save = canvas.save();
                canvas.translate((float) h2.getPaddingLeft(), (float) (h2.getHeight() / 2));
                for (int i4 = 0; i4 <= max; i4++) {
                    this.f.draw(canvas);
                    canvas.translate(width, 0.0f);
                }
                canvas.restoreToCount(save);
            }
        }
    }
}
