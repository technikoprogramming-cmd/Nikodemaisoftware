package i;

/* renamed from: i.v0  reason: case insensitive filesystem */
public interface C0087v0 {
}
