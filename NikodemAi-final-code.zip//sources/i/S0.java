package i;

import g.C0027b;

public abstract class S0 extends C0095z0 implements C0027b {
}
