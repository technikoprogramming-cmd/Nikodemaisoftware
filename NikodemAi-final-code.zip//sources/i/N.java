package i;

import android.view.View;
import android.widget.AdapterView;

public final class N implements AdapterView.OnItemClickListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ P f1233a;

    public N(P p2) {
        this.f1233a = p2;
    }

    public final void onItemClick(AdapterView adapterView, View view, int i2, long j2) {
        P p2 = this.f1233a;
        p2.f1245F.setSelection(i2);
        T t2 = p2.f1245F;
        if (t2.getOnItemClickListener() != null) {
            t2.performItemClick(view, i2, p2.f1242C.getItemId(i2));
        }
        p2.dismiss();
    }
}
