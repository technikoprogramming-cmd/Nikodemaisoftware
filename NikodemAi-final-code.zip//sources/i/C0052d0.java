package i;

/* renamed from: i.d0  reason: case insensitive filesystem */
public final class C0052d0 extends C0050c0 {

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ C0054e0 f1296d;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public C0052d0(C0054e0 e0Var) {
        super(e0Var);
        this.f1296d = e0Var;
    }

    public final void o(int i2, float f) {
        C0052d0.super.setLineHeight(i2, f);
    }
}
