package i;

import android.view.ViewTreeObserver;
import android.widget.PopupWindow;
import h.C0041d;

public final class O implements PopupWindow.OnDismissListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ C0041d f1234a;
    public final /* synthetic */ P b;

    public O(P p2, C0041d dVar) {
        this.b = p2;
        this.f1234a = dVar;
    }

    public final void onDismiss() {
        ViewTreeObserver viewTreeObserver = this.b.f1245F.getViewTreeObserver();
        if (viewTreeObserver != null) {
            viewTreeObserver.removeGlobalOnLayoutListener(this.f1234a);
        }
    }
}
