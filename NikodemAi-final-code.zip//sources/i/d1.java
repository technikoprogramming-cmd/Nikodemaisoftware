package i;

import E.b;
import E.c;
import android.os.Parcel;
import android.os.Parcelable;

public final class d1 extends c {
    public static final Parcelable.Creator<d1> CREATOR = new b(1);

    /* renamed from: c  reason: collision with root package name */
    public int f1297c;

    /* renamed from: d  reason: collision with root package name */
    public boolean f1298d;

    public d1(Parcel parcel, ClassLoader classLoader) {
        super(parcel, classLoader);
        boolean z2;
        this.f1297c = parcel.readInt();
        if (parcel.readInt() != 0) {
            z2 = true;
        } else {
            z2 = false;
        }
        this.f1298d = z2;
    }

    public final void writeToParcel(Parcel parcel, int i2) {
        super.writeToParcel(parcel, i2);
        parcel.writeInt(this.f1297c);
        parcel.writeInt(this.f1298d ? 1 : 0);
    }
}
