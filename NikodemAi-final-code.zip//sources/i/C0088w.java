package i;

/* renamed from: i.w  reason: case insensitive filesystem */
public final class C0088w {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ C0090x f1417a;

    public C0088w(C0090x xVar) {
        this.f1417a = xVar;
    }
}
