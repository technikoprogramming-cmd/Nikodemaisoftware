package i;

import R.a;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.util.TypedValue;
import java.util.WeakHashMap;
import l.C0102d;
import l.C0104f;
import l.C0110l;
import ncs.oprogramowanie.nikodemai.aos.R;
import p.C0120a;

public final class O0 {
    public static final PorterDuff.Mode f = PorterDuff.Mode.SRC_IN;

    /* renamed from: g  reason: collision with root package name */
    public static O0 f1235g;

    /* renamed from: h  reason: collision with root package name */
    public static final N0 f1236h = new C0104f(6);

    /* renamed from: a  reason: collision with root package name */
    public WeakHashMap f1237a;
    public final WeakHashMap b = new WeakHashMap(0);

    /* renamed from: c  reason: collision with root package name */
    public TypedValue f1238c;

    /* renamed from: d  reason: collision with root package name */
    public boolean f1239d;

    /* renamed from: e  reason: collision with root package name */
    public C0084u f1240e;

    public static synchronized O0 b() {
        O0 o0;
        synchronized (O0.class) {
            try {
                if (f1235g == null) {
                    f1235g = new O0();
                }
                o0 = f1235g;
            } catch (Throwable th) {
                while (true) {
                    throw th;
                }
            }
        }
        return o0;
    }

    public static synchronized PorterDuffColorFilter e(int i2, PorterDuff.Mode mode) {
        PorterDuffColorFilter porterDuffColorFilter;
        synchronized (O0.class) {
            N0 n0 = f1236h;
            n0.getClass();
            int i3 = (31 + i2) * 31;
            porterDuffColorFilter = (PorterDuffColorFilter) n0.a(Integer.valueOf(mode.hashCode() + i3));
            if (porterDuffColorFilter == null) {
                porterDuffColorFilter = new PorterDuffColorFilter(i2, mode);
                PorterDuffColorFilter porterDuffColorFilter2 = (PorterDuffColorFilter) n0.b(Integer.valueOf(mode.hashCode() + i3), porterDuffColorFilter);
            }
        }
        return porterDuffColorFilter;
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v6, resolved type: java.lang.ref.WeakReference} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v13, resolved type: java.lang.ref.WeakReference} */
    /* JADX WARNING: type inference failed for: r0v6, types: [l.e, java.lang.Object] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final android.graphics.drawable.Drawable a(android.content.Context r10, int r11) {
        /*
            r9 = this;
            android.util.TypedValue r0 = r9.f1238c
            if (r0 != 0) goto L_0x000b
            android.util.TypedValue r0 = new android.util.TypedValue
            r0.<init>()
            r9.f1238c = r0
        L_0x000b:
            android.util.TypedValue r0 = r9.f1238c
            android.content.res.Resources r1 = r10.getResources()
            r2 = 1
            r1.getValue(r11, r0, r2)
            int r1 = r0.assetCookie
            long r1 = (long) r1
            r3 = 32
            long r1 = r1 << r3
            int r3 = r0.data
            long r3 = (long) r3
            long r1 = r1 | r3
            monitor-enter(r9)
            java.util.WeakHashMap r3 = r9.b     // Catch:{ all -> 0x0056 }
            java.lang.Object r3 = r3.get(r10)     // Catch:{ all -> 0x0056 }
            l.e r3 = (l.C0103e) r3     // Catch:{ all -> 0x0056 }
            r4 = 0
            if (r3 != 0) goto L_0x002d
            monitor-exit(r9)
            goto L_0x0071
        L_0x002d:
            long[] r5 = r3.b     // Catch:{ all -> 0x0056 }
            int r6 = r3.f1485d     // Catch:{ all -> 0x0056 }
            int r5 = l.C0102d.b(r5, r6, r1)     // Catch:{ all -> 0x0056 }
            if (r5 < 0) goto L_0x003f
            java.lang.Object[] r6 = r3.f1484c     // Catch:{ all -> 0x0056 }
            r5 = r6[r5]     // Catch:{ all -> 0x0056 }
            java.lang.Object r6 = l.C0103e.f1482e     // Catch:{ all -> 0x0056 }
            if (r5 != r6) goto L_0x0040
        L_0x003f:
            r5 = r4
        L_0x0040:
            java.lang.ref.WeakReference r5 = (java.lang.ref.WeakReference) r5     // Catch:{ all -> 0x0056 }
            if (r5 == 0) goto L_0x0070
            java.lang.Object r5 = r5.get()     // Catch:{ all -> 0x0056 }
            android.graphics.drawable.Drawable$ConstantState r5 = (android.graphics.drawable.Drawable.ConstantState) r5     // Catch:{ all -> 0x0056 }
            if (r5 == 0) goto L_0x0059
            android.content.res.Resources r3 = r10.getResources()     // Catch:{ all -> 0x0056 }
            android.graphics.drawable.Drawable r4 = r5.newDrawable(r3)     // Catch:{ all -> 0x0056 }
            monitor-exit(r9)
            goto L_0x0071
        L_0x0056:
            r10 = move-exception
            goto L_0x0110
        L_0x0059:
            long[] r5 = r3.b     // Catch:{ all -> 0x0056 }
            int r6 = r3.f1485d     // Catch:{ all -> 0x0056 }
            int r5 = l.C0102d.b(r5, r6, r1)     // Catch:{ all -> 0x0056 }
            if (r5 < 0) goto L_0x0070
            java.lang.Object[] r6 = r3.f1484c     // Catch:{ all -> 0x0056 }
            r7 = r6[r5]     // Catch:{ all -> 0x0056 }
            java.lang.Object r8 = l.C0103e.f1482e     // Catch:{ all -> 0x0056 }
            if (r7 == r8) goto L_0x0070
            r6[r5] = r8     // Catch:{ all -> 0x0056 }
            r5 = 1
            r3.f1483a = r5     // Catch:{ all -> 0x0056 }
        L_0x0070:
            monitor-exit(r9)
        L_0x0071:
            if (r4 == 0) goto L_0x0074
            return r4
        L_0x0074:
            i.u r3 = r9.f1240e
            r4 = 0
            if (r3 != 0) goto L_0x007a
            goto L_0x00bd
        L_0x007a:
            r3 = 2131165201(0x7f070011, float:1.7944612E38)
            if (r11 != r3) goto L_0x0097
            android.graphics.drawable.LayerDrawable r4 = new android.graphics.drawable.LayerDrawable
            r11 = 2131165200(0x7f070010, float:1.794461E38)
            android.graphics.drawable.Drawable r11 = r9.c(r10, r11)
            r3 = 2131165202(0x7f070012, float:1.7944614E38)
            android.graphics.drawable.Drawable r3 = r9.c(r10, r3)
            android.graphics.drawable.Drawable[] r11 = new android.graphics.drawable.Drawable[]{r11, r3}
            r4.<init>(r11)
            goto L_0x00bd
        L_0x0097:
            r3 = 2131165236(0x7f070034, float:1.7944683E38)
            if (r11 != r3) goto L_0x00a4
            r11 = 2131099707(0x7f06003b, float:1.7811775E38)
            android.graphics.drawable.LayerDrawable r4 = i.C0084u.c(r9, r10, r11)
            goto L_0x00bd
        L_0x00a4:
            r3 = 2131165235(0x7f070033, float:1.7944681E38)
            if (r11 != r3) goto L_0x00b1
            r11 = 2131099708(0x7f06003c, float:1.7811777E38)
            android.graphics.drawable.LayerDrawable r4 = i.C0084u.c(r9, r10, r11)
            goto L_0x00bd
        L_0x00b1:
            r3 = 2131165237(0x7f070035, float:1.7944685E38)
            if (r11 != r3) goto L_0x00bd
            r11 = 2131099709(0x7f06003d, float:1.7811779E38)
            android.graphics.drawable.LayerDrawable r4 = i.C0084u.c(r9, r10, r11)
        L_0x00bd:
            if (r4 == 0) goto L_0x010f
            int r11 = r0.changingConfigurations
            r4.setChangingConfigurations(r11)
            monitor-enter(r9)
            android.graphics.drawable.Drawable$ConstantState r11 = r4.getConstantState()     // Catch:{ all -> 0x00ff }
            if (r11 == 0) goto L_0x010b
            java.util.WeakHashMap r0 = r9.b     // Catch:{ all -> 0x00ff }
            java.lang.Object r0 = r0.get(r10)     // Catch:{ all -> 0x00ff }
            l.e r0 = (l.C0103e) r0     // Catch:{ all -> 0x00ff }
            if (r0 != 0) goto L_0x0101
            l.e r0 = new l.e     // Catch:{ all -> 0x00ff }
            r0.<init>()     // Catch:{ all -> 0x00ff }
            r3 = 0
            r0.f1483a = r3     // Catch:{ all -> 0x00ff }
            r3 = 4
        L_0x00de:
            r5 = 32
            r6 = 80
            if (r3 >= r5) goto L_0x00ef
            r5 = 1
            int r5 = r5 << r3
            int r5 = r5 + -12
            if (r6 > r5) goto L_0x00ec
            r6 = r5
            goto L_0x00ef
        L_0x00ec:
            int r3 = r3 + 1
            goto L_0x00de
        L_0x00ef:
            int r6 = r6 / 8
            long[] r3 = new long[r6]     // Catch:{ all -> 0x00ff }
            r0.b = r3     // Catch:{ all -> 0x00ff }
            java.lang.Object[] r3 = new java.lang.Object[r6]     // Catch:{ all -> 0x00ff }
            r0.f1484c = r3     // Catch:{ all -> 0x00ff }
            java.util.WeakHashMap r3 = r9.b     // Catch:{ all -> 0x00ff }
            r3.put(r10, r0)     // Catch:{ all -> 0x00ff }
            goto L_0x0101
        L_0x00ff:
            r10 = move-exception
            goto L_0x010d
        L_0x0101:
            java.lang.ref.WeakReference r10 = new java.lang.ref.WeakReference     // Catch:{ all -> 0x00ff }
            r10.<init>(r11)     // Catch:{ all -> 0x00ff }
            r0.b(r1, r10)     // Catch:{ all -> 0x00ff }
            monitor-exit(r9)
            goto L_0x010c
        L_0x010b:
            monitor-exit(r9)
        L_0x010c:
            return r4
        L_0x010d:
            monitor-exit(r9)     // Catch:{ all -> 0x00ff }
            throw r10
        L_0x010f:
            return r4
        L_0x0110:
            monitor-exit(r9)     // Catch:{ all -> 0x0056 }
            throw r10
        */
        throw new UnsupportedOperationException("Method not decompiled: i.O0.a(android.content.Context, int):android.graphics.drawable.Drawable");
    }

    public final synchronized Drawable c(Context context, int i2) {
        return d(context, i2, false);
    }

    public final synchronized Drawable d(Context context, int i2, boolean z2) {
        Drawable a2;
        try {
            if (!this.f1239d) {
                this.f1239d = true;
                Drawable c2 = c(context, R.drawable.abc_vector_test);
                if (c2 == null || (!(c2 instanceof a) && !"android.graphics.drawable.VectorDrawable".equals(c2.getClass().getName()))) {
                    this.f1239d = false;
                    throw new IllegalStateException("This app has been built with an incorrect configuration. Please configure your build for VectorDrawableCompat.");
                }
            }
            a2 = a(context, i2);
            if (a2 == null) {
                a2 = C0120a.b(context, i2);
            }
            if (a2 != null) {
                a2 = g(context, i2, z2, a2);
            }
            if (a2 != null) {
                C0074o0.a(a2);
            }
        } catch (Throwable th) {
            throw th;
        }
        return a2;
    }

    public final synchronized ColorStateList f(Context context, int i2) {
        ColorStateList colorStateList;
        C0110l lVar;
        Object obj;
        WeakHashMap weakHashMap = this.f1237a;
        ColorStateList colorStateList2 = null;
        if (weakHashMap == null || (lVar = (C0110l) weakHashMap.get(context)) == null) {
            colorStateList = null;
        } else {
            int a2 = C0102d.a(lVar.f1506c, i2, lVar.f1505a);
            if (a2 < 0 || (obj = lVar.b[a2]) == C0110l.f1504d) {
                obj = null;
            }
            colorStateList = obj;
        }
        if (colorStateList == null) {
            C0084u uVar = this.f1240e;
            if (uVar != null) {
                colorStateList2 = uVar.d(context, i2);
            }
            if (colorStateList2 != null) {
                if (this.f1237a == null) {
                    this.f1237a = new WeakHashMap();
                }
                C0110l lVar2 = (C0110l) this.f1237a.get(context);
                if (lVar2 == null) {
                    lVar2 = new C0110l();
                    this.f1237a.put(context, lVar2);
                }
                lVar2.a(i2, colorStateList2);
            }
            colorStateList = colorStateList2;
        }
        return colorStateList;
    }

    /* JADX WARNING: Removed duplicated region for block: B:45:0x00e5  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final android.graphics.drawable.Drawable g(android.content.Context r8, int r9, boolean r10, android.graphics.drawable.Drawable r11) {
        /*
            r7 = this;
            android.content.res.ColorStateList r0 = r7.f(r8, r9)
            r1 = 0
            if (r0 == 0) goto L_0x0020
            android.graphics.drawable.Drawable r8 = r11.mutate()
            s.C0126a.h(r8, r0)
            i.u r10 = r7.f1240e
            if (r10 != 0) goto L_0x0013
            goto L_0x001a
        L_0x0013:
            r10 = 2131165250(0x7f070042, float:1.7944712E38)
            if (r9 != r10) goto L_0x001a
            android.graphics.PorterDuff$Mode r1 = android.graphics.PorterDuff.Mode.MULTIPLY
        L_0x001a:
            if (r1 == 0) goto L_0x001f
            s.C0126a.i(r8, r1)
        L_0x001f:
            return r8
        L_0x0020:
            i.u r0 = r7.f1240e
            if (r0 == 0) goto L_0x0094
            r0 = 2131165245(0x7f07003d, float:1.7944702E38)
            r2 = 16908301(0x102000d, float:2.3877265E-38)
            r3 = 16908303(0x102000f, float:2.387727E-38)
            r4 = 16908288(0x1020000, float:2.387723E-38)
            r5 = 2130903131(0x7f03005b, float:1.7413071E38)
            r6 = 2130903133(0x7f03005d, float:1.7413075E38)
            if (r9 != r0) goto L_0x005e
            r9 = r11
            android.graphics.drawable.LayerDrawable r9 = (android.graphics.drawable.LayerDrawable) r9
            android.graphics.drawable.Drawable r10 = r9.findDrawableByLayerId(r4)
            int r0 = i.T0.c(r8, r6)
            android.graphics.PorterDuff$Mode r1 = i.C0086v.b
            i.C0084u.e(r10, r0, r1)
            android.graphics.drawable.Drawable r10 = r9.findDrawableByLayerId(r3)
            int r0 = i.T0.c(r8, r6)
            i.C0084u.e(r10, r0, r1)
            android.graphics.drawable.Drawable r9 = r9.findDrawableByLayerId(r2)
            int r8 = i.T0.c(r8, r5)
            i.C0084u.e(r9, r8, r1)
            return r11
        L_0x005e:
            r0 = 2131165236(0x7f070034, float:1.7944683E38)
            if (r9 == r0) goto L_0x006d
            r0 = 2131165235(0x7f070033, float:1.7944681E38)
            if (r9 == r0) goto L_0x006d
            r0 = 2131165237(0x7f070035, float:1.7944685E38)
            if (r9 != r0) goto L_0x0094
        L_0x006d:
            r9 = r11
            android.graphics.drawable.LayerDrawable r9 = (android.graphics.drawable.LayerDrawable) r9
            android.graphics.drawable.Drawable r10 = r9.findDrawableByLayerId(r4)
            int r0 = i.T0.b(r8, r6)
            android.graphics.PorterDuff$Mode r1 = i.C0086v.b
            i.C0084u.e(r10, r0, r1)
            android.graphics.drawable.Drawable r10 = r9.findDrawableByLayerId(r3)
            int r0 = i.T0.c(r8, r5)
            i.C0084u.e(r10, r0, r1)
            android.graphics.drawable.Drawable r9 = r9.findDrawableByLayerId(r2)
            int r8 = i.T0.c(r8, r5)
            i.C0084u.e(r9, r8, r1)
            return r11
        L_0x0094:
            i.u r0 = r7.f1240e
            r2 = 0
            if (r0 == 0) goto L_0x0102
            android.graphics.PorterDuff$Mode r3 = i.C0086v.b
            int[] r4 = r0.f1401a
            boolean r4 = i.C0084u.a(r4, r9)
            r5 = 1
            r6 = -1
            if (r4 == 0) goto L_0x00ab
            r9 = 2130903133(0x7f03005d, float:1.7413075E38)
        L_0x00a8:
            r4 = r5
        L_0x00a9:
            r0 = r6
            goto L_0x00e3
        L_0x00ab:
            int[] r4 = r0.f1402c
            boolean r4 = i.C0084u.a(r4, r9)
            if (r4 == 0) goto L_0x00b7
            r9 = 2130903131(0x7f03005b, float:1.7413071E38)
            goto L_0x00a8
        L_0x00b7:
            int[] r0 = r0.f1403d
            boolean r0 = i.C0084u.a(r0, r9)
            r4 = 16842801(0x1010031, float:2.3693695E-38)
            if (r0 == 0) goto L_0x00c6
            android.graphics.PorterDuff$Mode r3 = android.graphics.PorterDuff.Mode.MULTIPLY
        L_0x00c4:
            r9 = r4
            goto L_0x00a8
        L_0x00c6:
            r0 = 2131165222(0x7f070026, float:1.7944655E38)
            if (r9 != r0) goto L_0x00da
            r9 = 1109603123(0x42233333, float:40.8)
            int r9 = java.lang.Math.round(r9)
            r0 = 16842800(0x1010030, float:2.3693693E-38)
            r4 = r0
            r0 = r9
            r9 = r4
            r4 = r5
            goto L_0x00e3
        L_0x00da:
            r0 = 2131165204(0x7f070014, float:1.7944619E38)
            if (r9 != r0) goto L_0x00e0
            goto L_0x00c4
        L_0x00e0:
            r9 = r2
            r4 = r9
            goto L_0x00a9
        L_0x00e3:
            if (r4 == 0) goto L_0x0102
            android.graphics.drawable.Drawable r2 = r11.mutate()
            int r8 = i.T0.c(r8, r9)
            java.lang.Class<i.v> r9 = i.C0086v.class
            monitor-enter(r9)
            android.graphics.PorterDuffColorFilter r8 = e(r8, r3)     // Catch:{ all -> 0x00ff }
            monitor-exit(r9)
            r2.setColorFilter(r8)
            if (r0 == r6) goto L_0x00fd
            r2.setAlpha(r0)
        L_0x00fd:
            r2 = r5
            goto L_0x0102
        L_0x00ff:
            r8 = move-exception
            monitor-exit(r9)     // Catch:{ all -> 0x00ff }
            throw r8
        L_0x0102:
            if (r2 != 0) goto L_0x0107
            if (r10 == 0) goto L_0x0107
            return r1
        L_0x0107:
            return r11
        */
        throw new UnsupportedOperationException("Method not decompiled: i.O0.g(android.content.Context, int, boolean, android.graphics.drawable.Drawable):android.graphics.drawable.Drawable");
    }
}
