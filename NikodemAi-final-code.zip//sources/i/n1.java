package i;

import android.os.Build;
import java.lang.reflect.Method;

public abstract class n1 {

    /* renamed from: a  reason: collision with root package name */
    public static boolean f1378a;
    public static Method b;

    /* renamed from: c  reason: collision with root package name */
    public static final boolean f1379c;

    static {
        boolean z2;
        if (Build.VERSION.SDK_INT >= 27) {
            z2 = true;
        } else {
            z2 = false;
        }
        f1379c = z2;
    }
}
