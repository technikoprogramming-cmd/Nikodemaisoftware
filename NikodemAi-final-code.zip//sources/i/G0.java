package i;

import android.view.MotionEvent;
import android.view.View;

public final class G0 implements View.OnTouchListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ H0 f1188a;

    public G0(H0 h02) {
        this.f1188a = h02;
    }

    public final boolean onTouch(View view, MotionEvent motionEvent) {
        D d2;
        int action = motionEvent.getAction();
        int x2 = (int) motionEvent.getX();
        int y2 = (int) motionEvent.getY();
        H0 h02 = this.f1188a;
        if (action == 0 && (d2 = h02.f1214y) != null && d2.isShowing() && x2 >= 0 && x2 < h02.f1214y.getWidth() && y2 >= 0 && y2 < h02.f1214y.getHeight()) {
            h02.f1210u.postDelayed(h02.f1206q, 250);
            return false;
        } else if (action != 1) {
            return false;
        } else {
            h02.f1210u.removeCallbacks(h02.f1206q);
            return false;
        }
    }
}
