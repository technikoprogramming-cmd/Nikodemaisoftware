package i;

import androidx.appcompat.widget.ActionBarOverlayLayout;

/* renamed from: i.d  reason: case insensitive filesystem */
public final class C0051d implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f1295a;
    public final /* synthetic */ ActionBarOverlayLayout b;

    public /* synthetic */ C0051d(ActionBarOverlayLayout actionBarOverlayLayout, int i2) {
        this.f1295a = i2;
        this.b = actionBarOverlayLayout;
    }

    public final void run() {
        switch (this.f1295a) {
            case 0:
                ActionBarOverlayLayout actionBarOverlayLayout = this.b;
                actionBarOverlayLayout.h();
                actionBarOverlayLayout.f430w = actionBarOverlayLayout.f412d.animate().translationY(0.0f).setListener(actionBarOverlayLayout.f431x);
                return;
            default:
                ActionBarOverlayLayout actionBarOverlayLayout2 = this.b;
                actionBarOverlayLayout2.h();
                actionBarOverlayLayout2.f430w = actionBarOverlayLayout2.f412d.animate().translationY((float) (-actionBarOverlayLayout2.f412d.getHeight())).setListener(actionBarOverlayLayout2.f431x);
                return;
        }
    }
}
