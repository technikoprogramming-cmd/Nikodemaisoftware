package i;

import D.g;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.widget.ToggleButton;

/* renamed from: i.k0  reason: case insensitive filesystem */
public final class C0066k0 extends ToggleButton {

    /* renamed from: a  reason: collision with root package name */
    public final C0077q f1350a;
    public final C0046a0 b;

    /* renamed from: c  reason: collision with root package name */
    public C0092y f1351c;

    public C0066k0(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 16842827);
        T0.a(this, getContext());
        C0077q qVar = new C0077q(this);
        this.f1350a = qVar;
        qVar.d(attributeSet, 16842827);
        C0046a0 a0Var = new C0046a0(this);
        this.b = a0Var;
        a0Var.f(attributeSet, 16842827);
        getEmojiTextViewHelper().a(attributeSet, 16842827);
    }

    private C0092y getEmojiTextViewHelper() {
        if (this.f1351c == null) {
            this.f1351c = new C0092y(this);
        }
        return this.f1351c;
    }

    public final void drawableStateChanged() {
        super.drawableStateChanged();
        C0077q qVar = this.f1350a;
        if (qVar != null) {
            qVar.a();
        }
        C0046a0 a0Var = this.b;
        if (a0Var != null) {
            a0Var.b();
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        C0077q qVar = this.f1350a;
        if (qVar != null) {
            return qVar.b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0077q qVar = this.f1350a;
        if (qVar != null) {
            return qVar.c();
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.b.d();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.b.e();
    }

    public void setAllCaps(boolean z2) {
        super.setAllCaps(z2);
        getEmojiTextViewHelper().b(z2);
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0077q qVar = this.f1350a;
        if (qVar != null) {
            qVar.e();
        }
    }

    public void setBackgroundResource(int i2) {
        super.setBackgroundResource(i2);
        C0077q qVar = this.f1350a;
        if (qVar != null) {
            qVar.f(i2);
        }
    }

    public final void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        C0046a0 a0Var = this.b;
        if (a0Var != null) {
            a0Var.b();
        }
    }

    public final void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        C0046a0 a0Var = this.b;
        if (a0Var != null) {
            a0Var.b();
        }
    }

    public void setEmojiCompatEnabled(boolean z2) {
        getEmojiTextViewHelper().c(z2);
    }

    public void setFilters(InputFilter[] inputFilterArr) {
        super.setFilters(((g) getEmojiTextViewHelper().b.b).u(inputFilterArr));
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C0077q qVar = this.f1350a;
        if (qVar != null) {
            qVar.h(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C0077q qVar = this.f1350a;
        if (qVar != null) {
            qVar.i(mode);
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        C0046a0 a0Var = this.b;
        a0Var.l(colorStateList);
        a0Var.b();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        C0046a0 a0Var = this.b;
        a0Var.m(mode);
        a0Var.b();
    }
}
