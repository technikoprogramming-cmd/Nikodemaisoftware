package i;

import android.view.View;
import h.l;
import h.n;

/* renamed from: i.j  reason: case insensitive filesystem */
public final class C0063j implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final C0059h f1332a;
    public final /* synthetic */ C0067l b;

    public C0063j(C0067l lVar, C0059h hVar) {
        this.b = lVar;
        this.f1332a = hVar;
    }

    public final void run() {
        l lVar;
        C0067l lVar2 = this.b;
        n nVar = lVar2.f1354c;
        if (!(nVar == null || (lVar = nVar.f1105e) == null)) {
            lVar.g(nVar);
        }
        View view = (View) lVar2.f1358h;
        if (!(view == null || view.getWindowToken() == null)) {
            C0059h hVar = this.f1332a;
            if (!hVar.b()) {
                if (hVar.f1165e != null) {
                    hVar.d(0, 0, false, false);
                }
            }
            lVar2.f1369s = hVar;
        }
        lVar2.f1371u = null;
    }
}
