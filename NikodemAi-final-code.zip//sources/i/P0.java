package i;

import android.content.res.Resources;

public abstract class P0 extends Resources {
}
