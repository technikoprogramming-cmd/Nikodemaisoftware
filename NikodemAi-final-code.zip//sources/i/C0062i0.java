package i;

import android.text.StaticLayout;
import android.widget.TextView;

/* renamed from: i.i0  reason: case insensitive filesystem */
public abstract class C0062i0 {
    public abstract void a(StaticLayout.Builder builder, TextView textView);

    public boolean b(TextView textView) {
        return ((Boolean) C0064j0.e(textView, "getHorizontallyScrolling", Boolean.FALSE)).booleanValue();
    }
}
