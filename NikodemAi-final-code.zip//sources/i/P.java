package i;

import android.content.Context;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ViewTreeObserver;
import android.widget.ListAdapter;
import h.C0041d;
import ncs.oprogramowanie.nikodemai.aos.R;

public final class P extends H0 implements S {

    /* renamed from: B  reason: collision with root package name */
    public CharSequence f1241B;

    /* renamed from: C  reason: collision with root package name */
    public M f1242C;

    /* renamed from: D  reason: collision with root package name */
    public final Rect f1243D = new Rect();

    /* renamed from: E  reason: collision with root package name */
    public int f1244E;

    /* renamed from: F  reason: collision with root package name */
    public final /* synthetic */ T f1245F;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public P(T t2, Context context, AttributeSet attributeSet) {
        super(context, attributeSet, R.attr.spinnerStyle);
        this.f1245F = t2;
        this.f1204o = t2;
        this.f1213x = true;
        this.f1214y.setFocusable(true);
        this.f1205p = new N(this);
    }

    public final CharSequence b() {
        return this.f1241B;
    }

    public final void e(int i2, int i3) {
        ViewTreeObserver viewTreeObserver;
        D d2 = this.f1214y;
        boolean isShowing = d2.isShowing();
        q();
        this.f1214y.setInputMethodMode(2);
        h();
        C0085u0 u0Var = this.f1193c;
        u0Var.setChoiceMode(1);
        u0Var.setTextDirection(i2);
        u0Var.setTextAlignment(i3);
        T t2 = this.f1245F;
        int selectedItemPosition = t2.getSelectedItemPosition();
        C0085u0 u0Var2 = this.f1193c;
        if (d2.isShowing() && u0Var2 != null) {
            u0Var2.setListSelectionHidden(false);
            u0Var2.setSelection(selectedItemPosition);
            if (u0Var2.getChoiceMode() != 0) {
                u0Var2.setItemChecked(selectedItemPosition, true);
            }
        }
        if (!isShowing && (viewTreeObserver = t2.getViewTreeObserver()) != null) {
            C0041d dVar = new C0041d(3, this);
            viewTreeObserver.addOnGlobalLayoutListener(dVar);
            this.f1214y.setOnDismissListener(new O(this, dVar));
        }
    }

    public final void g(CharSequence charSequence) {
        this.f1241B = charSequence;
    }

    public final void m(ListAdapter listAdapter) {
        super.m(listAdapter);
        this.f1242C = (M) listAdapter;
    }

    public final void n(int i2) {
        this.f1244E = i2;
    }

    public final void q() {
        int i2;
        int i3;
        D d2 = this.f1214y;
        Drawable background = d2.getBackground();
        T t2 = this.f1245F;
        if (background != null) {
            background.getPadding(t2.f1259h);
            boolean z2 = n1.f1378a;
            int layoutDirection = t2.getLayoutDirection();
            Rect rect = t2.f1259h;
            if (layoutDirection == 1) {
                i2 = rect.right;
            } else {
                i2 = -rect.left;
            }
        } else {
            Rect rect2 = t2.f1259h;
            rect2.right = 0;
            rect2.left = 0;
            i2 = 0;
        }
        int paddingLeft = t2.getPaddingLeft();
        int paddingRight = t2.getPaddingRight();
        int width = t2.getWidth();
        int i4 = t2.f1258g;
        if (i4 == -2) {
            int a2 = t2.a(this.f1242C, d2.getBackground());
            int i5 = t2.getContext().getResources().getDisplayMetrics().widthPixels;
            Rect rect3 = t2.f1259h;
            int i6 = (i5 - rect3.left) - rect3.right;
            if (a2 > i6) {
                a2 = i6;
            }
            p(Math.max(a2, (width - paddingLeft) - paddingRight));
        } else if (i4 == -1) {
            p((width - paddingLeft) - paddingRight);
        } else {
            p(i4);
        }
        boolean z3 = n1.f1378a;
        if (t2.getLayoutDirection() == 1) {
            i3 = (((width - paddingRight) - this.f1195e) - this.f1244E) + i2;
        } else {
            i3 = paddingLeft + this.f1244E + i2;
        }
        this.f = i3;
    }
}
