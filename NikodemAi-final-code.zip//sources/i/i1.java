package i;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.Resources;
import android.graphics.Rect;
import android.os.Build;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityManager;
import java.util.WeakHashMap;
import ncs.oprogramowanie.nikodemai.aos.R;
import y.K;
import y.L;
import y.N;

public final class i1 implements View.OnLongClickListener, View.OnHoverListener, View.OnAttachStateChangeListener {

    /* renamed from: k  reason: collision with root package name */
    public static i1 f1322k;

    /* renamed from: l  reason: collision with root package name */
    public static i1 f1323l;

    /* renamed from: a  reason: collision with root package name */
    public final View f1324a;
    public final CharSequence b;

    /* renamed from: c  reason: collision with root package name */
    public final int f1325c;

    /* renamed from: d  reason: collision with root package name */
    public final h1 f1326d = new h1(this, 0);

    /* renamed from: e  reason: collision with root package name */
    public final h1 f1327e = new h1(this, 1);
    public int f;

    /* renamed from: g  reason: collision with root package name */
    public int f1328g;

    /* renamed from: h  reason: collision with root package name */
    public j1 f1329h;

    /* renamed from: i  reason: collision with root package name */
    public boolean f1330i;

    /* renamed from: j  reason: collision with root package name */
    public boolean f1331j;

    public i1(View view, CharSequence charSequence) {
        int i2;
        this.f1324a = view;
        this.b = charSequence;
        ViewConfiguration viewConfiguration = ViewConfiguration.get(view.getContext());
        int i3 = N.f1637a;
        if (Build.VERSION.SDK_INT >= 28) {
            i2 = L.a(viewConfiguration);
        } else {
            i2 = viewConfiguration.getScaledTouchSlop() / 2;
        }
        this.f1325c = i2;
        this.f1331j = true;
        view.setOnLongClickListener(this);
        view.setOnHoverListener(this);
    }

    public static void b(i1 i1Var) {
        i1 i1Var2 = f1322k;
        if (i1Var2 != null) {
            i1Var2.f1324a.removeCallbacks(i1Var2.f1326d);
        }
        f1322k = i1Var;
        if (i1Var != null) {
            i1Var.f1324a.postDelayed(i1Var.f1326d, (long) ViewConfiguration.getLongPressTimeout());
        }
    }

    public final void a() {
        i1 i1Var = f1323l;
        View view = this.f1324a;
        if (i1Var == this) {
            f1323l = null;
            j1 j1Var = this.f1329h;
            if (j1Var != null) {
                View view2 = j1Var.b;
                if (view2.getParent() != null) {
                    ((WindowManager) j1Var.f1344a.getSystemService("window")).removeView(view2);
                }
                this.f1329h = null;
                this.f1331j = true;
                view.removeOnAttachStateChangeListener(this);
            } else {
                Log.e("TooltipCompatHandler", "sActiveHandler.mPopup == null");
            }
        }
        if (f1322k == this) {
            b((i1) null);
        }
        view.removeCallbacks(this.f1327e);
    }

    public final void c(boolean z2) {
        int i2;
        int i3;
        int i4;
        int i5;
        long j2;
        long longPressTimeout;
        long j3;
        int i6;
        int i7;
        int i8;
        int i9;
        View view = this.f1324a;
        if (view.isAttachedToWindow()) {
            b((i1) null);
            i1 i1Var = f1323l;
            if (i1Var != null) {
                i1Var.a();
            }
            f1323l = this;
            this.f1330i = z2;
            j1 j1Var = new j1(view.getContext());
            this.f1329h = j1Var;
            int i10 = this.f;
            int i11 = this.f1328g;
            boolean z3 = this.f1330i;
            View view2 = j1Var.b;
            ViewParent parent = view2.getParent();
            Context context = j1Var.f1344a;
            if (!(parent == null || view2.getParent() == null)) {
                ((WindowManager) context.getSystemService("window")).removeView(view2);
            }
            j1Var.f1345c.setText(this.b);
            WindowManager.LayoutParams layoutParams = j1Var.f1346d;
            layoutParams.token = view.getApplicationWindowToken();
            int dimensionPixelOffset = context.getResources().getDimensionPixelOffset(R.dimen.tooltip_precise_anchor_threshold);
            if (view.getWidth() < dimensionPixelOffset) {
                i10 = view.getWidth() / 2;
            }
            if (view.getHeight() >= dimensionPixelOffset) {
                int dimensionPixelOffset2 = context.getResources().getDimensionPixelOffset(R.dimen.tooltip_precise_anchor_extra_offset);
                i2 = i11 + dimensionPixelOffset2;
                i3 = i11 - dimensionPixelOffset2;
            } else {
                i2 = view.getHeight();
                i3 = 0;
            }
            layoutParams.gravity = 49;
            Resources resources = context.getResources();
            if (z3) {
                i4 = R.dimen.tooltip_y_offset_touch;
            } else {
                i4 = R.dimen.tooltip_y_offset_non_touch;
            }
            int dimensionPixelOffset3 = resources.getDimensionPixelOffset(i4);
            View rootView = view.getRootView();
            ViewGroup.LayoutParams layoutParams2 = rootView.getLayoutParams();
            if (!(layoutParams2 instanceof WindowManager.LayoutParams) || ((WindowManager.LayoutParams) layoutParams2).type != 2) {
                Context context2 = view.getContext();
                while (true) {
                    if (!(context2 instanceof ContextWrapper)) {
                        break;
                    } else if (context2 instanceof Activity) {
                        rootView = ((Activity) context2).getWindow().getDecorView();
                        break;
                    } else {
                        context2 = ((ContextWrapper) context2).getBaseContext();
                    }
                }
            }
            if (rootView == null) {
                Log.e("TooltipPopup", "Cannot find app view");
                i5 = 1;
            } else {
                Rect rect = j1Var.f1347e;
                rootView.getWindowVisibleDisplayFrame(rect);
                if (rect.left >= 0 || rect.top >= 0) {
                    i7 = i10;
                    i6 = i3;
                    i8 = 0;
                    i5 = 1;
                } else {
                    Resources resources2 = context.getResources();
                    i5 = 1;
                    i7 = i10;
                    i6 = i3;
                    int identifier = resources2.getIdentifier("status_bar_height", "dimen", "android");
                    if (identifier != 0) {
                        i9 = resources2.getDimensionPixelSize(identifier);
                    } else {
                        i9 = 0;
                    }
                    DisplayMetrics displayMetrics = resources2.getDisplayMetrics();
                    i8 = 0;
                    rect.set(0, i9, displayMetrics.widthPixels, displayMetrics.heightPixels);
                }
                int[] iArr = j1Var.f1348g;
                rootView.getLocationOnScreen(iArr);
                int[] iArr2 = j1Var.f;
                view.getLocationOnScreen(iArr2);
                int i12 = iArr2[i8] - iArr[i8];
                iArr2[i8] = i12;
                iArr2[i5] = iArr2[i5] - iArr[i5];
                layoutParams.x = (i12 + i7) - (rootView.getWidth() / 2);
                int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(i8, i8);
                view2.measure(makeMeasureSpec, makeMeasureSpec);
                int measuredHeight = view2.getMeasuredHeight();
                int i13 = iArr2[i5];
                int i14 = ((i13 + i6) - dimensionPixelOffset3) - measuredHeight;
                int i15 = i13 + i2 + dimensionPixelOffset3;
                if (z3) {
                    if (i14 >= 0) {
                        layoutParams.y = i14;
                    } else {
                        layoutParams.y = i15;
                    }
                } else if (measuredHeight + i15 <= rect.height()) {
                    layoutParams.y = i15;
                } else {
                    layoutParams.y = i14;
                }
            }
            ((WindowManager) context.getSystemService("window")).addView(view2, layoutParams);
            view.addOnAttachStateChangeListener(this);
            if (this.f1330i) {
                j2 = 2500;
            } else {
                WeakHashMap weakHashMap = K.f1633a;
                if ((view.getWindowSystemUiVisibility() & 1) == i5) {
                    longPressTimeout = (long) ViewConfiguration.getLongPressTimeout();
                    j3 = 3000;
                } else {
                    longPressTimeout = (long) ViewConfiguration.getLongPressTimeout();
                    j3 = 15000;
                }
                j2 = j3 - longPressTimeout;
            }
            h1 h1Var = this.f1327e;
            view.removeCallbacks(h1Var);
            view.postDelayed(h1Var, j2);
        }
    }

    public final boolean onHover(View view, MotionEvent motionEvent) {
        int i2;
        if (this.f1329h == null || !this.f1330i) {
            View view2 = this.f1324a;
            AccessibilityManager accessibilityManager = (AccessibilityManager) view2.getContext().getSystemService("accessibility");
            if (!accessibilityManager.isEnabled() || !accessibilityManager.isTouchExplorationEnabled()) {
                int action = motionEvent.getAction();
                if (action != 7) {
                    if (action == 10) {
                        this.f1331j = true;
                        a();
                        return false;
                    }
                } else if (view2.isEnabled() && this.f1329h == null) {
                    int x2 = (int) motionEvent.getX();
                    int y2 = (int) motionEvent.getY();
                    if (this.f1331j || Math.abs(x2 - this.f) > (i2 = this.f1325c) || Math.abs(y2 - this.f1328g) > i2) {
                        this.f = x2;
                        this.f1328g = y2;
                        this.f1331j = false;
                        b(this);
                    }
                }
            }
        }
        return false;
    }

    public final boolean onLongClick(View view) {
        this.f = view.getWidth() / 2;
        this.f1328g = view.getHeight() / 2;
        c(true);
        return true;
    }

    public final void onViewDetachedFromWindow(View view) {
        a();
    }

    public final void onViewAttachedToWindow(View view) {
    }
}
