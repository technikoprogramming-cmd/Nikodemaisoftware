package i;

import android.view.View;
import android.widget.AdapterView;

public final class A0 implements AdapterView.OnItemSelectedListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ H0 f1173a;

    public A0(H0 h02) {
        this.f1173a = h02;
    }

    public final void onItemSelected(AdapterView adapterView, View view, int i2, long j2) {
        C0085u0 u0Var;
        if (i2 != -1 && (u0Var = this.f1173a.f1193c) != null) {
            u0Var.setListSelectionHidden(false);
        }
    }

    public final void onNothingSelected(AdapterView adapterView) {
    }
}
