package i;

public final class Q0 {

    /* renamed from: a  reason: collision with root package name */
    public int f1247a;
    public int b;

    /* renamed from: c  reason: collision with root package name */
    public int f1248c;

    /* renamed from: d  reason: collision with root package name */
    public int f1249d;

    /* renamed from: e  reason: collision with root package name */
    public int f1250e;
    public int f;

    /* renamed from: g  reason: collision with root package name */
    public boolean f1251g;

    /* renamed from: h  reason: collision with root package name */
    public boolean f1252h;

    public final void a(int i2, int i3) {
        this.f1248c = i2;
        this.f1249d = i3;
        this.f1252h = true;
        if (this.f1251g) {
            if (i3 != Integer.MIN_VALUE) {
                this.f1247a = i3;
            }
            if (i2 != Integer.MIN_VALUE) {
                this.b = i2;
                return;
            }
            return;
        }
        if (i2 != Integer.MIN_VALUE) {
            this.f1247a = i2;
        }
        if (i3 != Integer.MIN_VALUE) {
            this.b = i3;
        }
    }
}
