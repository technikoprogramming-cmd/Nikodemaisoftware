package i;

import android.view.Window;

/* renamed from: i.m0  reason: case insensitive filesystem */
public interface C0070m0 {
    void setWindowCallback(Window.Callback callback);

    void setWindowTitle(CharSequence charSequence);
}
