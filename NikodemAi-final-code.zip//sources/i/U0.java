package i;

import android.content.Context;
import android.content.ContextWrapper;

public abstract class U0 extends ContextWrapper {

    /* renamed from: a  reason: collision with root package name */
    public static final Object f1265a = null;

    public static void a(Context context) {
        if (!(context.getResources() instanceof W0)) {
            context.getResources();
            int i2 = k1.f1352a;
        }
    }
}
