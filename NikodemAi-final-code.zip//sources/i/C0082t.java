package i;

import D.g;
import M.e;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.view.ActionMode;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.CheckedTextView;

/* renamed from: i.t  reason: case insensitive filesystem */
public final class C0082t extends CheckedTextView {

    /* renamed from: a  reason: collision with root package name */
    public final e f1397a = new e(this);
    public final C0077q b;

    /* renamed from: c  reason: collision with root package name */
    public final C0046a0 f1398c;

    /* renamed from: d  reason: collision with root package name */
    public C0092y f1399d;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    /* JADX WARNING: Can't wrap try/catch for region: R(13:0|1|2|(2:6|7)|10|11|(1:15)|16|(1:18)|19|(1:21)|22|23) */
    /* JADX WARNING: Missing exception handler attribute for start block: B:10:0x0067 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public C0082t(android.content.Context r8, android.util.AttributeSet r9) {
        /*
            r7 = this;
            i.U0.a(r8)
            r6 = 2130903122(0x7f030052, float:1.7413053E38)
            r7.<init>(r8, r9, r6)
            android.content.Context r8 = r7.getContext()
            i.T0.a(r7, r8)
            i.a0 r8 = new i.a0
            r8.<init>(r7)
            r7.f1398c = r8
            r8.f(r9, r6)
            r8.b()
            i.q r8 = new i.q
            r8.<init>(r7)
            r7.b = r8
            r8.d(r9, r6)
            M.e r8 = new M.e
            r8.<init>(r7)
            r7.f1397a = r8
            android.content.Context r8 = r7.getContext()
            int[] r3 = d.C0010a.f780l
            C.h r8 = C.h.m(r8, r9, r3, r6)
            java.lang.Object r0 = r8.b
            android.content.res.TypedArray r0 = (android.content.res.TypedArray) r0
            android.content.Context r2 = r7.getContext()
            java.lang.Object r1 = r8.b
            r5 = r1
            android.content.res.TypedArray r5 = (android.content.res.TypedArray) r5
            r1 = r7
            r4 = r9
            y.K.g(r1, r2, r3, r4, r5, r6)
            r9 = 1
            boolean r2 = r0.hasValue(r9)     // Catch:{ all -> 0x0064 }
            r3 = 0
            if (r2 == 0) goto L_0x0067
            int r9 = r0.getResourceId(r9, r3)     // Catch:{ all -> 0x0064 }
            if (r9 == 0) goto L_0x0067
            android.content.Context r2 = r7.getContext()     // Catch:{ NotFoundException -> 0x0067 }
            android.graphics.drawable.Drawable r9 = D.g.s(r2, r9)     // Catch:{ NotFoundException -> 0x0067 }
            r7.setCheckMarkDrawable((android.graphics.drawable.Drawable) r9)     // Catch:{ NotFoundException -> 0x0067 }
            goto L_0x007e
        L_0x0064:
            r0 = move-exception
            r9 = r0
            goto L_0x00ab
        L_0x0067:
            boolean r9 = r0.hasValue(r3)     // Catch:{ all -> 0x0064 }
            if (r9 == 0) goto L_0x007e
            int r9 = r0.getResourceId(r3, r3)     // Catch:{ all -> 0x0064 }
            if (r9 == 0) goto L_0x007e
            android.content.Context r2 = r7.getContext()     // Catch:{ all -> 0x0064 }
            android.graphics.drawable.Drawable r9 = D.g.s(r2, r9)     // Catch:{ all -> 0x0064 }
            r7.setCheckMarkDrawable((android.graphics.drawable.Drawable) r9)     // Catch:{ all -> 0x0064 }
        L_0x007e:
            r9 = 2
            boolean r2 = r0.hasValue(r9)     // Catch:{ all -> 0x0064 }
            if (r2 == 0) goto L_0x008c
            android.content.res.ColorStateList r9 = r8.h(r9)     // Catch:{ all -> 0x0064 }
            r7.setCheckMarkTintList(r9)     // Catch:{ all -> 0x0064 }
        L_0x008c:
            r9 = 3
            boolean r2 = r0.hasValue(r9)     // Catch:{ all -> 0x0064 }
            if (r2 == 0) goto L_0x00a0
            r2 = -1
            int r9 = r0.getInt(r9, r2)     // Catch:{ all -> 0x0064 }
            r0 = 0
            android.graphics.PorterDuff$Mode r9 = i.C0074o0.b(r9, r0)     // Catch:{ all -> 0x0064 }
            r7.setCheckMarkTintMode(r9)     // Catch:{ all -> 0x0064 }
        L_0x00a0:
            r8.r()
            i.y r8 = r7.getEmojiTextViewHelper()
            r8.a(r4, r6)
            return
        L_0x00ab:
            r8.r()
            throw r9
        */
        throw new UnsupportedOperationException("Method not decompiled: i.C0082t.<init>(android.content.Context, android.util.AttributeSet):void");
    }

    private C0092y getEmojiTextViewHelper() {
        if (this.f1399d == null) {
            this.f1399d = new C0092y(this);
        }
        return this.f1399d;
    }

    public final void drawableStateChanged() {
        super.drawableStateChanged();
        C0046a0 a0Var = this.f1398c;
        if (a0Var != null) {
            a0Var.b();
        }
        C0077q qVar = this.b;
        if (qVar != null) {
            qVar.a();
        }
        e eVar = this.f1397a;
        if (eVar != null) {
            eVar.b();
        }
    }

    public ActionMode.Callback getCustomSelectionActionModeCallback() {
        return g.T(super.getCustomSelectionActionModeCallback());
    }

    public ColorStateList getSupportBackgroundTintList() {
        C0077q qVar = this.b;
        if (qVar != null) {
            return qVar.b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0077q qVar = this.b;
        if (qVar != null) {
            return qVar.c();
        }
        return null;
    }

    public ColorStateList getSupportCheckMarkTintList() {
        e eVar = this.f1397a;
        if (eVar != null) {
            return (ColorStateList) eVar.f118e;
        }
        return null;
    }

    public PorterDuff.Mode getSupportCheckMarkTintMode() {
        e eVar = this.f1397a;
        if (eVar != null) {
            return (PorterDuff.Mode) eVar.f;
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.f1398c.d();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.f1398c.e();
    }

    public final InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        InputConnection onCreateInputConnection = super.onCreateInputConnection(editorInfo);
        g.D(editorInfo, onCreateInputConnection, this);
        return onCreateInputConnection;
    }

    public void setAllCaps(boolean z2) {
        super.setAllCaps(z2);
        getEmojiTextViewHelper().b(z2);
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0077q qVar = this.b;
        if (qVar != null) {
            qVar.e();
        }
    }

    public void setBackgroundResource(int i2) {
        super.setBackgroundResource(i2);
        C0077q qVar = this.b;
        if (qVar != null) {
            qVar.f(i2);
        }
    }

    public void setCheckMarkDrawable(Drawable drawable) {
        super.setCheckMarkDrawable(drawable);
        e eVar = this.f1397a;
        if (eVar == null) {
            return;
        }
        if (eVar.f116c) {
            eVar.f116c = false;
            return;
        }
        eVar.f116c = true;
        eVar.b();
    }

    public final void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        C0046a0 a0Var = this.f1398c;
        if (a0Var != null) {
            a0Var.b();
        }
    }

    public final void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        C0046a0 a0Var = this.f1398c;
        if (a0Var != null) {
            a0Var.b();
        }
    }

    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(g.U(callback, this));
    }

    public void setEmojiCompatEnabled(boolean z2) {
        getEmojiTextViewHelper().c(z2);
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C0077q qVar = this.b;
        if (qVar != null) {
            qVar.h(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C0077q qVar = this.b;
        if (qVar != null) {
            qVar.i(mode);
        }
    }

    public void setSupportCheckMarkTintList(ColorStateList colorStateList) {
        e eVar = this.f1397a;
        if (eVar != null) {
            eVar.f118e = colorStateList;
            eVar.f115a = true;
            eVar.b();
        }
    }

    public void setSupportCheckMarkTintMode(PorterDuff.Mode mode) {
        e eVar = this.f1397a;
        if (eVar != null) {
            eVar.f = mode;
            eVar.b = true;
            eVar.b();
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        C0046a0 a0Var = this.f1398c;
        a0Var.l(colorStateList);
        a0Var.b();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        C0046a0 a0Var = this.f1398c;
        a0Var.m(mode);
        a0Var.b();
    }

    public final void setTextAppearance(Context context, int i2) {
        super.setTextAppearance(context, i2);
        C0046a0 a0Var = this.f1398c;
        if (a0Var != null) {
            a0Var.g(context, i2);
        }
    }

    public void setCheckMarkDrawable(int i2) {
        setCheckMarkDrawable(g.s(getContext(), i2));
    }
}
