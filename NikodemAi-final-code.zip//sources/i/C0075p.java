package i;

import C.h;
import D.g;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.method.KeyListener;
import android.text.method.NumberKeyListener;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;
import ncs.oprogramowanie.nikodemai.aos.R;

/* renamed from: i.p  reason: case insensitive filesystem */
public class C0075p extends AutoCompleteTextView {

    /* renamed from: d  reason: collision with root package name */
    public static final int[] f1381d = {16843126};

    /* renamed from: a  reason: collision with root package name */
    public final C0077q f1382a;
    public final C0046a0 b;

    /* renamed from: c  reason: collision with root package name */
    public final E f1383c;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public C0075p(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, R.attr.autoCompleteTextViewStyle);
        U0.a(context);
        T0.a(this, getContext());
        h m2 = h.m(getContext(), attributeSet, f1381d, R.attr.autoCompleteTextViewStyle);
        if (((TypedArray) m2.b).hasValue(0)) {
            setDropDownBackgroundDrawable(m2.i(0));
        }
        m2.r();
        C0077q qVar = new C0077q(this);
        this.f1382a = qVar;
        qVar.d(attributeSet, R.attr.autoCompleteTextViewStyle);
        C0046a0 a0Var = new C0046a0(this);
        this.b = a0Var;
        a0Var.f(attributeSet, R.attr.autoCompleteTextViewStyle);
        a0Var.b();
        E e2 = new E((EditText) this);
        this.f1383c = e2;
        e2.b(attributeSet, R.attr.autoCompleteTextViewStyle);
        KeyListener keyListener = getKeyListener();
        if (!(keyListener instanceof NumberKeyListener)) {
            boolean isFocusable = super.isFocusable();
            boolean isClickable = super.isClickable();
            boolean isLongClickable = super.isLongClickable();
            int inputType = super.getInputType();
            KeyListener a2 = e2.a(keyListener);
            if (a2 != keyListener) {
                super.setKeyListener(a2);
                super.setRawInputType(inputType);
                super.setFocusable(isFocusable);
                super.setClickable(isClickable);
                super.setLongClickable(isLongClickable);
            }
        }
    }

    public final void drawableStateChanged() {
        super.drawableStateChanged();
        C0077q qVar = this.f1382a;
        if (qVar != null) {
            qVar.a();
        }
        C0046a0 a0Var = this.b;
        if (a0Var != null) {
            a0Var.b();
        }
    }

    public ActionMode.Callback getCustomSelectionActionModeCallback() {
        return g.T(super.getCustomSelectionActionModeCallback());
    }

    public ColorStateList getSupportBackgroundTintList() {
        C0077q qVar = this.f1382a;
        if (qVar != null) {
            return qVar.b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0077q qVar = this.f1382a;
        if (qVar != null) {
            return qVar.c();
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.b.d();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.b.e();
    }

    public InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        InputConnection onCreateInputConnection = super.onCreateInputConnection(editorInfo);
        g.D(editorInfo, onCreateInputConnection, this);
        return this.f1383c.c(onCreateInputConnection, editorInfo);
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0077q qVar = this.f1382a;
        if (qVar != null) {
            qVar.e();
        }
    }

    public void setBackgroundResource(int i2) {
        super.setBackgroundResource(i2);
        C0077q qVar = this.f1382a;
        if (qVar != null) {
            qVar.f(i2);
        }
    }

    public final void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        C0046a0 a0Var = this.b;
        if (a0Var != null) {
            a0Var.b();
        }
    }

    public final void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        C0046a0 a0Var = this.b;
        if (a0Var != null) {
            a0Var.b();
        }
    }

    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(g.U(callback, this));
    }

    public void setDropDownBackgroundResource(int i2) {
        setDropDownBackgroundDrawable(g.s(getContext(), i2));
    }

    public void setEmojiCompatEnabled(boolean z2) {
        this.f1383c.d(z2);
    }

    public void setKeyListener(KeyListener keyListener) {
        super.setKeyListener(this.f1383c.a(keyListener));
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C0077q qVar = this.f1382a;
        if (qVar != null) {
            qVar.h(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C0077q qVar = this.f1382a;
        if (qVar != null) {
            qVar.i(mode);
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        C0046a0 a0Var = this.b;
        a0Var.l(colorStateList);
        a0Var.b();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        C0046a0 a0Var = this.b;
        a0Var.m(mode);
        a0Var.b();
    }

    public final void setTextAppearance(Context context, int i2) {
        super.setTextAppearance(context, i2);
        C0046a0 a0Var = this.b;
        if (a0Var != null) {
            a0Var.g(context, i2);
        }
    }
}
