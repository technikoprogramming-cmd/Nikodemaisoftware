package i;

import D.b;
import D.i;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListAdapter;
import android.widget.ListView;
import java.lang.reflect.InvocationTargetException;
import ncs.oprogramowanie.nikodemai.aos.R;

/* renamed from: i.u0  reason: case insensitive filesystem */
public class C0085u0 extends ListView {

    /* renamed from: a  reason: collision with root package name */
    public final Rect f1405a = new Rect();
    public int b = 0;

    /* renamed from: c  reason: collision with root package name */
    public int f1406c = 0;

    /* renamed from: d  reason: collision with root package name */
    public int f1407d = 0;

    /* renamed from: e  reason: collision with root package name */
    public int f1408e = 0;
    public int f;

    /* renamed from: g  reason: collision with root package name */
    public C0081s0 f1409g;

    /* renamed from: h  reason: collision with root package name */
    public boolean f1410h;

    /* renamed from: i  reason: collision with root package name */
    public final boolean f1411i;

    /* renamed from: j  reason: collision with root package name */
    public boolean f1412j;

    /* renamed from: k  reason: collision with root package name */
    public i f1413k;

    /* renamed from: l  reason: collision with root package name */
    public b f1414l;

    public C0085u0(Context context, boolean z2) {
        super(context, (AttributeSet) null, R.attr.dropDownListViewStyle);
        this.f1411i = z2;
        setCacheColorHint(0);
    }

    public final int a(int i2, int i3) {
        int i4;
        int listPaddingTop = getListPaddingTop();
        int listPaddingBottom = getListPaddingBottom();
        int dividerHeight = getDividerHeight();
        Drawable divider = getDivider();
        ListAdapter adapter = getAdapter();
        if (adapter == null) {
            return listPaddingTop + listPaddingBottom;
        }
        int i5 = listPaddingTop + listPaddingBottom;
        if (dividerHeight <= 0 || divider == null) {
            dividerHeight = 0;
        }
        int count = adapter.getCount();
        int i6 = 0;
        View view = null;
        for (int i7 = 0; i7 < count; i7++) {
            int itemViewType = adapter.getItemViewType(i7);
            if (itemViewType != i6) {
                view = null;
                i6 = itemViewType;
            }
            view = adapter.getView(i7, view, this);
            ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
            if (layoutParams == null) {
                layoutParams = generateDefaultLayoutParams();
                view.setLayoutParams(layoutParams);
            }
            int i8 = layoutParams.height;
            if (i8 > 0) {
                i4 = View.MeasureSpec.makeMeasureSpec(i8, 1073741824);
            } else {
                i4 = View.MeasureSpec.makeMeasureSpec(0, 0);
            }
            view.measure(i2, i4);
            view.forceLayout();
            if (i7 > 0) {
                i5 += dividerHeight;
            }
            i5 += view.getMeasuredHeight();
            if (i5 >= i3) {
                return i3;
            }
        }
        return i5;
    }

    /* JADX WARNING: Removed duplicated region for block: B:12:0x0022  */
    /* JADX WARNING: Removed duplicated region for block: B:81:0x0162  */
    /* JADX WARNING: Removed duplicated region for block: B:83:0x0167  */
    /* JADX WARNING: Removed duplicated region for block: B:87:0x017d  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean b(android.view.MotionEvent r18, int r19) {
        /*
            r17 = this;
            r1 = r17
            r2 = r18
            int r3 = r2.getActionMasked()
            r4 = 1
            r5 = 0
            if (r3 == r4) goto L_0x001a
            r0 = 2
            if (r3 == r0) goto L_0x0018
            r0 = 3
            if (r3 == r0) goto L_0x0015
            r0 = r4
            goto L_0x0148
        L_0x0015:
            r0 = r5
            goto L_0x0148
        L_0x0018:
            r0 = r4
            goto L_0x001b
        L_0x001a:
            r0 = r5
        L_0x001b:
            int r6 = r18.findPointerIndex(r19)
            if (r6 >= 0) goto L_0x0022
            goto L_0x0015
        L_0x0022:
            float r7 = r2.getX(r6)
            int r7 = (int) r7
            float r6 = r2.getY(r6)
            int r6 = (int) r6
            int r8 = r1.pointToPosition(r7, r6)
            r9 = -1
            if (r8 != r9) goto L_0x0036
            r5 = r4
            goto L_0x0148
        L_0x0036:
            int r0 = r1.getFirstVisiblePosition()
            int r0 = r8 - r0
            android.view.View r10 = r1.getChildAt(r0)
            float r7 = (float) r7
            float r6 = (float) r6
            r1.f1412j = r4
            int r0 = android.os.Build.VERSION.SDK_INT
            i.C0076p0.a(r1, r7, r6)
            boolean r11 = r1.isPressed()
            if (r11 != 0) goto L_0x0052
            r1.setPressed(r4)
        L_0x0052:
            r1.layoutChildren()
            int r11 = r1.f
            if (r11 == r9) goto L_0x006f
            int r12 = r1.getFirstVisiblePosition()
            int r11 = r11 - r12
            android.view.View r11 = r1.getChildAt(r11)
            if (r11 == 0) goto L_0x006f
            if (r11 == r10) goto L_0x006f
            boolean r12 = r11.isPressed()
            if (r12 == 0) goto L_0x006f
            r11.setPressed(r5)
        L_0x006f:
            r1.f = r8
            int r11 = r10.getLeft()
            float r11 = (float) r11
            float r11 = r7 - r11
            int r12 = r10.getTop()
            float r12 = (float) r12
            float r12 = r6 - r12
            i.C0076p0.a(r10, r11, r12)
            boolean r11 = r10.isPressed()
            if (r11 != 0) goto L_0x008b
            r10.setPressed(r4)
        L_0x008b:
            android.graphics.drawable.Drawable r11 = r1.getSelector()
            if (r11 == 0) goto L_0x0095
            if (r8 == r9) goto L_0x0095
            r12 = r4
            goto L_0x0096
        L_0x0095:
            r12 = r5
        L_0x0096:
            if (r12 == 0) goto L_0x009b
            r11.setVisible(r5, r5)
        L_0x009b:
            int r13 = r10.getLeft()
            int r14 = r10.getTop()
            int r15 = r10.getRight()
            r16 = r4
            int r4 = r10.getBottom()
            android.graphics.Rect r5 = r1.f1405a
            r5.set(r13, r14, r15, r4)
            int r4 = r5.left
            int r13 = r1.b
            int r4 = r4 - r13
            r5.left = r4
            int r4 = r5.top
            int r13 = r1.f1406c
            int r4 = r4 - r13
            r5.top = r4
            int r4 = r5.right
            int r13 = r1.f1407d
            int r4 = r4 + r13
            r5.right = r4
            int r4 = r5.bottom
            int r13 = r1.f1408e
            int r4 = r4 + r13
            r5.bottom = r4
            r4 = 33
            if (r0 < r4) goto L_0x00d7
            boolean r0 = i.C0079r0.a(r1)
            goto L_0x00e5
        L_0x00d7:
            java.lang.reflect.Field r0 = i.C0083t0.f1400a
            if (r0 == 0) goto L_0x00e4
            boolean r0 = r0.getBoolean(r1)     // Catch:{ IllegalAccessException -> 0x00e0 }
            goto L_0x00e5
        L_0x00e0:
            r0 = move-exception
            r0.printStackTrace()
        L_0x00e4:
            r0 = 0
        L_0x00e5:
            boolean r13 = r10.isEnabled()
            if (r13 == r0) goto L_0x010a
            r0 = r0 ^ 1
            int r13 = android.os.Build.VERSION.SDK_INT
            if (r13 < r4) goto L_0x00f5
            i.C0079r0.b(r1, r0)
            goto L_0x0105
        L_0x00f5:
            java.lang.reflect.Field r4 = i.C0083t0.f1400a
            if (r4 == 0) goto L_0x0105
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)     // Catch:{ IllegalAccessException -> 0x0101 }
            r4.set(r1, r0)     // Catch:{ IllegalAccessException -> 0x0101 }
            goto L_0x0105
        L_0x0101:
            r0 = move-exception
            r0.printStackTrace()
        L_0x0105:
            if (r8 == r9) goto L_0x010a
            r1.refreshDrawableState()
        L_0x010a:
            if (r12 == 0) goto L_0x0126
            float r0 = r5.exactCenterX()
            float r4 = r5.exactCenterY()
            int r5 = r1.getVisibility()
            if (r5 != 0) goto L_0x011e
            r5 = r16
        L_0x011c:
            r12 = 0
            goto L_0x0120
        L_0x011e:
            r5 = 0
            goto L_0x011c
        L_0x0120:
            r11.setVisible(r5, r12)
            s.C0126a.e(r11, r0, r4)
        L_0x0126:
            android.graphics.drawable.Drawable r0 = r1.getSelector()
            if (r0 == 0) goto L_0x0131
            if (r8 == r9) goto L_0x0131
            s.C0126a.e(r0, r7, r6)
        L_0x0131:
            i.s0 r0 = r1.f1409g
            if (r0 == 0) goto L_0x0138
            r12 = 0
            r0.b = r12
        L_0x0138:
            r1.refreshDrawableState()
            r4 = r16
            if (r3 != r4) goto L_0x0146
            long r3 = r1.getItemIdAtPosition(r8)
            r1.performItemClick(r10, r8, r3)
        L_0x0146:
            r0 = 1
            r5 = 0
        L_0x0148:
            if (r0 == 0) goto L_0x014c
            if (r5 == 0) goto L_0x0165
        L_0x014c:
            r12 = 0
            r1.f1412j = r12
            r1.setPressed(r12)
            r1.drawableStateChanged()
            int r3 = r1.f
            int r4 = r1.getFirstVisiblePosition()
            int r3 = r3 - r4
            android.view.View r3 = r1.getChildAt(r3)
            if (r3 == 0) goto L_0x0165
            r3.setPressed(r12)
        L_0x0165:
            if (r0 == 0) goto L_0x017d
            D.i r3 = r1.f1413k
            if (r3 != 0) goto L_0x0172
            D.i r3 = new D.i
            r3.<init>(r1)
            r1.f1413k = r3
        L_0x0172:
            D.i r3 = r1.f1413k
            boolean r4 = r3.f43p
            r4 = 1
            r3.f43p = r4
            r3.onTouch(r1, r2)
            goto L_0x018b
        L_0x017d:
            D.i r2 = r1.f1413k
            if (r2 == 0) goto L_0x018b
            boolean r3 = r2.f43p
            if (r3 == 0) goto L_0x0188
            r2.d()
        L_0x0188:
            r12 = 0
            r2.f43p = r12
        L_0x018b:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: i.C0085u0.b(android.view.MotionEvent, int):boolean");
    }

    public final void dispatchDraw(Canvas canvas) {
        Drawable selector;
        Rect rect = this.f1405a;
        if (!rect.isEmpty() && (selector = getSelector()) != null) {
            selector.setBounds(rect);
            selector.draw(canvas);
        }
        super.dispatchDraw(canvas);
    }

    public final void drawableStateChanged() {
        if (this.f1414l == null) {
            super.drawableStateChanged();
            C0081s0 s0Var = this.f1409g;
            if (s0Var != null) {
                s0Var.b = true;
            }
            Drawable selector = getSelector();
            if (selector != null && this.f1412j && isPressed()) {
                selector.setState(getDrawableState());
            }
        }
    }

    public final boolean hasFocus() {
        if (this.f1411i || super.hasFocus()) {
            return true;
        }
        return false;
    }

    public final boolean hasWindowFocus() {
        if (this.f1411i || super.hasWindowFocus()) {
            return true;
        }
        return false;
    }

    public final boolean isFocused() {
        if (this.f1411i || super.isFocused()) {
            return true;
        }
        return false;
    }

    public final boolean isInTouchMode() {
        if ((!this.f1411i || !this.f1410h) && !super.isInTouchMode()) {
            return false;
        }
        return true;
    }

    public final void onDetachedFromWindow() {
        this.f1414l = null;
        super.onDetachedFromWindow();
    }

    public boolean onHoverEvent(MotionEvent motionEvent) {
        int i2 = Build.VERSION.SDK_INT;
        if (i2 < 26) {
            return super.onHoverEvent(motionEvent);
        }
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 10 && this.f1414l == null) {
            b bVar = new b(3, (Object) this);
            this.f1414l = bVar;
            post(bVar);
        }
        boolean onHoverEvent = super.onHoverEvent(motionEvent);
        if (actionMasked == 9 || actionMasked == 7) {
            int pointToPosition = pointToPosition((int) motionEvent.getX(), (int) motionEvent.getY());
            if (!(pointToPosition == -1 || pointToPosition == getSelectedItemPosition())) {
                View childAt = getChildAt(pointToPosition - getFirstVisiblePosition());
                if (childAt.isEnabled()) {
                    requestFocus();
                    if (i2 < 30 || !C0078q0.f1390d) {
                        setSelectionFromTop(pointToPosition, childAt.getTop() - getTop());
                    } else {
                        try {
                            C0078q0.f1388a.invoke(this, new Object[]{Integer.valueOf(pointToPosition), childAt, Boolean.FALSE, -1, -1});
                            C0078q0.b.invoke(this, new Object[]{Integer.valueOf(pointToPosition)});
                            C0078q0.f1389c.invoke(this, new Object[]{Integer.valueOf(pointToPosition)});
                        } catch (IllegalAccessException e2) {
                            e2.printStackTrace();
                        } catch (InvocationTargetException e3) {
                            e3.printStackTrace();
                        }
                    }
                }
                Drawable selector = getSelector();
                if (selector != null && this.f1412j && isPressed()) {
                    selector.setState(getDrawableState());
                }
            }
            return onHoverEvent;
        }
        setSelection(-1);
        return onHoverEvent;
    }

    public final boolean onTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            this.f = pointToPosition((int) motionEvent.getX(), (int) motionEvent.getY());
        }
        b bVar = this.f1414l;
        if (bVar != null) {
            C0085u0 u0Var = (C0085u0) bVar.b;
            u0Var.f1414l = null;
            u0Var.removeCallbacks(bVar);
        }
        return super.onTouchEvent(motionEvent);
    }

    public void setListSelectionHidden(boolean z2) {
        this.f1410h = z2;
    }

    /* JADX WARNING: type inference failed for: r1v0, types: [i.s0, android.graphics.drawable.Drawable$Callback, android.graphics.drawable.Drawable] */
    public void setSelector(Drawable drawable) {
        C0081s0 s0Var = null;
        if (drawable != null) {
            ? drawable2 = new Drawable();
            Drawable drawable3 = drawable2.f1396a;
            if (drawable3 != null) {
                drawable3.setCallback((Drawable.Callback) null);
            }
            drawable2.f1396a = drawable;
            drawable.setCallback(drawable2);
            drawable2.b = true;
            s0Var = drawable2;
        }
        this.f1409g = s0Var;
        super.setSelector(s0Var);
        Rect rect = new Rect();
        if (drawable != null) {
            drawable.getPadding(rect);
        }
        this.b = rect.left;
        this.f1406c = rect.top;
        this.f1407d = rect.right;
        this.f1408e = rect.bottom;
    }
}
