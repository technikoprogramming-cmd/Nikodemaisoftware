package i;

import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewParent;

/* renamed from: i.w0  reason: case insensitive filesystem */
public final class C0089w0 implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f1418a;
    public final /* synthetic */ C0091x0 b;

    public /* synthetic */ C0089w0(C0091x0 x0Var, int i2) {
        this.f1418a = i2;
        this.b = x0Var;
    }

    public final void run() {
        switch (this.f1418a) {
            case 0:
                ViewParent parent = this.b.f1425d.getParent();
                if (parent != null) {
                    parent.requestDisallowInterceptTouchEvent(true);
                    return;
                }
                return;
            default:
                C0091x0 x0Var = this.b;
                x0Var.a();
                View view = x0Var.f1425d;
                if (view.isEnabled() && !view.isLongClickable() && x0Var.c()) {
                    view.getParent().requestDisallowInterceptTouchEvent(true);
                    long uptimeMillis = SystemClock.uptimeMillis();
                    MotionEvent obtain = MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, 0.0f, 0.0f, 0);
                    view.onTouchEvent(obtain);
                    obtain.recycle();
                    x0Var.f1427g = true;
                    return;
                }
                return;
        }
    }
}
