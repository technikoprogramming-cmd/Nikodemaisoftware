package i;

import android.widget.AbsListView;

/* renamed from: i.r0  reason: case insensitive filesystem */
public abstract class C0079r0 {
    public static boolean a(AbsListView absListView) {
        return absListView.isSelectedChildViewEnabled();
    }

    public static void b(AbsListView absListView, boolean z2) {
        absListView.setSelectedChildViewEnabled(z2);
    }
}
