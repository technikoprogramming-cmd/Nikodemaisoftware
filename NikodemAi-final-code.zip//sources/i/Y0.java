package i;

import android.view.MenuItem;
import androidx.appcompat.widget.Toolbar;
import h.l;
import h.n;

public final class Y0 implements C0073o, l {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ Toolbar f1275a;

    public /* synthetic */ Y0(Toolbar toolbar) {
        this.f1275a = toolbar;
    }

    public void g(n nVar) {
        Toolbar toolbar = this.f1275a;
        C0067l lVar = toolbar.f474a.f438t;
        if (lVar == null || !lVar.h()) {
            toolbar.f463G.p();
        }
    }

    public boolean h(n nVar, MenuItem menuItem) {
        this.f1275a.getClass();
        return false;
    }
}
