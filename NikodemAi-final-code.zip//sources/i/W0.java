package i;

public abstract class W0 extends P0 {
}
