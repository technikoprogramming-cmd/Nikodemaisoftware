package i;

import androidx.appcompat.widget.ActionBarContextView;
import y.S;

/* renamed from: i.a  reason: case insensitive filesystem */
public final class C0045a implements S {

    /* renamed from: a  reason: collision with root package name */
    public boolean f1276a = false;
    public int b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ ActionBarContextView f1277c;

    public C0045a(ActionBarContextView actionBarContextView) {
        this.f1277c = actionBarContextView;
    }

    public final void a() {
        if (!this.f1276a) {
            ActionBarContextView actionBarContextView = this.f1277c;
            actionBarContextView.f = null;
            C0045a.super.setVisibility(this.b);
        }
    }

    public final void b() {
        this.f1276a = true;
    }

    public final void c() {
        C0045a.super.setVisibility(0);
        this.f1276a = false;
    }
}
