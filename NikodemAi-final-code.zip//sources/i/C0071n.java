package i;

/* renamed from: i.n  reason: case insensitive filesystem */
public final class C0071n extends C0093y0 {

    /* renamed from: a  reason: collision with root package name */
    public boolean f1374a;
    public int b;

    /* renamed from: c  reason: collision with root package name */
    public int f1375c;

    /* renamed from: d  reason: collision with root package name */
    public boolean f1376d;

    /* renamed from: e  reason: collision with root package name */
    public boolean f1377e;
    public boolean f;
}
