package i;

import C.j;
import android.content.Context;
import android.os.Build;
import android.util.Log;
import android.widget.PopupWindow;
import h.n;
import h.p;
import java.lang.reflect.Method;

public final class M0 extends H0 implements I0 {

    /* renamed from: C  reason: collision with root package name */
    public static final Method f1231C;

    /* renamed from: B  reason: collision with root package name */
    public j f1232B;

    static {
        try {
            if (Build.VERSION.SDK_INT <= 28) {
                f1231C = PopupWindow.class.getDeclaredMethod("setTouchModal", new Class[]{Boolean.TYPE});
            }
        } catch (NoSuchMethodException unused) {
            Log.i("MenuPopupWindow", "Could not find method setTouchModal() on PopupWindow. Oh well.");
        }
    }

    public final C0085u0 o(Context context, boolean z2) {
        L0 l0 = new L0(context, z2);
        l0.setHoverListener(this);
        return l0;
    }

    public final void r(n nVar, p pVar) {
        j jVar = this.f1232B;
        if (jVar != null) {
            jVar.r(nVar, pVar);
        }
    }

    public final void t(n nVar, p pVar) {
        j jVar = this.f1232B;
        if (jVar != null) {
            jVar.t(nVar, pVar);
        }
    }
}
