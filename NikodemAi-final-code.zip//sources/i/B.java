package i;

import D.g;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.util.AttributeSet;
import android.widget.ImageView;

public class B extends ImageView {

    /* renamed from: a  reason: collision with root package name */
    public final C0077q f1174a;
    public final C0044A b;

    /* renamed from: c  reason: collision with root package name */
    public boolean f1175c = false;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public B(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        U0.a(context);
        T0.a(this, getContext());
        C0077q qVar = new C0077q(this);
        this.f1174a = qVar;
        qVar.d(attributeSet, i2);
        C0044A a2 = new C0044A(this);
        this.b = a2;
        a2.b(attributeSet, i2);
    }

    public final void drawableStateChanged() {
        super.drawableStateChanged();
        C0077q qVar = this.f1174a;
        if (qVar != null) {
            qVar.a();
        }
        C0044A a2 = this.b;
        if (a2 != null) {
            a2.a();
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        C0077q qVar = this.f1174a;
        if (qVar != null) {
            return qVar.b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0077q qVar = this.f1174a;
        if (qVar != null) {
            return qVar.c();
        }
        return null;
    }

    public ColorStateList getSupportImageTintList() {
        V0 v0;
        C0044A a2 = this.b;
        if (a2 == null || (v0 = a2.b) == null) {
            return null;
        }
        return v0.f1269a;
    }

    public PorterDuff.Mode getSupportImageTintMode() {
        V0 v0;
        C0044A a2 = this.b;
        if (a2 == null || (v0 = a2.b) == null) {
            return null;
        }
        return v0.b;
    }

    public final boolean hasOverlappingRendering() {
        if ((this.b.f1171a.getBackground() instanceof RippleDrawable) || !super.hasOverlappingRendering()) {
            return false;
        }
        return true;
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0077q qVar = this.f1174a;
        if (qVar != null) {
            qVar.e();
        }
    }

    public void setBackgroundResource(int i2) {
        super.setBackgroundResource(i2);
        C0077q qVar = this.f1174a;
        if (qVar != null) {
            qVar.f(i2);
        }
    }

    public void setImageBitmap(Bitmap bitmap) {
        super.setImageBitmap(bitmap);
        C0044A a2 = this.b;
        if (a2 != null) {
            a2.a();
        }
    }

    public void setImageDrawable(Drawable drawable) {
        C0044A a2 = this.b;
        if (!(a2 == null || drawable == null || this.f1175c)) {
            a2.f1172c = drawable.getLevel();
        }
        super.setImageDrawable(drawable);
        if (a2 != null) {
            a2.a();
            if (!this.f1175c) {
                ImageView imageView = a2.f1171a;
                if (imageView.getDrawable() != null) {
                    imageView.getDrawable().setLevel(a2.f1172c);
                }
            }
        }
    }

    public void setImageLevel(int i2) {
        super.setImageLevel(i2);
        this.f1175c = true;
    }

    public void setImageResource(int i2) {
        C0044A a2 = this.b;
        if (a2 != null) {
            ImageView imageView = a2.f1171a;
            if (i2 != 0) {
                Drawable s2 = g.s(imageView.getContext(), i2);
                if (s2 != null) {
                    C0074o0.a(s2);
                }
                imageView.setImageDrawable(s2);
            } else {
                imageView.setImageDrawable((Drawable) null);
            }
            a2.a();
        }
    }

    public void setImageURI(Uri uri) {
        super.setImageURI(uri);
        C0044A a2 = this.b;
        if (a2 != null) {
            a2.a();
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C0077q qVar = this.f1174a;
        if (qVar != null) {
            qVar.h(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C0077q qVar = this.f1174a;
        if (qVar != null) {
            qVar.i(mode);
        }
    }

    /* JADX WARNING: type inference failed for: r1v2, types: [java.lang.Object, i.V0] */
    public void setSupportImageTintList(ColorStateList colorStateList) {
        C0044A a2 = this.b;
        if (a2 != null) {
            if (a2.b == null) {
                a2.b = new Object();
            }
            V0 v0 = a2.b;
            v0.f1269a = colorStateList;
            v0.f1271d = true;
            a2.a();
        }
    }

    /* JADX WARNING: type inference failed for: r1v2, types: [java.lang.Object, i.V0] */
    public void setSupportImageTintMode(PorterDuff.Mode mode) {
        C0044A a2 = this.b;
        if (a2 != null) {
            if (a2.b == null) {
                a2.b = new Object();
            }
            V0 v0 = a2.b;
            v0.b = mode;
            v0.f1270c = true;
            a2.a();
        }
    }
}
