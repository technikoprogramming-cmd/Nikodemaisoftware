package i;

import android.app.DownloadManager;
import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.webkit.CookieManager;
import android.widget.EditText;
import android.widget.ListAdapter;
import androidx.appcompat.app.AlertController$RecycleListView;
import e.C0015b;
import e.C0019f;
import e.C0020g;
import i0.b;
import java.io.IOException;
import ncs.oprogramowanie.nikodemai.aos.MainActivity;

public final class L implements S, DialogInterface.OnClickListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f1222a;
    public Object b;

    /* renamed from: c  reason: collision with root package name */
    public Object f1223c;

    /* renamed from: d  reason: collision with root package name */
    public Object f1224d;

    /* renamed from: e  reason: collision with root package name */
    public final /* synthetic */ Object f1225e;

    public /* synthetic */ L(Object obj, String str, String str2, Object obj2, int i2) {
        this.f1222a = i2;
        this.f1225e = obj;
        this.b = str;
        this.f1223c = str2;
        this.f1224d = obj2;
    }

    public boolean a() {
        C0020g gVar = (C0020g) this.b;
        if (gVar != null) {
            return gVar.isShowing();
        }
        return false;
    }

    public CharSequence b() {
        return (CharSequence) this.f1224d;
    }

    public void c(int i2) {
        Log.e("AppCompatSpinner", "Cannot set horizontal offset for MODE_DIALOG, ignoring");
    }

    public int d() {
        return 0;
    }

    public void dismiss() {
        C0020g gVar = (C0020g) this.b;
        if (gVar != null) {
            gVar.dismiss();
            this.b = null;
        }
    }

    public void e(int i2, int i3) {
        if (((M) this.f1223c) != null) {
            T t2 = (T) this.f1225e;
            C0019f fVar = new C0019f(t2.getPopupContext());
            CharSequence charSequence = (CharSequence) this.f1224d;
            C0015b bVar = (C0015b) fVar.b;
            if (charSequence != null) {
                bVar.f910d = charSequence;
            }
            int selectedItemPosition = t2.getSelectedItemPosition();
            bVar.f912g = (M) this.f1223c;
            bVar.f913h = this;
            bVar.f915j = selectedItemPosition;
            bVar.f914i = true;
            C0020g a2 = fVar.a();
            this.b = a2;
            AlertController$RecycleListView alertController$RecycleListView = a2.f.f920e;
            alertController$RecycleListView.setTextDirection(i2);
            alertController$RecycleListView.setTextAlignment(i3);
            ((C0020g) this.b).show();
        }
    }

    public void g(CharSequence charSequence) {
        this.f1224d = charSequence;
    }

    public int i() {
        return 0;
    }

    public void j(Drawable drawable) {
        Log.e("AppCompatSpinner", "Cannot set popup background for MODE_DIALOG, ignoring");
    }

    public void k(int i2) {
        Log.e("AppCompatSpinner", "Cannot set vertical offset for MODE_DIALOG, ignoring");
    }

    public Drawable l() {
        return null;
    }

    public void m(ListAdapter listAdapter) {
        this.f1223c = (M) listAdapter;
    }

    public void n(int i2) {
        Log.e("AppCompatSpinner", "Cannot set horizontal (original) offset for MODE_DIALOG, ignoring");
    }

    public final void onClick(DialogInterface dialogInterface, int i2) {
        switch (this.f1222a) {
            case 0:
                T t2 = (T) this.f1225e;
                t2.setSelection(i2);
                if (t2.getOnItemClickListener() != null) {
                    t2.performItemClick((View) null, i2, ((M) this.f1223c).getItemId(i2));
                }
                dismiss();
                return;
            case 1:
                try {
                    b.a((b) this.f1225e, (String) this.b, (String) this.f1223c, ((EditText) this.f1224d).getText().toString());
                    return;
                } catch (IOException e2) {
                    e2.printStackTrace();
                    return;
                }
            default:
                String str = (String) this.b;
                DownloadManager.Request request = new DownloadManager.Request(Uri.parse(str));
                request.addRequestHeader("Cookie", CookieManager.getInstance().getCookie(str));
                request.addRequestHeader("User-Agent", (String) this.f1223c);
                request.allowScanningByMediaScanner();
                request.setNotificationVisibility(1);
                request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, (String) this.f1224d);
                ((DownloadManager) ((MainActivity) this.f1225e).getSystemService("download")).enqueue(request);
                return;
        }
    }

    public L(T t2) {
        this.f1222a = 0;
        this.f1225e = t2;
    }
}
