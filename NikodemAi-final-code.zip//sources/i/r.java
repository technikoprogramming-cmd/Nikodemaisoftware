package i;

import D.g;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import ncs.oprogramowanie.nikodemai.aos.R;

public final class r extends Button {

    /* renamed from: a  reason: collision with root package name */
    public final C0077q f1391a;
    public final C0046a0 b;

    /* renamed from: c  reason: collision with root package name */
    public C0092y f1392c;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public r(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, R.attr.buttonStyle);
        U0.a(context);
        T0.a(this, getContext());
        C0077q qVar = new C0077q(this);
        this.f1391a = qVar;
        qVar.d(attributeSet, R.attr.buttonStyle);
        C0046a0 a0Var = new C0046a0(this);
        this.b = a0Var;
        a0Var.f(attributeSet, R.attr.buttonStyle);
        a0Var.b();
        getEmojiTextViewHelper().a(attributeSet, R.attr.buttonStyle);
    }

    private C0092y getEmojiTextViewHelper() {
        if (this.f1392c == null) {
            this.f1392c = new C0092y(this);
        }
        return this.f1392c;
    }

    public final void drawableStateChanged() {
        super.drawableStateChanged();
        C0077q qVar = this.f1391a;
        if (qVar != null) {
            qVar.a();
        }
        C0046a0 a0Var = this.b;
        if (a0Var != null) {
            a0Var.b();
        }
    }

    public int getAutoSizeMaxTextSize() {
        if (n1.f1379c) {
            return super.getAutoSizeMaxTextSize();
        }
        C0046a0 a0Var = this.b;
        if (a0Var != null) {
            return Math.round(a0Var.f1284i.f1338e);
        }
        return -1;
    }

    public int getAutoSizeMinTextSize() {
        if (n1.f1379c) {
            return super.getAutoSizeMinTextSize();
        }
        C0046a0 a0Var = this.b;
        if (a0Var != null) {
            return Math.round(a0Var.f1284i.f1337d);
        }
        return -1;
    }

    public int getAutoSizeStepGranularity() {
        if (n1.f1379c) {
            return super.getAutoSizeStepGranularity();
        }
        C0046a0 a0Var = this.b;
        if (a0Var != null) {
            return Math.round(a0Var.f1284i.f1336c);
        }
        return -1;
    }

    public int[] getAutoSizeTextAvailableSizes() {
        if (n1.f1379c) {
            return super.getAutoSizeTextAvailableSizes();
        }
        C0046a0 a0Var = this.b;
        if (a0Var != null) {
            return a0Var.f1284i.f;
        }
        return new int[0];
    }

    public int getAutoSizeTextType() {
        if (!n1.f1379c) {
            C0046a0 a0Var = this.b;
            if (a0Var != null) {
                return a0Var.f1284i.f1335a;
            }
            return 0;
        } else if (super.getAutoSizeTextType() == 1) {
            return 1;
        } else {
            return 0;
        }
    }

    public ActionMode.Callback getCustomSelectionActionModeCallback() {
        return g.T(super.getCustomSelectionActionModeCallback());
    }

    public ColorStateList getSupportBackgroundTintList() {
        C0077q qVar = this.f1391a;
        if (qVar != null) {
            return qVar.b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0077q qVar = this.f1391a;
        if (qVar != null) {
            return qVar.c();
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.b.d();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.b.e();
    }

    public final void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName(Button.class.getName());
    }

    public final void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName(Button.class.getName());
    }

    public final void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        super.onLayout(z2, i2, i3, i4, i5);
        C0046a0 a0Var = this.b;
        if (a0Var != null && !n1.f1379c) {
            a0Var.f1284i.a();
        }
    }

    public final void onTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
        super.onTextChanged(charSequence, i2, i3, i4);
        C0046a0 a0Var = this.b;
        if (a0Var != null && !n1.f1379c) {
            C0064j0 j0Var = a0Var.f1284i;
            if (j0Var.f()) {
                j0Var.a();
            }
        }
    }

    public void setAllCaps(boolean z2) {
        super.setAllCaps(z2);
        getEmojiTextViewHelper().b(z2);
    }

    public final void setAutoSizeTextTypeUniformWithConfiguration(int i2, int i3, int i4, int i5) {
        if (n1.f1379c) {
            super.setAutoSizeTextTypeUniformWithConfiguration(i2, i3, i4, i5);
            return;
        }
        C0046a0 a0Var = this.b;
        if (a0Var != null) {
            a0Var.i(i2, i3, i4, i5);
        }
    }

    public final void setAutoSizeTextTypeUniformWithPresetSizes(int[] iArr, int i2) {
        if (n1.f1379c) {
            super.setAutoSizeTextTypeUniformWithPresetSizes(iArr, i2);
            return;
        }
        C0046a0 a0Var = this.b;
        if (a0Var != null) {
            a0Var.j(iArr, i2);
        }
    }

    public void setAutoSizeTextTypeWithDefaults(int i2) {
        if (n1.f1379c) {
            super.setAutoSizeTextTypeWithDefaults(i2);
            return;
        }
        C0046a0 a0Var = this.b;
        if (a0Var != null) {
            a0Var.k(i2);
        }
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0077q qVar = this.f1391a;
        if (qVar != null) {
            qVar.e();
        }
    }

    public void setBackgroundResource(int i2) {
        super.setBackgroundResource(i2);
        C0077q qVar = this.f1391a;
        if (qVar != null) {
            qVar.f(i2);
        }
    }

    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(g.U(callback, this));
    }

    public void setEmojiCompatEnabled(boolean z2) {
        getEmojiTextViewHelper().c(z2);
    }

    public void setFilters(InputFilter[] inputFilterArr) {
        super.setFilters(((g) getEmojiTextViewHelper().b.b).u(inputFilterArr));
    }

    public void setSupportAllCaps(boolean z2) {
        C0046a0 a0Var = this.b;
        if (a0Var != null) {
            a0Var.f1278a.setAllCaps(z2);
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C0077q qVar = this.f1391a;
        if (qVar != null) {
            qVar.h(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C0077q qVar = this.f1391a;
        if (qVar != null) {
            qVar.i(mode);
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        C0046a0 a0Var = this.b;
        a0Var.l(colorStateList);
        a0Var.b();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        C0046a0 a0Var = this.b;
        a0Var.m(mode);
        a0Var.b();
    }

    public final void setTextAppearance(Context context, int i2) {
        super.setTextAppearance(context, i2);
        C0046a0 a0Var = this.b;
        if (a0Var != null) {
            a0Var.g(context, i2);
        }
    }

    public final void setTextSize(int i2, float f) {
        boolean z2 = n1.f1379c;
        if (z2) {
            super.setTextSize(i2, f);
            return;
        }
        C0046a0 a0Var = this.b;
        if (a0Var != null && !z2) {
            C0064j0 j0Var = a0Var.f1284i;
            if (!j0Var.f()) {
                j0Var.g(i2, f);
            }
        }
    }
}
