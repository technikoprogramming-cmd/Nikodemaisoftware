package i;

import C.j;
import android.content.Context;
import android.view.View;
import h.n;
import h.v;
import h.x;
import ncs.oprogramowanie.nikodemai.aos.R;

/* renamed from: i.h  reason: case insensitive filesystem */
public final class C0059h extends x {

    /* renamed from: l  reason: collision with root package name */
    public final /* synthetic */ int f1318l = 0;

    /* renamed from: m  reason: collision with root package name */
    public final /* synthetic */ C0067l f1319m;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public C0059h(C0067l lVar, Context context, n nVar, View view) {
        super(R.attr.actionOverflowMenuStyle, context, view, nVar, true);
        this.f1319m = lVar;
        this.f = 8388613;
        j jVar = lVar.f1373w;
        this.f1167h = jVar;
        v vVar = this.f1168i;
        if (vVar != null) {
            vVar.e(jVar);
        }
    }

    public final void c() {
        switch (this.f1318l) {
            case 0:
                C0067l lVar = this.f1319m;
                lVar.f1370t = null;
                lVar.getClass();
                super.c();
                return;
            default:
                C0067l lVar2 = this.f1319m;
                n nVar = lVar2.f1354c;
                if (nVar != null) {
                    nVar.c(true);
                }
                lVar2.f1369s = null;
                super.c();
                return;
        }
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public C0059h(i.C0067l r8, android.content.Context r9, h.F r10, android.view.View r11) {
        /*
            r7 = this;
            r0 = 0
            r7.f1318l = r0
            r7.f1319m = r8
            r6 = 0
            r2 = 2130903072(0x7f030020, float:1.7412952E38)
            r1 = r7
            r3 = r9
            r5 = r10
            r4 = r11
            r1.<init>(r2, r3, r4, r5, r6)
            h.p r9 = r5.f1044A
            int r9 = r9.f1150x
            r10 = 32
            r9 = r9 & r10
            if (r9 != r10) goto L_0x001a
            goto L_0x0024
        L_0x001a:
            i.k r9 = r8.f1359i
            if (r9 != 0) goto L_0x0022
            h.B r9 = r8.f1358h
            android.view.View r9 = (android.view.View) r9
        L_0x0022:
            r1.f1165e = r9
        L_0x0024:
            C.j r8 = r8.f1373w
            r1.f1167h = r8
            h.v r9 = r1.f1168i
            if (r9 == 0) goto L_0x002f
            r9.e(r8)
        L_0x002f:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: i.C0059h.<init>(i.l, android.content.Context, h.F, android.view.View):void");
    }
}
