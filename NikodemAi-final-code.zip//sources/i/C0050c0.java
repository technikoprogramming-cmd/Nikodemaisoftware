package i;

import C.j;

/* renamed from: i.c0  reason: case insensitive filesystem */
public class C0050c0 extends j {

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ C0054e0 f1294c;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public C0050c0(C0054e0 e0Var) {
        super(18, (Object) e0Var);
        this.f1294c = e0Var;
    }

    public final void d(int i2) {
        C0050c0.super.setFirstBaselineToTopHeight(i2);
    }

    public final void v(int i2) {
        C0050c0.super.setLastBaselineToBottomHeight(i2);
    }
}
