package i;

import h.C0040c;

/* renamed from: i.i  reason: case insensitive filesystem */
public final class C0061i extends C0040c {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ C0067l f1321a;

    public C0061i(C0067l lVar) {
        this.f1321a = lVar;
    }
}
