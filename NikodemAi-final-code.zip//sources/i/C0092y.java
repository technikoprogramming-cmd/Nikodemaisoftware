package i;

import C.j;
import D.g;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.widget.TextView;
import d.C0010a;

/* renamed from: i.y  reason: case insensitive filesystem */
public final class C0092y {

    /* renamed from: a  reason: collision with root package name */
    public final TextView f1430a;
    public final j b;

    public C0092y(TextView textView) {
        this.f1430a = textView;
        this.b = new j(textView);
    }

    /* JADX INFO: finally extract failed */
    public final void a(AttributeSet attributeSet, int i2) {
        TypedArray obtainStyledAttributes = this.f1430a.getContext().obtainStyledAttributes(attributeSet, C0010a.f777i, i2, 0);
        try {
            boolean z2 = true;
            if (obtainStyledAttributes.hasValue(14)) {
                z2 = obtainStyledAttributes.getBoolean(14, true);
            }
            obtainStyledAttributes.recycle();
            c(z2);
        } catch (Throwable th) {
            obtainStyledAttributes.recycle();
            throw th;
        }
    }

    public final void b(boolean z2) {
        ((g) this.b.b).N(z2);
    }

    public final void c(boolean z2) {
        ((g) this.b.b).O(z2);
    }
}
