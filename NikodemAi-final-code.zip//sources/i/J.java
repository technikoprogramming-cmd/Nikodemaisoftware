package i;

import h.D;

public final class J extends C0091x0 {

    /* renamed from: j  reason: collision with root package name */
    public final /* synthetic */ P f1220j;

    /* renamed from: k  reason: collision with root package name */
    public final /* synthetic */ T f1221k;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public J(T t2, T t3, P p2) {
        super(t3);
        this.f1221k = t2;
        this.f1220j = p2;
    }

    public final D b() {
        return this.f1220j;
    }

    public final boolean c() {
        T t2 = this.f1221k;
        if (t2.getInternalPopup().a()) {
            return true;
        }
        t2.f.e(t2.getTextDirection(), t2.getTextAlignment());
        return true;
    }
}
