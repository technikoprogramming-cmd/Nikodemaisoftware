package i;

import C.h;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import d.C0010a;
import java.util.WeakHashMap;
import y.C0148A;
import y.K;

/* renamed from: i.q  reason: case insensitive filesystem */
public final class C0077q {

    /* renamed from: a  reason: collision with root package name */
    public final View f1384a;
    public final C0086v b;

    /* renamed from: c  reason: collision with root package name */
    public int f1385c = -1;

    /* renamed from: d  reason: collision with root package name */
    public V0 f1386d;

    /* renamed from: e  reason: collision with root package name */
    public V0 f1387e;
    public V0 f;

    public C0077q(View view) {
        this.f1384a = view;
        this.b = C0086v.a();
    }

    /* JADX WARNING: type inference failed for: r2v5, types: [java.lang.Object, i.V0] */
    public final void a() {
        View view = this.f1384a;
        Drawable background = view.getBackground();
        if (background != null) {
            if (this.f1386d != null) {
                if (this.f == null) {
                    this.f = new Object();
                }
                V0 v0 = this.f;
                v0.f1269a = null;
                v0.f1271d = false;
                v0.b = null;
                v0.f1270c = false;
                WeakHashMap weakHashMap = K.f1633a;
                ColorStateList g2 = C0148A.g(view);
                if (g2 != null) {
                    v0.f1271d = true;
                    v0.f1269a = g2;
                }
                PorterDuff.Mode h2 = C0148A.h(view);
                if (h2 != null) {
                    v0.f1270c = true;
                    v0.b = h2;
                }
                if (v0.f1271d || v0.f1270c) {
                    C0086v.d(background, v0, view.getDrawableState());
                    return;
                }
            }
            V0 v02 = this.f1387e;
            if (v02 != null) {
                C0086v.d(background, v02, view.getDrawableState());
                return;
            }
            V0 v03 = this.f1386d;
            if (v03 != null) {
                C0086v.d(background, v03, view.getDrawableState());
            }
        }
    }

    public final ColorStateList b() {
        V0 v0 = this.f1387e;
        if (v0 != null) {
            return v0.f1269a;
        }
        return null;
    }

    public final PorterDuff.Mode c() {
        V0 v0 = this.f1387e;
        if (v0 != null) {
            return v0.b;
        }
        return null;
    }

    public final void d(AttributeSet attributeSet, int i2) {
        ColorStateList f2;
        View view = this.f1384a;
        Context context = view.getContext();
        int[] iArr = C0010a.f793y;
        h m2 = h.m(context, attributeSet, iArr, i2);
        TypedArray typedArray = (TypedArray) m2.b;
        View view2 = this.f1384a;
        K.g(view2, view2.getContext(), iArr, attributeSet, (TypedArray) m2.b, i2);
        try {
            if (typedArray.hasValue(0)) {
                this.f1385c = typedArray.getResourceId(0, -1);
                C0086v vVar = this.b;
                Context context2 = view.getContext();
                int i3 = this.f1385c;
                synchronized (vVar) {
                    f2 = vVar.f1416a.f(context2, i3);
                }
                if (f2 != null) {
                    g(f2);
                }
            }
            if (typedArray.hasValue(1)) {
                C0148A.q(view, m2.h(1));
            }
            if (typedArray.hasValue(2)) {
                C0148A.r(view, C0074o0.b(typedArray.getInt(2, -1), (PorterDuff.Mode) null));
            }
            m2.r();
        } catch (Throwable th) {
            Throwable th2 = th;
            m2.r();
            throw th2;
        }
    }

    public final void e() {
        this.f1385c = -1;
        g((ColorStateList) null);
        a();
    }

    public final void f(int i2) {
        ColorStateList colorStateList;
        this.f1385c = i2;
        C0086v vVar = this.b;
        if (vVar != null) {
            Context context = this.f1384a.getContext();
            synchronized (vVar) {
                colorStateList = vVar.f1416a.f(context, i2);
            }
        } else {
            colorStateList = null;
        }
        g(colorStateList);
        a();
    }

    /* JADX WARNING: type inference failed for: r0v2, types: [java.lang.Object, i.V0] */
    public final void g(ColorStateList colorStateList) {
        if (colorStateList != null) {
            if (this.f1386d == null) {
                this.f1386d = new Object();
            }
            V0 v0 = this.f1386d;
            v0.f1269a = colorStateList;
            v0.f1271d = true;
        } else {
            this.f1386d = null;
        }
        a();
    }

    /* JADX WARNING: type inference failed for: r0v2, types: [java.lang.Object, i.V0] */
    public final void h(ColorStateList colorStateList) {
        if (this.f1387e == null) {
            this.f1387e = new Object();
        }
        V0 v0 = this.f1387e;
        v0.f1269a = colorStateList;
        v0.f1271d = true;
        a();
    }

    /* JADX WARNING: type inference failed for: r0v2, types: [java.lang.Object, i.V0] */
    public final void i(PorterDuff.Mode mode) {
        if (this.f1387e == null) {
            this.f1387e = new Object();
        }
        V0 v0 = this.f1387e;
        v0.b = mode;
        v0.f1270c = true;
        a();
    }
}
