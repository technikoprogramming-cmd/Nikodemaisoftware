package i;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Outline;
import android.graphics.drawable.Drawable;
import androidx.appcompat.widget.ActionBarContainer;

/* renamed from: i.b  reason: case insensitive filesystem */
public final class C0047b extends Drawable {

    /* renamed from: a  reason: collision with root package name */
    public final ActionBarContainer f1291a;

    public C0047b(ActionBarContainer actionBarContainer) {
        this.f1291a = actionBarContainer;
    }

    public final void draw(Canvas canvas) {
        ActionBarContainer actionBarContainer = this.f1291a;
        if (actionBarContainer.f384g) {
            Drawable drawable = actionBarContainer.f;
            if (drawable != null) {
                drawable.draw(canvas);
                return;
            }
            return;
        }
        Drawable drawable2 = actionBarContainer.f382d;
        if (drawable2 != null) {
            drawable2.draw(canvas);
        }
        Drawable drawable3 = actionBarContainer.f383e;
        if (drawable3 != null && actionBarContainer.f385h) {
            drawable3.draw(canvas);
        }
    }

    public final int getOpacity() {
        return 0;
    }

    public final void getOutline(Outline outline) {
        ActionBarContainer actionBarContainer = this.f1291a;
        if (!actionBarContainer.f384g) {
            Drawable drawable = actionBarContainer.f382d;
            if (drawable != null) {
                drawable.getOutline(outline);
            }
        } else if (actionBarContainer.f != null) {
            actionBarContainer.f382d.getOutline(outline);
        }
    }

    public final void setAlpha(int i2) {
    }

    public final void setColorFilter(ColorFilter colorFilter) {
    }
}
