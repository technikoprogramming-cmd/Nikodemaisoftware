package i;

import android.view.View;

public abstract class g1 {
    public static void a(View view, CharSequence charSequence) {
        view.setTooltipText(charSequence);
    }
}
