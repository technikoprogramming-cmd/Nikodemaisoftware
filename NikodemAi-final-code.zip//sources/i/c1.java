package i;

public interface c1 {
}
