package i;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.util.Log;

/* renamed from: i.v  reason: case insensitive filesystem */
public final class C0086v {
    public static final PorterDuff.Mode b = PorterDuff.Mode.SRC_IN;

    /* renamed from: c  reason: collision with root package name */
    public static C0086v f1415c;

    /* renamed from: a  reason: collision with root package name */
    public O0 f1416a;

    public static synchronized C0086v a() {
        C0086v vVar;
        synchronized (C0086v.class) {
            try {
                if (f1415c == null) {
                    c();
                }
                vVar = f1415c;
            } catch (Throwable th) {
                while (true) {
                    throw th;
                }
            }
        }
        return vVar;
    }

    /* JADX WARNING: type inference failed for: r1v2, types: [i.v, java.lang.Object] */
    public static synchronized void c() {
        synchronized (C0086v.class) {
            if (f1415c == null) {
                ? obj = new Object();
                f1415c = obj;
                obj.f1416a = O0.b();
                O0 o0 = f1415c.f1416a;
                C0084u uVar = new C0084u();
                synchronized (o0) {
                    o0.f1240e = uVar;
                }
            }
        }
    }

    public static void d(Drawable drawable, V0 v0, int[] iArr) {
        ColorStateList colorStateList;
        PorterDuff.Mode mode;
        PorterDuff.Mode mode2 = O0.f;
        int[] state = drawable.getState();
        if (drawable.mutate() == drawable) {
            if ((drawable instanceof LayerDrawable) && drawable.isStateful()) {
                drawable.setState(new int[0]);
                drawable.setState(state);
            }
            boolean z2 = v0.f1271d;
            if (z2 || v0.f1270c) {
                PorterDuffColorFilter porterDuffColorFilter = null;
                if (z2) {
                    colorStateList = v0.f1269a;
                } else {
                    colorStateList = null;
                }
                if (v0.f1270c) {
                    mode = v0.b;
                } else {
                    mode = O0.f;
                }
                if (!(colorStateList == null || mode == null)) {
                    porterDuffColorFilter = O0.e(colorStateList.getColorForState(iArr, 0), mode);
                }
                drawable.setColorFilter(porterDuffColorFilter);
                return;
            }
            drawable.clearColorFilter();
            return;
        }
        Log.d("ResourceManagerInternal", "Mutated drawable is not the same instance as the input.");
    }

    public final synchronized Drawable b(Context context, int i2) {
        return this.f1416a.c(context, i2);
    }
}
