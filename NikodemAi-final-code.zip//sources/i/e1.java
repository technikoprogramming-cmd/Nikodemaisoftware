package i;

import android.content.Context;
import android.view.View;
import android.view.Window;
import h.C0038a;

public final class e1 implements View.OnClickListener {

    /* renamed from: a  reason: collision with root package name */
    public final C0038a f1304a;
    public final /* synthetic */ f1 b;

    /* JADX WARNING: type inference failed for: r0v0, types: [java.lang.Object, h.a] */
    public e1(f1 f1Var) {
        this.b = f1Var;
        Context context = f1Var.f1305a.getContext();
        CharSequence charSequence = f1Var.f1310h;
        ? obj = new Object();
        obj.f1049e = 4096;
        obj.f1050g = 4096;
        obj.f1055l = null;
        obj.f1056m = null;
        obj.f1057n = false;
        obj.f1058o = false;
        obj.f1059p = 16;
        obj.f1052i = context;
        obj.f1046a = charSequence;
        this.f1304a = obj;
    }

    public final void onClick(View view) {
        f1 f1Var = this.b;
        Window.Callback callback = f1Var.f1313k;
        if (callback != null && f1Var.f1314l) {
            callback.onMenuItemSelected(0, this.f1304a);
        }
    }
}
