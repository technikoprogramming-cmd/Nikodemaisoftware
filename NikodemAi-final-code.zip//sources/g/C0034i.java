package g;

import i.f1;
import z.i;

/* renamed from: g.i  reason: case insensitive filesystem */
public final class C0034i extends i {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f1019a = 0;
    public boolean b;

    /* renamed from: c  reason: collision with root package name */
    public int f1020c;

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ Object f1021d;

    public C0034i(C0035j jVar) {
        this.f1021d = jVar;
        this.b = false;
        this.f1020c = 0;
    }

    public final void a() {
        switch (this.f1019a) {
            case 0:
                int i2 = this.f1020c + 1;
                this.f1020c = i2;
                C0035j jVar = (C0035j) this.f1021d;
                if (i2 == jVar.f1022a.size()) {
                    i iVar = jVar.f1024d;
                    if (iVar != null) {
                        iVar.a();
                    }
                    this.f1020c = 0;
                    this.b = false;
                    jVar.f1025e = false;
                    return;
                }
                return;
            default:
                if (!this.b) {
                    ((f1) this.f1021d).f1305a.setVisibility(this.f1020c);
                    return;
                }
                return;
        }
    }

    public void b() {
        switch (this.f1019a) {
            case 1:
                this.b = true;
                return;
            default:
                return;
        }
    }

    public final void c() {
        switch (this.f1019a) {
            case 0:
                if (!this.b) {
                    this.b = true;
                    i iVar = ((C0035j) this.f1021d).f1024d;
                    if (iVar != null) {
                        iVar.c();
                        return;
                    }
                    return;
                }
                return;
            default:
                ((f1) this.f1021d).f1305a.setVisibility(0);
                return;
        }
    }

    public C0034i(f1 f1Var, int i2) {
        this.f1021d = f1Var;
        this.f1020c = i2;
        this.b = false;
    }
}
