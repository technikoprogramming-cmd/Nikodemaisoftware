package g;

import D.g;
import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.util.AttributeSet;
import android.util.Log;
import android.util.Xml;
import android.view.InflateException;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.SubMenu;
import d.C0010a;
import h.n;
import h.q;
import i.C0074o0;
import java.io.IOException;
import org.xmlpull.v1.XmlPullParserException;

/* renamed from: g.h  reason: case insensitive filesystem */
public final class C0033h extends MenuInflater {

    /* renamed from: e  reason: collision with root package name */
    public static final Class[] f1015e;
    public static final Class[] f;

    /* renamed from: a  reason: collision with root package name */
    public final Object[] f1016a;
    public final Object[] b;

    /* renamed from: c  reason: collision with root package name */
    public final Context f1017c;

    /* renamed from: d  reason: collision with root package name */
    public Object f1018d;

    static {
        Class[] clsArr = {Context.class};
        f1015e = clsArr;
        f = clsArr;
    }

    public C0033h(Context context) {
        super(context);
        this.f1017c = context;
        Object[] objArr = {context};
        this.f1016a = objArr;
        this.b = objArr;
    }

    public static Object a(Object obj) {
        if (!(obj instanceof Activity) && (obj instanceof ContextWrapper)) {
            return a(((ContextWrapper) obj).getBaseContext());
        }
        return obj;
    }

    public final void b(XmlResourceParser xmlResourceParser, AttributeSet attributeSet, Menu menu) {
        boolean z2;
        int i2;
        boolean z3;
        XmlResourceParser xmlResourceParser2;
        char c2;
        char c3;
        boolean z4;
        ColorStateList colorStateList;
        int resourceId;
        AttributeSet attributeSet2 = attributeSet;
        C0032g gVar = new C0032g(this, menu);
        int eventType = xmlResourceParser.getEventType();
        while (true) {
            z2 = true;
            i2 = 2;
            if (eventType == 2) {
                String name = xmlResourceParser.getName();
                if (name.equals("menu")) {
                    eventType = xmlResourceParser.next();
                } else {
                    throw new RuntimeException("Expecting menu, got ".concat(name));
                }
            } else {
                eventType = xmlResourceParser.next();
                if (eventType == 1) {
                    break;
                }
                XmlResourceParser xmlResourceParser3 = xmlResourceParser;
            }
        }
        boolean z5 = false;
        boolean z6 = false;
        String str = null;
        while (!z5) {
            if (eventType != z2) {
                if (eventType != i2) {
                    if (eventType == 3) {
                        String name2 = xmlResourceParser.getName();
                        if (z6 && name2.equals(str)) {
                            xmlResourceParser2 = xmlResourceParser;
                            z3 = z2;
                            z6 = false;
                            str = null;
                            eventType = xmlResourceParser2.next();
                            z2 = z3;
                            i2 = 2;
                        } else if (name2.equals("group")) {
                            gVar.b = 0;
                            gVar.f992c = 0;
                            gVar.f993d = 0;
                            gVar.f994e = 0;
                            gVar.f = z2;
                            gVar.f995g = z2;
                        } else if (name2.equals("item")) {
                            if (!gVar.f996h) {
                                q qVar = gVar.f1014z;
                                if (qVar == null || !qVar.b.hasSubMenu()) {
                                    gVar.f996h = z2;
                                    gVar.b(gVar.f991a.add(gVar.b, gVar.f997i, gVar.f998j, gVar.f999k));
                                } else {
                                    gVar.f996h = z2;
                                    gVar.b(gVar.f991a.addSubMenu(gVar.b, gVar.f997i, gVar.f998j, gVar.f999k).getItem());
                                }
                            }
                        } else if (name2.equals("menu")) {
                            xmlResourceParser2 = xmlResourceParser;
                            z3 = z2;
                            z5 = z3;
                            eventType = xmlResourceParser2.next();
                            z2 = z3;
                            i2 = 2;
                        }
                    }
                } else if (!z6) {
                    String name3 = xmlResourceParser.getName();
                    boolean equals = name3.equals("group");
                    C0033h hVar = gVar.f990E;
                    if (equals) {
                        TypedArray obtainStyledAttributes = hVar.f1017c.obtainStyledAttributes(attributeSet2, C0010a.f784p);
                        gVar.b = obtainStyledAttributes.getResourceId(z2 ? 1 : 0, 0);
                        gVar.f992c = obtainStyledAttributes.getInt(3, 0);
                        gVar.f993d = obtainStyledAttributes.getInt(4, 0);
                        gVar.f994e = obtainStyledAttributes.getInt(5, 0);
                        gVar.f = obtainStyledAttributes.getBoolean(2, z2);
                        gVar.f995g = obtainStyledAttributes.getBoolean(0, z2);
                        obtainStyledAttributes.recycle();
                    } else {
                        if (name3.equals("item")) {
                            Context context = hVar.f1017c;
                            TypedArray obtainStyledAttributes2 = context.obtainStyledAttributes(attributeSet2, C0010a.f785q);
                            gVar.f997i = obtainStyledAttributes2.getResourceId(2, 0);
                            gVar.f998j = (obtainStyledAttributes2.getInt(5, gVar.f992c) & -65536) | (obtainStyledAttributes2.getInt(6, gVar.f993d) & 65535);
                            gVar.f999k = obtainStyledAttributes2.getText(7);
                            gVar.f1000l = obtainStyledAttributes2.getText(8);
                            gVar.f1001m = obtainStyledAttributes2.getResourceId(0, 0);
                            String string = obtainStyledAttributes2.getString(9);
                            if (string == null) {
                                c2 = 0;
                            } else {
                                c2 = string.charAt(0);
                            }
                            gVar.f1002n = c2;
                            gVar.f1003o = obtainStyledAttributes2.getInt(16, 4096);
                            String string2 = obtainStyledAttributes2.getString(10);
                            if (string2 == null) {
                                c3 = 0;
                            } else {
                                c3 = string2.charAt(0);
                            }
                            gVar.f1004p = c3;
                            gVar.f1005q = obtainStyledAttributes2.getInt(20, 4096);
                            if (obtainStyledAttributes2.hasValue(11)) {
                                gVar.f1006r = obtainStyledAttributes2.getBoolean(11, false) ? 1 : 0;
                            } else {
                                gVar.f1006r = gVar.f994e;
                            }
                            gVar.f1007s = obtainStyledAttributes2.getBoolean(3, false);
                            gVar.f1008t = obtainStyledAttributes2.getBoolean(4, gVar.f);
                            gVar.f1009u = obtainStyledAttributes2.getBoolean(1, gVar.f995g);
                            gVar.f1010v = obtainStyledAttributes2.getInt(21, -1);
                            gVar.f1013y = obtainStyledAttributes2.getString(12);
                            gVar.f1011w = obtainStyledAttributes2.getResourceId(13, 0);
                            gVar.f1012x = obtainStyledAttributes2.getString(15);
                            String string3 = obtainStyledAttributes2.getString(14);
                            if (string3 != null) {
                                z4 = true;
                            } else {
                                z4 = false;
                            }
                            if (z4 && gVar.f1011w == 0 && gVar.f1012x == null) {
                                gVar.f1014z = (q) gVar.a(string3, f, hVar.b);
                            } else {
                                if (z4) {
                                    Log.w("SupportMenuInflater", "Ignoring attribute 'actionProviderClass'. Action view already specified.");
                                }
                                gVar.f1014z = null;
                            }
                            gVar.f986A = obtainStyledAttributes2.getText(17);
                            gVar.f987B = obtainStyledAttributes2.getText(22);
                            if (obtainStyledAttributes2.hasValue(19)) {
                                gVar.f989D = C0074o0.b(obtainStyledAttributes2.getInt(19, -1), gVar.f989D);
                            } else {
                                gVar.f989D = null;
                            }
                            if (obtainStyledAttributes2.hasValue(18)) {
                                if (!obtainStyledAttributes2.hasValue(18) || (resourceId = obtainStyledAttributes2.getResourceId(18, 0)) == 0 || (colorStateList = g.q(context, resourceId)) == null) {
                                    colorStateList = obtainStyledAttributes2.getColorStateList(18);
                                }
                                gVar.f988C = colorStateList;
                            } else {
                                gVar.f988C = null;
                            }
                            obtainStyledAttributes2.recycle();
                            gVar.f996h = false;
                            xmlResourceParser2 = xmlResourceParser;
                            z3 = true;
                        } else if (name3.equals("menu")) {
                            z3 = true;
                            gVar.f996h = true;
                            SubMenu addSubMenu = gVar.f991a.addSubMenu(gVar.b, gVar.f997i, gVar.f998j, gVar.f999k);
                            gVar.b(addSubMenu.getItem());
                            xmlResourceParser2 = xmlResourceParser;
                            b(xmlResourceParser2, attributeSet2, addSubMenu);
                        } else {
                            xmlResourceParser2 = xmlResourceParser;
                            z3 = true;
                            str = name3;
                            z6 = true;
                        }
                        eventType = xmlResourceParser2.next();
                        z2 = z3;
                        i2 = 2;
                    }
                }
                xmlResourceParser2 = xmlResourceParser;
                z3 = z2;
                eventType = xmlResourceParser2.next();
                z2 = z3;
                i2 = 2;
            } else {
                throw new RuntimeException("Unexpected end of document");
            }
        }
    }

    public final void inflate(int i2, Menu menu) {
        if (!(menu instanceof n)) {
            super.inflate(i2, menu);
            return;
        }
        XmlResourceParser xmlResourceParser = null;
        boolean z2 = false;
        try {
            XmlResourceParser layout = this.f1017c.getResources().getLayout(i2);
            AttributeSet asAttributeSet = Xml.asAttributeSet(layout);
            if (menu instanceof n) {
                n nVar = (n) menu;
                if (!nVar.f1115p) {
                    nVar.w();
                    z2 = true;
                }
            }
            b(layout, asAttributeSet, menu);
            if (z2) {
                ((n) menu).v();
            }
            layout.close();
        } catch (XmlPullParserException e2) {
            throw new InflateException("Error inflating menu XML", e2);
        } catch (IOException e3) {
            throw new InflateException("Error inflating menu XML", e3);
        } catch (Throwable th) {
            if (0 != 0) {
                ((n) menu).v();
            }
            if (xmlResourceParser != null) {
                xmlResourceParser.close();
            }
            throw th;
        }
    }
}
