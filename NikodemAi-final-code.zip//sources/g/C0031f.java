package g;

import android.view.MenuItem;
import java.lang.reflect.Method;

/* renamed from: g.f  reason: case insensitive filesystem */
public final class C0031f implements MenuItem.OnMenuItemClickListener {

    /* renamed from: c  reason: collision with root package name */
    public static final Class[] f984c = {MenuItem.class};

    /* renamed from: a  reason: collision with root package name */
    public Object f985a;
    public Method b;

    public final boolean onMenuItemClick(MenuItem menuItem) {
        Method method = this.b;
        try {
            Class<?> returnType = method.getReturnType();
            Class<?> cls = Boolean.TYPE;
            Object obj = this.f985a;
            if (returnType == cls) {
                return ((Boolean) method.invoke(obj, new Object[]{menuItem})).booleanValue();
            }
            method.invoke(obj, new Object[]{menuItem});
            return true;
        } catch (Exception e2) {
            throw new RuntimeException(e2);
        }
    }
}
