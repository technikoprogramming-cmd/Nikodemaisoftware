package g;

import android.view.MenuInflater;
import android.view.View;
import h.n;

/* renamed from: g.a  reason: case insensitive filesystem */
public abstract class C0026a {

    /* renamed from: a  reason: collision with root package name */
    public Object f973a;
    public boolean b;

    public abstract void a();

    public abstract View b();

    public abstract n c();

    public abstract MenuInflater d();

    public abstract CharSequence e();

    public abstract CharSequence f();

    public abstract void i();

    public abstract boolean j();

    public abstract void k(View view);

    public abstract void l(int i2);

    public abstract void m(CharSequence charSequence);

    public abstract void n(int i2);

    public abstract void o(CharSequence charSequence);

    public abstract void p(boolean z2);
}
