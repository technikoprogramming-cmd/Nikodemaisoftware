package g;

import android.view.View;
import android.view.animation.BaseInterpolator;
import java.util.ArrayList;
import y.Q;
import z.i;

/* renamed from: g.j  reason: case insensitive filesystem */
public final class C0035j {

    /* renamed from: a  reason: collision with root package name */
    public final ArrayList f1022a = new ArrayList();
    public long b = -1;

    /* renamed from: c  reason: collision with root package name */
    public BaseInterpolator f1023c;

    /* renamed from: d  reason: collision with root package name */
    public i f1024d;

    /* renamed from: e  reason: collision with root package name */
    public boolean f1025e;
    public final C0034i f = new C0034i(this);

    public final void a() {
        if (this.f1025e) {
            ArrayList arrayList = this.f1022a;
            int size = arrayList.size();
            int i2 = 0;
            while (i2 < size) {
                Object obj = arrayList.get(i2);
                i2++;
                ((Q) obj).b();
            }
            this.f1025e = false;
        }
    }

    public final void b() {
        View view;
        if (!this.f1025e) {
            ArrayList arrayList = this.f1022a;
            int size = arrayList.size();
            int i2 = 0;
            while (i2 < size) {
                Object obj = arrayList.get(i2);
                i2++;
                Q q2 = (Q) obj;
                long j2 = this.b;
                if (j2 >= 0) {
                    q2.c(j2);
                }
                BaseInterpolator baseInterpolator = this.f1023c;
                if (!(baseInterpolator == null || (view = (View) q2.f1639a.get()) == null)) {
                    view.animate().setInterpolator(baseInterpolator);
                }
                if (this.f1024d != null) {
                    q2.d(this.f);
                }
                View view2 = (View) q2.f1639a.get();
                if (view2 != null) {
                    view2.animate().start();
                }
            }
            this.f1025e = true;
        }
    }
}
