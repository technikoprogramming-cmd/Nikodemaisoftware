package g;

import android.view.Window;

public abstract class m {
    public static void a(Window.Callback callback, boolean z2) {
        callback.onPointerCaptureChanged(z2);
    }
}
