package g;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.os.Build;
import android.util.Log;
import android.view.InflateException;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import h.p;
import h.q;
import h.u;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import t.C0129a;
import y.C0161l;

/* renamed from: g.g  reason: case insensitive filesystem */
public final class C0032g {

    /* renamed from: A  reason: collision with root package name */
    public CharSequence f986A;

    /* renamed from: B  reason: collision with root package name */
    public CharSequence f987B;

    /* renamed from: C  reason: collision with root package name */
    public ColorStateList f988C = null;

    /* renamed from: D  reason: collision with root package name */
    public PorterDuff.Mode f989D = null;

    /* renamed from: E  reason: collision with root package name */
    public final /* synthetic */ C0033h f990E;

    /* renamed from: a  reason: collision with root package name */
    public final Menu f991a;
    public int b;

    /* renamed from: c  reason: collision with root package name */
    public int f992c;

    /* renamed from: d  reason: collision with root package name */
    public int f993d;

    /* renamed from: e  reason: collision with root package name */
    public int f994e;
    public boolean f;

    /* renamed from: g  reason: collision with root package name */
    public boolean f995g;

    /* renamed from: h  reason: collision with root package name */
    public boolean f996h;

    /* renamed from: i  reason: collision with root package name */
    public int f997i;

    /* renamed from: j  reason: collision with root package name */
    public int f998j;

    /* renamed from: k  reason: collision with root package name */
    public CharSequence f999k;

    /* renamed from: l  reason: collision with root package name */
    public CharSequence f1000l;

    /* renamed from: m  reason: collision with root package name */
    public int f1001m;

    /* renamed from: n  reason: collision with root package name */
    public char f1002n;

    /* renamed from: o  reason: collision with root package name */
    public int f1003o;

    /* renamed from: p  reason: collision with root package name */
    public char f1004p;

    /* renamed from: q  reason: collision with root package name */
    public int f1005q;

    /* renamed from: r  reason: collision with root package name */
    public int f1006r;

    /* renamed from: s  reason: collision with root package name */
    public boolean f1007s;

    /* renamed from: t  reason: collision with root package name */
    public boolean f1008t;

    /* renamed from: u  reason: collision with root package name */
    public boolean f1009u;

    /* renamed from: v  reason: collision with root package name */
    public int f1010v;

    /* renamed from: w  reason: collision with root package name */
    public int f1011w;

    /* renamed from: x  reason: collision with root package name */
    public String f1012x;

    /* renamed from: y  reason: collision with root package name */
    public String f1013y;

    /* renamed from: z  reason: collision with root package name */
    public q f1014z;

    public C0032g(C0033h hVar, Menu menu) {
        this.f990E = hVar;
        this.f991a = menu;
        this.b = 0;
        this.f992c = 0;
        this.f993d = 0;
        this.f994e = 0;
        this.f = true;
        this.f995g = true;
    }

    public final Object a(String str, Class[] clsArr, Object[] objArr) {
        try {
            Constructor<?> constructor = Class.forName(str, false, this.f990E.f1017c.getClassLoader()).getConstructor(clsArr);
            constructor.setAccessible(true);
            return constructor.newInstance(objArr);
        } catch (Exception e2) {
            Log.w("SupportMenuInflater", "Cannot instantiate class: " + str, e2);
            return null;
        }
    }

    /* JADX WARNING: type inference failed for: r0v33, types: [android.view.MenuItem$OnMenuItemClickListener, java.lang.Object, g.f] */
    public final void b(MenuItem menuItem) {
        boolean z2;
        MenuItem enabled = menuItem.setChecked(this.f1007s).setVisible(this.f1008t).setEnabled(this.f1009u);
        boolean z3 = false;
        if (this.f1006r >= 1) {
            z2 = true;
        } else {
            z2 = false;
        }
        enabled.setCheckable(z2).setTitleCondensed(this.f1000l).setIcon(this.f1001m);
        int i2 = this.f1010v;
        if (i2 >= 0) {
            menuItem.setShowAsAction(i2);
        }
        String str = this.f1013y;
        C0033h hVar = this.f990E;
        if (str != null) {
            if (!hVar.f1017c.isRestricted()) {
                if (hVar.f1018d == null) {
                    hVar.f1018d = C0033h.a(hVar.f1017c);
                }
                Object obj = hVar.f1018d;
                String str2 = this.f1013y;
                ? obj2 = new Object();
                obj2.f985a = obj;
                Class<?> cls = obj.getClass();
                try {
                    obj2.b = cls.getMethod(str2, C0031f.f984c);
                    menuItem.setOnMenuItemClickListener(obj2);
                } catch (Exception e2) {
                    InflateException inflateException = new InflateException("Couldn't resolve menu item onClick handler " + str2 + " in class " + cls.getName());
                    inflateException.initCause(e2);
                    throw inflateException;
                }
            } else {
                throw new IllegalStateException("The android:onClick attribute cannot be used within a restricted context");
            }
        }
        if (this.f1006r >= 2) {
            if (menuItem instanceof p) {
                p pVar = (p) menuItem;
                pVar.f1150x = (pVar.f1150x & -5) | 4;
            } else if (menuItem instanceof u) {
                u uVar = (u) menuItem;
                try {
                    Method method = uVar.f1159d;
                    C0129a aVar = uVar.f1158c;
                    if (method == null) {
                        uVar.f1159d = aVar.getClass().getDeclaredMethod("setExclusiveCheckable", new Class[]{Boolean.TYPE});
                    }
                    uVar.f1159d.invoke(aVar, new Object[]{Boolean.TRUE});
                } catch (Exception e3) {
                    Log.w("MenuItemWrapper", "Error while calling setExclusiveCheckable", e3);
                }
            }
        }
        String str3 = this.f1012x;
        if (str3 != null) {
            menuItem.setActionView((View) a(str3, C0033h.f1015e, hVar.f1016a));
            z3 = true;
        }
        int i3 = this.f1011w;
        if (i3 > 0) {
            if (!z3) {
                menuItem.setActionView(i3);
            } else {
                Log.w("SupportMenuInflater", "Ignoring attribute 'itemActionViewLayout'. Action view already specified.");
            }
        }
        q qVar = this.f1014z;
        if (qVar != null) {
            if (menuItem instanceof C0129a) {
                ((C0129a) menuItem).b(qVar);
            } else {
                Log.w("MenuItemCompat", "setActionProvider: item does not implement SupportMenuItem; ignoring");
            }
        }
        CharSequence charSequence = this.f986A;
        boolean z4 = menuItem instanceof C0129a;
        if (z4) {
            ((C0129a) menuItem).setContentDescription(charSequence);
        } else if (Build.VERSION.SDK_INT >= 26) {
            C0161l.h(menuItem, charSequence);
        }
        CharSequence charSequence2 = this.f987B;
        if (z4) {
            ((C0129a) menuItem).setTooltipText(charSequence2);
        } else if (Build.VERSION.SDK_INT >= 26) {
            C0161l.m(menuItem, charSequence2);
        }
        char c2 = this.f1002n;
        int i4 = this.f1003o;
        if (z4) {
            ((C0129a) menuItem).setAlphabeticShortcut(c2, i4);
        } else if (Build.VERSION.SDK_INT >= 26) {
            C0161l.g(menuItem, c2, i4);
        }
        char c3 = this.f1004p;
        int i5 = this.f1005q;
        if (z4) {
            ((C0129a) menuItem).setNumericShortcut(c3, i5);
        } else if (Build.VERSION.SDK_INT >= 26) {
            C0161l.k(menuItem, c3, i5);
        }
        PorterDuff.Mode mode = this.f989D;
        if (mode != null) {
            if (z4) {
                ((C0129a) menuItem).setIconTintMode(mode);
            } else if (Build.VERSION.SDK_INT >= 26) {
                C0161l.j(menuItem, mode);
            }
        }
        ColorStateList colorStateList = this.f988C;
        if (colorStateList == null) {
            return;
        }
        if (z4) {
            ((C0129a) menuItem).setIconTintList(colorStateList);
        } else if (Build.VERSION.SDK_INT >= 26) {
            C0161l.i(menuItem, colorStateList);
        }
    }
}
