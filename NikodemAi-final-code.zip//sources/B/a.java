package B;

public abstract class a {
}
