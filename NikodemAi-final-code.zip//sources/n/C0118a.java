package n;

import ncs.oprogramowanie.nikodemai.aos.R;

/* renamed from: n.a  reason: case insensitive filesystem */
public abstract class C0118a {

    /* renamed from: a  reason: collision with root package name */
    public static final int[] f1522a = {16843173, 16843551, 16844359, R.attr.alpha, R.attr.lStar};
    public static final int[] b = {R.attr.fontProviderAuthority, R.attr.fontProviderCerts, R.attr.fontProviderFetchStrategy, R.attr.fontProviderFetchTimeout, R.attr.fontProviderPackage, R.attr.fontProviderQuery, R.attr.fontProviderSystemFontFamily};

    /* renamed from: c  reason: collision with root package name */
    public static final int[] f1523c = {16844082, 16844083, 16844095, 16844143, 16844144, R.attr.font, R.attr.fontStyle, R.attr.fontVariationSettings, R.attr.fontWeight, R.attr.ttcIndex};
}
