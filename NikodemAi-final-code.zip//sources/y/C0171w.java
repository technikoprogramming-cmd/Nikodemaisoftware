package y;

import F.c;
import android.text.TextUtils;
import android.view.View;

/* renamed from: y.w  reason: case insensitive filesystem */
public final class C0171w extends c {

    /* renamed from: e  reason: collision with root package name */
    public final /* synthetic */ int f1688e;

    public C0171w(int i2, Class cls, int i3, int i4, int i5) {
        this.f1688e = i5;
        this.f53a = i2;
        this.f55d = cls;
        this.f54c = i3;
        this.b = i4;
    }

    public final Object b(View view) {
        switch (this.f1688e) {
            case 0:
                return Boolean.valueOf(D.d(view));
            case 1:
                return D.b(view);
            default:
                return Boolean.valueOf(D.c(view));
        }
    }

    public final void c(View view, Object obj) {
        switch (this.f1688e) {
            case 0:
                D.j(view, ((Boolean) obj).booleanValue());
                return;
            case 1:
                D.h(view, (CharSequence) obj);
                return;
            default:
                D.g(view, ((Boolean) obj).booleanValue());
                return;
        }
    }

    public final boolean e(Object obj, Object obj2) {
        boolean z2;
        boolean z3;
        boolean z4;
        boolean z5;
        switch (this.f1688e) {
            case 0:
                Boolean bool = (Boolean) obj;
                Boolean bool2 = (Boolean) obj2;
                boolean z6 = false;
                if (bool == null || !bool.booleanValue()) {
                    z2 = false;
                } else {
                    z2 = true;
                }
                if (bool2 == null || !bool2.booleanValue()) {
                    z3 = false;
                } else {
                    z3 = true;
                }
                if (z2 == z3) {
                    z6 = true;
                }
                return !z6;
            case 1:
                return !TextUtils.equals((CharSequence) obj, (CharSequence) obj2);
            default:
                Boolean bool3 = (Boolean) obj;
                Boolean bool4 = (Boolean) obj2;
                boolean z7 = false;
                if (bool3 == null || !bool3.booleanValue()) {
                    z4 = false;
                } else {
                    z4 = true;
                }
                if (bool4 == null || !bool4.booleanValue()) {
                    z5 = false;
                } else {
                    z5 = true;
                }
                if (z4 == z5) {
                    z7 = true;
                }
                return !z7;
        }
    }
}
