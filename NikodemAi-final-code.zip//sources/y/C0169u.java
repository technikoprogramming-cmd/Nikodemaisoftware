package y;

/* renamed from: y.u  reason: case insensitive filesystem */
public final class C0169u {

    /* renamed from: a  reason: collision with root package name */
    public final float[] f1684a = new float[20];
    public final long[] b = new long[20];

    /* renamed from: c  reason: collision with root package name */
    public float f1685c = 0.0f;

    /* renamed from: d  reason: collision with root package name */
    public int f1686d = 0;

    /* renamed from: e  reason: collision with root package name */
    public int f1687e = 0;
}
