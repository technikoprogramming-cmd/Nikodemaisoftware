package y;

import android.view.View;
import android.view.WindowInsets;
import r.c;

public class b0 extends a0 {

    /* renamed from: n  reason: collision with root package name */
    public c f1661n = null;

    /* renamed from: o  reason: collision with root package name */
    public c f1662o = null;

    /* renamed from: p  reason: collision with root package name */
    public c f1663p = null;

    public b0(f0 f0Var, WindowInsets windowInsets) {
        super(f0Var, windowInsets);
    }

    public c g() {
        if (this.f1662o == null) {
            this.f1662o = c.b(this.f1653c.getMandatorySystemGestureInsets());
        }
        return this.f1662o;
    }

    public c i() {
        if (this.f1661n == null) {
            this.f1661n = c.b(this.f1653c.getSystemGestureInsets());
        }
        return this.f1661n;
    }

    public c k() {
        if (this.f1663p == null) {
            this.f1663p = c.b(this.f1653c.getTappableElementInsets());
        }
        return this.f1663p;
    }

    public f0 l(int i2, int i3, int i4, int i5) {
        return f0.c(this.f1653c.inset(i2, i3, i4, i5), (View) null);
    }

    public void q(c cVar) {
    }
}
