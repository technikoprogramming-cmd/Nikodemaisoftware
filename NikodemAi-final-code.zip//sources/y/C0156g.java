package y;

/* renamed from: y.g  reason: case insensitive filesystem */
public final class C0156g {

    /* renamed from: a  reason: collision with root package name */
    public final C0155f f1671a;

    public C0156g(C0155f fVar) {
        this.f1671a = fVar;
    }

    public final String toString() {
        return this.f1671a.toString();
    }
}
