package y;

public interface r {
    C0156g a(C0156g gVar);
}
