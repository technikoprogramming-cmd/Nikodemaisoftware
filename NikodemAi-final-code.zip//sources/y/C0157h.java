package y;

import C.j;
import android.content.Context;
import android.view.VelocityTracker;

/* renamed from: y.h  reason: case insensitive filesystem */
public final class C0157h {

    /* renamed from: a  reason: collision with root package name */
    public final Context f1672a;
    public final j b;

    /* renamed from: c  reason: collision with root package name */
    public VelocityTracker f1673c;

    /* renamed from: d  reason: collision with root package name */
    public float f1674d;

    /* renamed from: e  reason: collision with root package name */
    public int f1675e = -1;
    public int f = -1;

    /* renamed from: g  reason: collision with root package name */
    public int f1676g = -1;

    /* renamed from: h  reason: collision with root package name */
    public final int[] f1677h = {Integer.MAX_VALUE, 0};

    public C0157h(Context context, j jVar) {
        this.f1672a = context;
        this.b = jVar;
    }
}
