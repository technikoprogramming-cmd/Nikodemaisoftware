package y;

import android.view.View;
import android.view.WindowInsets;
import r.c;

public class Z extends Y {

    /* renamed from: m  reason: collision with root package name */
    public c f1657m = null;

    public Z(f0 f0Var, WindowInsets windowInsets) {
        super(f0Var, windowInsets);
    }

    public f0 b() {
        return f0.c(this.f1653c.consumeStableInsets(), (View) null);
    }

    public f0 c() {
        return f0.c(this.f1653c.consumeSystemWindowInsets(), (View) null);
    }

    public final c h() {
        if (this.f1657m == null) {
            WindowInsets windowInsets = this.f1653c;
            this.f1657m = c.a(windowInsets.getStableInsetLeft(), windowInsets.getStableInsetTop(), windowInsets.getStableInsetRight(), windowInsets.getStableInsetBottom());
        }
        return this.f1657m;
    }

    public boolean m() {
        return this.f1653c.isConsumed();
    }

    public void q(c cVar) {
        this.f1657m = cVar;
    }
}
