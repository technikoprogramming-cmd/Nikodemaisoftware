package y;

import android.graphics.Rect;
import android.os.Build;
import android.util.Log;
import android.view.View;
import android.view.WindowInsets;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Objects;
import r.c;

public abstract class Y extends d0 {

    /* renamed from: h  reason: collision with root package name */
    public static boolean f1648h = false;

    /* renamed from: i  reason: collision with root package name */
    public static Method f1649i;

    /* renamed from: j  reason: collision with root package name */
    public static Class f1650j;

    /* renamed from: k  reason: collision with root package name */
    public static Field f1651k;

    /* renamed from: l  reason: collision with root package name */
    public static Field f1652l;

    /* renamed from: c  reason: collision with root package name */
    public final WindowInsets f1653c;

    /* renamed from: d  reason: collision with root package name */
    public c[] f1654d;

    /* renamed from: e  reason: collision with root package name */
    public c f1655e = null;
    public f0 f;

    /* renamed from: g  reason: collision with root package name */
    public c f1656g;

    public Y(f0 f0Var, WindowInsets windowInsets) {
        super(f0Var);
        this.f1653c = windowInsets;
    }

    private c r(int i2, boolean z2) {
        c cVar = c.f1585e;
        for (int i3 = 1; i3 <= 256; i3 <<= 1) {
            if ((i2 & i3) != 0) {
                c s2 = s(i3, z2);
                cVar = c.a(Math.max(cVar.f1586a, s2.f1586a), Math.max(cVar.b, s2.b), Math.max(cVar.f1587c, s2.f1587c), Math.max(cVar.f1588d, s2.f1588d));
            }
        }
        return cVar;
    }

    private c t() {
        f0 f0Var = this.f;
        if (f0Var != null) {
            return f0Var.f1670a.h();
        }
        return c.f1585e;
    }

    private c u(View view) {
        if (Build.VERSION.SDK_INT < 30) {
            if (!f1648h) {
                v();
            }
            Method method = f1649i;
            if (!(method == null || f1650j == null || f1651k == null)) {
                try {
                    Object invoke = method.invoke(view, (Object[]) null);
                    if (invoke == null) {
                        Log.w("WindowInsetsCompat", "Failed to get visible insets. getViewRootImpl() returned null from the provided view. This means that the view is either not attached or the method has been overridden", new NullPointerException());
                        return null;
                    }
                    Rect rect = (Rect) f1651k.get(f1652l.get(invoke));
                    if (rect != null) {
                        return c.a(rect.left, rect.top, rect.right, rect.bottom);
                    }
                } catch (ReflectiveOperationException e2) {
                    Log.e("WindowInsetsCompat", "Failed to get visible insets. (Reflection error). " + e2.getMessage(), e2);
                }
            }
            return null;
        }
        throw new UnsupportedOperationException("getVisibleInsets() should not be called on API >= 30. Use WindowInsets.isVisible() instead.");
    }

    private static void v() {
        try {
            f1649i = View.class.getDeclaredMethod("getViewRootImpl", (Class[]) null);
            Class<?> cls = Class.forName("android.view.View$AttachInfo");
            f1650j = cls;
            f1651k = cls.getDeclaredField("mVisibleInsets");
            f1652l = Class.forName("android.view.ViewRootImpl").getDeclaredField("mAttachInfo");
            f1651k.setAccessible(true);
            f1652l.setAccessible(true);
        } catch (ReflectiveOperationException e2) {
            Log.e("WindowInsetsCompat", "Failed to get visible insets. (Reflection error). " + e2.getMessage(), e2);
        }
        f1648h = true;
    }

    public void d(View view) {
        c u2 = u(view);
        if (u2 == null) {
            u2 = c.f1585e;
        }
        w(u2);
    }

    public boolean equals(Object obj) {
        if (!super.equals(obj)) {
            return false;
        }
        return Objects.equals(this.f1656g, ((Y) obj).f1656g);
    }

    public c f(int i2) {
        return r(i2, false);
    }

    public final c j() {
        if (this.f1655e == null) {
            WindowInsets windowInsets = this.f1653c;
            this.f1655e = c.a(windowInsets.getSystemWindowInsetLeft(), windowInsets.getSystemWindowInsetTop(), windowInsets.getSystemWindowInsetRight(), windowInsets.getSystemWindowInsetBottom());
        }
        return this.f1655e;
    }

    public f0 l(int i2, int i3, int i4, int i5) {
        X x2;
        f0 c2 = f0.c(this.f1653c, (View) null);
        int i6 = Build.VERSION.SDK_INT;
        if (i6 >= 30) {
            x2 = new W(c2);
        } else if (i6 >= 29) {
            x2 = new V(c2);
        } else {
            x2 = new U(c2);
        }
        x2.d(f0.a(j(), i2, i3, i4, i5));
        x2.c(f0.a(h(), i2, i3, i4, i5));
        return x2.b();
    }

    public boolean n() {
        return this.f1653c.isRound();
    }

    public void o(c[] cVarArr) {
        this.f1654d = cVarArr;
    }

    public void p(f0 f0Var) {
        this.f = f0Var;
    }

    public c s(int i2, boolean z2) {
        int i3;
        C0159j jVar;
        int i4;
        int i5;
        int i6;
        int i7 = 0;
        if (i2 != 1) {
            c cVar = null;
            if (i2 != 2) {
                c cVar2 = c.f1585e;
                if (i2 == 8) {
                    c[] cVarArr = this.f1654d;
                    if (cVarArr != null) {
                        cVar = cVarArr[3];
                    }
                    if (cVar != null) {
                        return cVar;
                    }
                    c j2 = j();
                    c t2 = t();
                    int i8 = j2.f1588d;
                    if (i8 > t2.f1588d) {
                        return c.a(0, 0, 0, i8);
                    }
                    c cVar3 = this.f1656g;
                    if (cVar3 != null && !cVar3.equals(cVar2) && (i3 = this.f1656g.f1588d) > t2.f1588d) {
                        return c.a(0, 0, 0, i3);
                    }
                } else if (i2 == 16) {
                    return i();
                } else {
                    if (i2 == 32) {
                        return g();
                    }
                    if (i2 == 64) {
                        return k();
                    }
                    if (i2 == 128) {
                        f0 f0Var = this.f;
                        if (f0Var != null) {
                            jVar = f0Var.f1670a.e();
                        } else {
                            jVar = e();
                        }
                        if (jVar != null) {
                            int i9 = Build.VERSION.SDK_INT;
                            if (i9 >= 28) {
                                i4 = C0158i.d(jVar.f1678a);
                            } else {
                                i4 = 0;
                            }
                            if (i9 >= 28) {
                                i5 = C0158i.f(jVar.f1678a);
                            } else {
                                i5 = 0;
                            }
                            if (i9 >= 28) {
                                i6 = C0158i.e(jVar.f1678a);
                            } else {
                                i6 = 0;
                            }
                            if (i9 >= 28) {
                                i7 = C0158i.c(jVar.f1678a);
                            }
                            return c.a(i4, i5, i6, i7);
                        }
                    }
                }
                return cVar2;
            } else if (z2) {
                c t3 = t();
                c h2 = h();
                return c.a(Math.max(t3.f1586a, h2.f1586a), 0, Math.max(t3.f1587c, h2.f1587c), Math.max(t3.f1588d, h2.f1588d));
            } else {
                c j3 = j();
                f0 f0Var2 = this.f;
                if (f0Var2 != null) {
                    cVar = f0Var2.f1670a.h();
                }
                int i10 = j3.f1588d;
                if (cVar != null) {
                    i10 = Math.min(i10, cVar.f1588d);
                }
                return c.a(j3.f1586a, 0, j3.f1587c, i10);
            }
        } else if (z2) {
            return c.a(0, Math.max(t().b, j().b), 0, 0);
        } else {
            return c.a(0, j().b, 0, 0);
        }
    }

    public void w(c cVar) {
        this.f1656g = cVar;
    }
}
