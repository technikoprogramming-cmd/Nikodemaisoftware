package y;

import android.os.Build;
import android.view.View;
import android.view.WindowInsets;
import java.util.WeakHashMap;

/* renamed from: y.z  reason: case insensitive filesystem */
public final class C0174z implements View.OnApplyWindowInsetsListener {

    /* renamed from: a  reason: collision with root package name */
    public f0 f1690a = null;
    public final /* synthetic */ View b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ C0165p f1691c;

    public C0174z(View view, C0165p pVar) {
        this.b = view;
        this.f1691c = pVar;
    }

    public WindowInsets onApplyWindowInsets(View view, WindowInsets windowInsets) {
        f0 c2 = f0.c(windowInsets, view);
        int i2 = Build.VERSION.SDK_INT;
        C0165p pVar = this.f1691c;
        if (i2 < 30) {
            C0148A.a(windowInsets, this.b);
            if (c2.equals(this.f1690a)) {
                return pVar.a(view, c2).b();
            }
        }
        this.f1690a = c2;
        f0 a2 = pVar.a(view, c2);
        if (i2 >= 30) {
            return a2.b();
        }
        WeakHashMap weakHashMap = K.f1633a;
        C0173y.c(view);
        return a2.b();
    }
}
