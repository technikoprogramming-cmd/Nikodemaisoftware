package y;

import r.c;

public abstract class X {
    public X() {
        this(new f0());
    }

    public abstract f0 b();

    public abstract void c(c cVar);

    public abstract void d(c cVar);

    public X(f0 f0Var) {
    }

    public final void a() {
    }
}
