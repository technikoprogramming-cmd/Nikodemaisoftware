package y;

import android.view.View;
import android.view.WindowInsets;
import r.c;

public final class c0 extends b0 {

    /* renamed from: q  reason: collision with root package name */
    public static final f0 f1664q = f0.c(WindowInsets.CONSUMED, (View) null);

    public c0(f0 f0Var, WindowInsets windowInsets) {
        super(f0Var, windowInsets);
    }

    public c f(int i2) {
        return c.b(this.f1653c.getInsets(e0.a(i2)));
    }

    public final void d(View view) {
    }
}
