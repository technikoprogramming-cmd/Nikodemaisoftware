package y;

import Q.a;
import android.view.View;
import android.view.WindowInsets;
import r.c;

public class V extends X {

    /* renamed from: a  reason: collision with root package name */
    public final WindowInsets.Builder f1647a;

    public V() {
        this.f1647a = a.d();
    }

    public f0 b() {
        a();
        f0 c2 = f0.c(this.f1647a.build(), (View) null);
        c2.f1670a.o((c[]) null);
        return c2;
    }

    public void c(c cVar) {
        this.f1647a.setStableInsets(cVar.c());
    }

    public void d(c cVar) {
        this.f1647a.setSystemWindowInsets(cVar.c());
    }

    public V(f0 f0Var) {
        super(f0Var);
        WindowInsets.Builder builder;
        WindowInsets b = f0Var.b();
        if (b != null) {
            builder = a.e(b);
        } else {
            builder = a.d();
        }
        this.f1647a = builder;
    }
}
