package y;

import android.content.ClipData;
import android.net.Uri;
import android.os.Bundle;
import android.view.ContentInfo;
import java.util.Locale;

/* renamed from: y.e  reason: case insensitive filesystem */
public final class C0154e implements C0153d, C0155f {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f1666a = 0;
    public ClipData b;

    /* renamed from: c  reason: collision with root package name */
    public int f1667c;

    /* renamed from: d  reason: collision with root package name */
    public int f1668d;

    /* renamed from: e  reason: collision with root package name */
    public Uri f1669e;
    public Bundle f;

    public /* synthetic */ C0154e() {
    }

    public void a(Bundle bundle) {
        this.f = bundle;
    }

    public void e(Uri uri) {
        this.f1669e = uri;
    }

    public int f() {
        return this.f1667c;
    }

    public ClipData j() {
        return this.b;
    }

    public C0156g k() {
        return new C0156g(new C0154e(this));
    }

    public int n() {
        return this.f1668d;
    }

    public ContentInfo s() {
        return null;
    }

    public String toString() {
        String str;
        String str2;
        String str3;
        switch (this.f1666a) {
            case 1:
                StringBuilder sb = new StringBuilder("ContentInfoCompat{clip=");
                sb.append(this.b.getDescription());
                sb.append(", source=");
                int i2 = this.f1667c;
                if (i2 == 0) {
                    str = "SOURCE_APP";
                } else if (i2 == 1) {
                    str = "SOURCE_CLIPBOARD";
                } else if (i2 == 2) {
                    str = "SOURCE_INPUT_METHOD";
                } else if (i2 == 3) {
                    str = "SOURCE_DRAG_AND_DROP";
                } else if (i2 == 4) {
                    str = "SOURCE_AUTOFILL";
                } else if (i2 != 5) {
                    str = String.valueOf(i2);
                } else {
                    str = "SOURCE_PROCESS_TEXT";
                }
                sb.append(str);
                sb.append(", flags=");
                int i3 = this.f1668d;
                if ((i3 & 1) != 0) {
                    str2 = "FLAG_CONVERT_TO_PLAIN_TEXT";
                } else {
                    str2 = String.valueOf(i3);
                }
                sb.append(str2);
                String str4 = "";
                Uri uri = this.f1669e;
                if (uri == null) {
                    str3 = str4;
                } else {
                    str3 = ", hasLinkUri(" + uri.toString().length() + ")";
                }
                sb.append(str3);
                if (this.f != null) {
                    str4 = ", hasExtras";
                }
                sb.append(str4);
                sb.append("}");
                return sb.toString();
            default:
                return super.toString();
        }
    }

    public void w(int i2) {
        this.f1668d = i2;
    }

    public C0154e(C0154e eVar) {
        ClipData clipData = eVar.b;
        clipData.getClass();
        this.b = clipData;
        int i2 = eVar.f1667c;
        if (i2 < 0) {
            Locale locale = Locale.US;
            throw new IllegalArgumentException("source is out of range of [0, 5] (too low)");
        } else if (i2 <= 5) {
            this.f1667c = i2;
            int i3 = eVar.f1668d;
            if ((i3 & 1) == i3) {
                this.f1668d = i3;
                this.f1669e = eVar.f1669e;
                this.f = eVar.f;
                return;
            }
            throw new IllegalArgumentException("Requested flags 0x" + Integer.toHexString(i3) + ", but only 0x" + Integer.toHexString(1) + " are allowed");
        } else {
            Locale locale2 = Locale.US;
            throw new IllegalArgumentException("source is out of range of [0, 5] (too high)");
        }
    }
}
