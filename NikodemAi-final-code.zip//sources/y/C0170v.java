package y;

/* renamed from: y.v  reason: case insensitive filesystem */
public final /* synthetic */ class C0170v implements r {
    public final C0156g a(C0156g gVar) {
        return gVar;
    }
}
