package y;

import C.j;
import D.u;
import android.view.ContentInfo;
import android.view.OnReceiveContentListener;
import android.view.View;
import java.util.Objects;

public final class H implements OnReceiveContentListener {

    /* renamed from: a  reason: collision with root package name */
    public final C0166q f1629a;

    public H(C0166q qVar) {
        this.f1629a = qVar;
    }

    public final ContentInfo onReceiveContent(View view, ContentInfo contentInfo) {
        C0156g gVar = new C0156g(new j(contentInfo));
        C0156g a2 = ((u) this.f1629a).a(view, gVar);
        if (a2 == null) {
            return null;
        }
        if (a2 == gVar) {
            return contentInfo;
        }
        ContentInfo s2 = a2.f1671a.s();
        Objects.requireNonNull(s2);
        return C0152c.e(s2);
    }
}
