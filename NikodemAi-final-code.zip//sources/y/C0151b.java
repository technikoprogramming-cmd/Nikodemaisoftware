package y;

import android.os.Bundle;
import android.text.Spanned;
import android.text.style.ClickableSpan;
import android.util.SparseArray;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.lang.ref.WeakReference;
import java.util.Collections;
import java.util.List;
import ncs.oprogramowanie.nikodemai.aos.R;
import z.c;
import z.h;

/* renamed from: y.b  reason: case insensitive filesystem */
public class C0151b {

    /* renamed from: c  reason: collision with root package name */
    public static final View.AccessibilityDelegate f1659c = new View.AccessibilityDelegate();

    /* renamed from: a  reason: collision with root package name */
    public final View.AccessibilityDelegate f1660a;
    public final C0150a b;

    public C0151b() {
        this(f1659c);
    }

    public void a(View view, AccessibilityEvent accessibilityEvent) {
        this.f1660a.onInitializeAccessibilityEvent(view, accessibilityEvent);
    }

    public void b(View view, h hVar) {
        this.f1660a.onInitializeAccessibilityNodeInfo(view, hVar.f1698a);
    }

    public boolean c(View view, int i2, Bundle bundle) {
        WeakReference weakReference;
        ClickableSpan clickableSpan;
        ClickableSpan[] clickableSpanArr;
        List list = (List) view.getTag(R.id.tag_accessibility_actions);
        if (list == null) {
            list = Collections.EMPTY_LIST;
        }
        int i3 = 0;
        while (i3 < list.size() && ((AccessibilityNodeInfo.AccessibilityAction) ((c) list.get(i3)).f1697a).getId() != i2) {
            i3++;
        }
        boolean performAccessibilityAction = this.f1660a.performAccessibilityAction(view, i2, bundle);
        if (performAccessibilityAction || i2 != R.id.accessibility_action_clickable_span || bundle == null) {
            return performAccessibilityAction;
        }
        int i4 = bundle.getInt("ACCESSIBILITY_CLICKABLE_SPAN_ID", -1);
        SparseArray sparseArray = (SparseArray) view.getTag(R.id.tag_accessibility_clickable_spans);
        if (!(sparseArray == null || (weakReference = (WeakReference) sparseArray.get(i4)) == null || (clickableSpan = (ClickableSpan) weakReference.get()) == null)) {
            CharSequence text = view.createAccessibilityNodeInfo().getText();
            if (text instanceof Spanned) {
                clickableSpanArr = (ClickableSpan[]) ((Spanned) text).getSpans(0, text.length(), ClickableSpan.class);
            } else {
                clickableSpanArr = null;
            }
            int i5 = 0;
            while (clickableSpanArr != null && i5 < clickableSpanArr.length) {
                if (clickableSpan.equals(clickableSpanArr[i5])) {
                    clickableSpan.onClick(view);
                    return true;
                }
                i5++;
            }
        }
        return false;
    }

    public C0151b(View.AccessibilityDelegate accessibilityDelegate) {
        this.f1660a = accessibilityDelegate;
        this.b = new C0150a(this);
    }
}
