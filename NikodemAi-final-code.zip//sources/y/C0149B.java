package y;

import android.view.View;
import android.view.WindowInsets;

/* renamed from: y.B  reason: case insensitive filesystem */
public abstract class C0149B {
    public static f0 a(View view) {
        WindowInsets rootWindowInsets = view.getRootWindowInsets();
        if (rootWindowInsets == null) {
            return null;
        }
        f0 c2 = f0.c(rootWindowInsets, (View) null);
        d0 d0Var = c2.f1670a;
        d0Var.p(c2);
        d0Var.d(view.getRootView());
        return c2;
    }

    public static int b(View view) {
        return view.getScrollIndicators();
    }

    public static void c(View view, int i2) {
        view.setScrollIndicators(i2);
    }

    public static void d(View view, int i2, int i3) {
        view.setScrollIndicators(i2, i3);
    }
}
