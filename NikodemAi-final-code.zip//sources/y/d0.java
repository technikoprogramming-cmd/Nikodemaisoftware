package y;

import android.os.Build;
import android.view.View;
import java.util.Objects;
import r.c;

public class d0 {
    public static final f0 b;

    /* renamed from: a  reason: collision with root package name */
    public final f0 f1665a;

    static {
        X x2;
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 30) {
            x2 = new W();
        } else if (i2 >= 29) {
            x2 = new V();
        } else {
            x2 = new U();
        }
        b = x2.b().f1670a.a().f1670a.b().f1670a.c();
    }

    public d0(f0 f0Var) {
        this.f1665a = f0Var;
    }

    public f0 a() {
        return this.f1665a;
    }

    public f0 b() {
        return this.f1665a;
    }

    public f0 c() {
        return this.f1665a;
    }

    public C0159j e() {
        return null;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof d0)) {
            return false;
        }
        d0 d0Var = (d0) obj;
        if (n() != d0Var.n() || m() != d0Var.m() || !Objects.equals(j(), d0Var.j()) || !Objects.equals(h(), d0Var.h()) || !Objects.equals(e(), d0Var.e())) {
            return false;
        }
        return true;
    }

    public c f(int i2) {
        return c.f1585e;
    }

    public c g() {
        return j();
    }

    public c h() {
        return c.f1585e;
    }

    public int hashCode() {
        return Objects.hash(new Object[]{Boolean.valueOf(n()), Boolean.valueOf(m()), j(), h(), e()});
    }

    public c i() {
        return j();
    }

    public c j() {
        return c.f1585e;
    }

    public c k() {
        return j();
    }

    public f0 l(int i2, int i3, int i4, int i5) {
        return b;
    }

    public boolean m() {
        return false;
    }

    public boolean n() {
        return false;
    }

    public void d(View view) {
    }

    public void o(c[] cVarArr) {
    }

    public void p(f0 f0Var) {
    }

    public void q(c cVar) {
    }
}
