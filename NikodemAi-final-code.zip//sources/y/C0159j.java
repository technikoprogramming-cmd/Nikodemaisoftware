package y;

import android.view.DisplayCutout;
import java.util.Objects;

/* renamed from: y.j  reason: case insensitive filesystem */
public final class C0159j {

    /* renamed from: a  reason: collision with root package name */
    public final DisplayCutout f1678a;

    public C0159j(DisplayCutout displayCutout) {
        this.f1678a = displayCutout;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || C0159j.class != obj.getClass()) {
            return false;
        }
        return Objects.equals(this.f1678a, ((C0159j) obj).f1678a);
    }

    public final int hashCode() {
        return this.f1678a.hashCode();
    }

    public final String toString() {
        return "DisplayCutoutCompat{" + this.f1678a + "}";
    }
}
