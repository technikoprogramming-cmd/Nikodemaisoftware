package y;

import android.view.View;
import android.view.ViewGroup;

/* renamed from: y.n  reason: case insensitive filesystem */
public interface C0163n {
    void a(View view, View view2, int i2, int i3);

    void c(ViewGroup viewGroup, int i2, int i3, int i4, int i5, int i6);

    void d(View view, int i2);

    void e(ViewGroup viewGroup, int i2, int i3, int[] iArr, int i4);

    boolean f(View view, View view2, int i2, int i3);
}
