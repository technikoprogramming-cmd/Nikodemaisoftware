package y;

import C.j;
import android.animation.ValueAnimator;
import android.view.View;
import e.L;

public final /* synthetic */ class P implements ValueAnimator.AnimatorUpdateListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ j f1638a;

    public /* synthetic */ P(j jVar, View view) {
        this.f1638a = jVar;
    }

    public final void onAnimationUpdate(ValueAnimator valueAnimator) {
        ((View) ((L) this.f1638a.b).f898r.getParent()).invalidate();
    }
}
