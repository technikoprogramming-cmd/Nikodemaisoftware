package y;

import android.view.View;

/* renamed from: y.o  reason: case insensitive filesystem */
public interface C0164o extends C0163n {
    void b(View view, int i2, int i3, int i4, int i5, int i6, int[] iArr);
}
