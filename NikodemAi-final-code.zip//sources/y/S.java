package y;

public interface S {
    void a();

    void b();

    void c();
}
