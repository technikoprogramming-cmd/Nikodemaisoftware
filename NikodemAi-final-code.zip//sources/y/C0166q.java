package y;

/* renamed from: y.q  reason: case insensitive filesystem */
public interface C0166q {
}
