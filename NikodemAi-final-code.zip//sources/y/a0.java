package y;

import android.view.DisplayCutout;
import android.view.View;
import android.view.WindowInsets;
import java.util.Objects;

public class a0 extends Z {
    public a0(f0 f0Var, WindowInsets windowInsets) {
        super(f0Var, windowInsets);
    }

    public f0 a() {
        return f0.c(this.f1653c.consumeDisplayCutout(), (View) null);
    }

    public C0159j e() {
        DisplayCutout i2 = this.f1653c.getDisplayCutout();
        if (i2 == null) {
            return null;
        }
        return new C0159j(i2);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof a0)) {
            return false;
        }
        a0 a0Var = (a0) obj;
        if (!Objects.equals(this.f1653c, a0Var.f1653c) || !Objects.equals(this.f1656g, a0Var.f1656g)) {
            return false;
        }
        return true;
    }

    public int hashCode() {
        return this.f1653c.hashCode();
    }
}
