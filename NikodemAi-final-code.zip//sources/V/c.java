package V;

import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import androidx.appcompat.widget.Toolbar;
import e.C0018e;
import g.C0026a;
import h.p;
import i.a1;

public final class c implements View.OnClickListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f244a;
    public final /* synthetic */ Object b;

    public /* synthetic */ c(int i2, Object obj) {
        this.f244a = i2;
        this.b = obj;
    }

    public final void onClick(View view) {
        p pVar;
        switch (this.f244a) {
            case 0:
                d dVar = (d) this.b;
                ((ViewGroup) dVar.f248e).removeView((View) dVar.f);
                return;
            case 1:
                C0018e eVar = (C0018e) this.b;
                Button button = eVar.f;
                eVar.f936v.obtainMessage(1, eVar.b).sendToTarget();
                return;
            case 2:
                ((C0026a) this.b).a();
                return;
            default:
                a1 a1Var = ((Toolbar) this.b).f468L;
                if (a1Var == null) {
                    pVar = null;
                } else {
                    pVar = a1Var.b;
                }
                if (pVar != null) {
                    pVar.collapseActionView();
                    return;
                }
                return;
        }
    }
}
