package V;

import C.j;
import G.a;
import android.app.Dialog;
import android.view.View;

public final class k implements View.OnClickListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ Dialog f276a;
    public final /* synthetic */ a b;

    public k(a aVar, Dialog dialog) {
        this.b = aVar;
        this.f276a = dialog;
    }

    public final void onClick(View view) {
        e eVar = (e) ((j) this.b.b).b;
        if (eVar != null) {
            eVar.a();
        }
        this.f276a.dismiss();
    }
}
