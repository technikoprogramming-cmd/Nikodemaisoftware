package V;

import android.graphics.Point;
import android.util.Base64;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageButton;
import java.util.List;
import ncs.oprogramowanie.nikodemai.aos.MainActivity;
import ncs.oprogramowanie.nikodemai.aos.R;

public final class d {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f245a = 1;
    public final Object b;

    /* renamed from: c  reason: collision with root package name */
    public Object f246c;

    /* renamed from: d  reason: collision with root package name */
    public Object f247d;

    /* renamed from: e  reason: collision with root package name */
    public Object f248e;
    public Object f;

    public d(MainActivity mainActivity) {
        this.b = mainActivity;
    }

    public void a(String str, String str2) {
        MainActivity mainActivity = (MainActivity) this.b;
        ((WindowManager) mainActivity.getSystemService("window")).getDefaultDisplay().getSize(new Point());
        this.f248e = (ViewGroup) mainActivity.findViewById(16908290);
        View inflate = View.inflate(mainActivity, R.layout.ad_banner, (ViewGroup) null);
        this.f = inflate;
        ((ViewGroup) this.f248e).addView(inflate);
        WebView webView = (WebView) ((ViewGroup) this.f248e).findViewById(R.id.activity_ad_webview);
        this.f247d = webView;
        webView.setWebChromeClient(new WebChromeClient());
        ((WebView) this.f247d).getSettings().setJavaScriptEnabled(true);
        ((WebView) this.f247d).setOnTouchListener(new a(this, str2));
        ((WebView) this.f247d).loadUrl(str);
        ((WebView) this.f247d).setWebViewClient(new WebViewClient());
        ImageButton imageButton = (ImageButton) ((ViewGroup) this.f248e).findViewById(R.id.button_close);
        imageButton.setOnClickListener(new c(0, this));
        imageButton.getBackground().setAlpha(64);
    }

    public String toString() {
        switch (this.f245a) {
            case 1:
                StringBuilder sb = new StringBuilder();
                sb.append("FontRequest {mProviderAuthority: " + ((String) this.b) + ", mProviderPackage: " + ((String) this.f246c) + ", mQuery: " + ((String) this.f247d) + ", mCertificates:");
                int i2 = 0;
                while (true) {
                    List list = (List) this.f248e;
                    if (i2 < list.size()) {
                        sb.append(" [");
                        List list2 = (List) list.get(i2);
                        for (int i3 = 0; i3 < list2.size(); i3++) {
                            sb.append(" \"");
                            sb.append(Base64.encodeToString((byte[]) list2.get(i3), 0));
                            sb.append("\"");
                        }
                        sb.append(" ]");
                        i2++;
                    } else {
                        sb.append("}mCertificatesArray: 0");
                        return sb.toString();
                    }
                }
            default:
                return super.toString();
        }
    }

    public d(String str, String str2, String str3, List list) {
        str.getClass();
        this.b = str;
        str2.getClass();
        this.f246c = str2;
        this.f247d = str3;
        list.getClass();
        this.f248e = list;
        this.f = str + "-" + str2 + "-" + str3;
    }
}
