package V;

import G.a;
import android.content.DialogInterface;

public final class i implements DialogInterface.OnShowListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ a f274a;

    public i(a aVar) {
        this.f274a = aVar;
    }

    public final void onShow(DialogInterface dialogInterface) {
        Object obj = this.f274a.b;
    }
}
