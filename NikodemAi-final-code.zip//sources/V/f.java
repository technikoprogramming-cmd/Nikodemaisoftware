package V;

import F.d;
import U.h;
import java.util.HashMap;
import java.util.Map;

public final class f extends h {

    /* renamed from: p  reason: collision with root package name */
    public final /* synthetic */ String f250p;

    /* renamed from: q  reason: collision with root package name */
    public final /* synthetic */ String f251q;

    /* renamed from: r  reason: collision with root package name */
    public final /* synthetic */ String f252r;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public f(String str, d dVar, d dVar2, String str2, String str3, String str4) {
        super(1, str, dVar, dVar2);
        this.f250p = str2;
        this.f251q = str3;
        this.f252r = str4;
    }

    public final Map e() {
        HashMap hashMap = new HashMap();
        hashMap.put("si", this.f250p);
        hashMap.put("ri", this.f251q);
        hashMap.put("ai", this.f252r);
        return hashMap;
    }
}
