package V;

import G.a;
import android.content.DialogInterface;

public final class j implements DialogInterface.OnDismissListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ a f275a;

    public j(a aVar) {
        this.f275a = aVar;
    }

    public final void onDismiss(DialogInterface dialogInterface) {
        e eVar = (e) ((C.j) this.f275a.b).b;
        if (eVar != null) {
            eVar.a();
        }
    }
}
