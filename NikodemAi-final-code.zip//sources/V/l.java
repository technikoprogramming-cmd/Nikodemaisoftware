package V;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.ImageView;
import java.net.URL;

public final class l extends AsyncTask {

    /* renamed from: a  reason: collision with root package name */
    public ImageView f277a;

    public final Object doInBackground(Object[] objArr) {
        try {
            return BitmapFactory.decodeStream(new URL(((String[]) objArr)[0]).openStream());
        } catch (Exception e2) {
            Log.e("Error", e2.getMessage());
            e2.printStackTrace();
            return null;
        }
    }

    public final void onPostExecute(Object obj) {
        this.f277a.setImageBitmap((Bitmap) obj);
    }
}
