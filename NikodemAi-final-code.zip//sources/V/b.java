package V;

import android.content.Intent;
import android.net.Uri;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public final class b extends WebViewClient {
    public final boolean shouldOverrideUrlLoading(WebView webView, String str) {
        new Intent("android.intent.action.VIEW", Uri.parse(str));
        webView.getContext().startActivity(new Intent("android.intent.action.VIEW", Uri.parse(str)));
        return true;
    }

    public final void onPageFinished(WebView webView, String str) {
    }
}
