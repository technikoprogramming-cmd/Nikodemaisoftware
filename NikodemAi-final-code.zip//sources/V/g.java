package V;

import F.d;
import T.h;
import T.n;
import android.os.Handler;
import ncs.oprogramowanie.nikodemai.aos.MainActivity;

public final class g {

    /* renamed from: a  reason: collision with root package name */
    public h f253a;
    public MainActivity b;

    /* renamed from: c  reason: collision with root package name */
    public int f254c;

    /* renamed from: d  reason: collision with root package name */
    public Handler f255d;

    /* renamed from: e  reason: collision with root package name */
    public boolean f256e;
    public int f;

    /* renamed from: g  reason: collision with root package name */
    public int f257g;

    /* renamed from: h  reason: collision with root package name */
    public String f258h;

    /* renamed from: i  reason: collision with root package name */
    public String f259i;

    /* renamed from: j  reason: collision with root package name */
    public String f260j;

    /* renamed from: k  reason: collision with root package name */
    public String f261k;

    /* renamed from: l  reason: collision with root package name */
    public String f262l;

    /* renamed from: m  reason: collision with root package name */
    public String f263m;

    /* renamed from: n  reason: collision with root package name */
    public String f264n;

    /* renamed from: o  reason: collision with root package name */
    public String f265o;

    /* renamed from: p  reason: collision with root package name */
    public String f266p;

    /* renamed from: q  reason: collision with root package name */
    public String f267q;

    /* renamed from: r  reason: collision with root package name */
    public String f268r;

    /* renamed from: s  reason: collision with root package name */
    public Boolean f269s;

    public final void a(String str, String str2, String str3) {
        if (!this.f269s.booleanValue()) {
            n C2 = D.g.C(this.b);
            C2.a(new f(this.f258h + "ads-click.json", new d(10), new d(11), str, str2, str3));
            this.f269s = Boolean.TRUE;
        }
    }
}
