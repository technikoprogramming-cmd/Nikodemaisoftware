package V;

import C.j;
import G.a;
import android.app.Dialog;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import ncs.oprogramowanie.nikodemai.aos.MainActivity;

public final class h implements View.OnClickListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f270a = 0;
    public final String b;

    /* renamed from: c  reason: collision with root package name */
    public final Object f271c;

    /* renamed from: d  reason: collision with root package name */
    public Object f272d;

    /* renamed from: e  reason: collision with root package name */
    public Object f273e;

    public h(a aVar, String str, String str2, Dialog dialog) {
        this.f273e = aVar;
        this.b = str;
        this.f271c = str2;
        this.f272d = dialog;
    }

    public final void onClick(View view) {
        String str;
        Method method;
        switch (this.f270a) {
            case 0:
                Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(this.b));
                a aVar = (a) this.f273e;
                ((MainActivity) aVar.f57a).startActivity(intent);
                e eVar = (e) ((j) aVar.b).b;
                if (eVar != null) {
                    g gVar = eVar.f249a;
                    String str2 = gVar.f266p;
                    gVar.getClass();
                    gVar.a(gVar.f266p, (String) this.f271c, gVar.f264n);
                }
                ((Dialog) this.f272d).dismiss();
                return;
            default:
                if (((Method) this.f272d) == null) {
                    View view2 = (View) this.f271c;
                    Context context = view2.getContext();
                    while (true) {
                        String str3 = this.b;
                        if (context != null) {
                            try {
                                if (!context.isRestricted() && (method = context.getClass().getMethod(str3, new Class[]{View.class})) != null) {
                                    this.f272d = method;
                                    this.f273e = context;
                                }
                            } catch (NoSuchMethodException unused) {
                            }
                            if (context instanceof ContextWrapper) {
                                context = ((ContextWrapper) context).getBaseContext();
                            } else {
                                context = null;
                            }
                        } else {
                            int id = view2.getId();
                            if (id == -1) {
                                str = "";
                            } else {
                                str = " with id '" + view2.getContext().getResources().getResourceEntryName(id) + "'";
                            }
                            throw new IllegalStateException("Could not find method " + str3 + "(View) in a parent or ancestor Context for android:onClick attribute defined on view " + view2.getClass() + str);
                        }
                    }
                }
                try {
                    ((Method) this.f272d).invoke((Context) this.f273e, new Object[]{view});
                    return;
                } catch (IllegalAccessException e2) {
                    throw new IllegalStateException("Could not execute non-public method for android:onClick", e2);
                } catch (InvocationTargetException e3) {
                    throw new IllegalStateException("Could not execute method for android:onClick", e3);
                }
        }
    }

    public h(View view, String str) {
        this.f271c = view;
        this.b = str;
    }
}
