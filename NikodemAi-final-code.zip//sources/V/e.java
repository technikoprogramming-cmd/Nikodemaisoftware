package V;

import T.h;
import T.o;
import android.widget.Toast;
import ncs.oprogramowanie.nikodemai.aos.MainActivity;
import org.json.JSONException;
import org.json.JSONObject;

public final class e implements o {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ g f249a;

    public /* synthetic */ e(g gVar) {
        this.f249a = gVar;
    }

    public void a() {
        this.f249a.b.finish();
    }

    public void u(String str) {
        try {
            JSONObject jSONObject = new JSONObject(str);
            boolean has = jSONObject.has("ad_display_running");
            g gVar = this.f249a;
            if (has) {
                if (!jSONObject.isNull("ad_display_running")) {
                    gVar.f259i = jSONObject.getString("ad_display_running");
                }
            }
            if (jSONObject.has("ad_display_exit") && !jSONObject.isNull("ad_display_exit")) {
                gVar.f260j = jSONObject.getString("ad_display_exit");
            }
            if (jSONObject.has("session_id") && !jSONObject.isNull("session_id")) {
                gVar.f266p = jSONObject.getString("session_id");
            }
            if (jSONObject.has("app_mode") && !jSONObject.isNull("app_mode")) {
                gVar.f267q = jSONObject.getString("app_mode");
            }
            String str2 = gVar.f267q;
            MainActivity mainActivity = gVar.b;
            if (str2.equals("finish")) {
                Toast.makeText(mainActivity, "The current version of this App is not available anymore. Please update to the new version or contact the administrator.", 1).show();
                mainActivity.finish();
            }
            if (jSONObject.has("next_call") && !jSONObject.isNull("next_call")) {
                gVar.f257g = Integer.parseInt(jSONObject.getString("next_call")) * 1000;
            }
            h hVar = new h(gVar, (gVar.f258h + "ads-running.json") + "?ai=" + gVar.f264n + "&ik=" + gVar.f265o + "&si=" + gVar.f266p);
            gVar.f253a = hVar;
            gVar.f255d.post(hVar);
        } catch (JSONException e2) {
            e2.printStackTrace();
        }
    }
}
