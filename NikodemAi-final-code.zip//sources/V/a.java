package V;

import C.j;
import T.h;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.WebView;

public final class a implements View.OnTouchListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ String f243a;
    public final /* synthetic */ d b;

    public a(d dVar, String str) {
        this.b = dVar;
        this.f243a = str;
    }

    public final boolean onTouch(View view, MotionEvent motionEvent) {
        ((WebView) view).getHitTestResult();
        j jVar = (j) this.b.f246c;
        if (jVar == null) {
            return false;
        }
        String str = this.f243a;
        j jVar2 = (j) jVar.b;
        g gVar = (g) ((h) jVar2.b).f186d;
        String str2 = gVar.f266p;
        gVar.getClass();
        g gVar2 = (g) ((h) jVar2.b).f186d;
        gVar2.a(gVar2.f266p, str, gVar2.f264n);
        return false;
    }
}
