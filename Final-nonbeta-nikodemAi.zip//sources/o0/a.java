package o0;

public final class a {

    /* renamed from: e  reason: collision with root package name */
    public static final a f1687e = new a();

    /* renamed from: a  reason: collision with root package name */
    public final int[] f1688a = new int[929];
    public final int[] b = new int[929];

    /* renamed from: c  reason: collision with root package name */
    public final G.a f1689c;

    /* renamed from: d  reason: collision with root package name */
    public final G.a f1690d;

    public a() {
        int i2 = 1;
        for (int i3 = 0; i3 < 929; i3++) {
            this.f1688a[i3] = i2;
            i2 = (i2 * 3) % 929;
        }
        for (int i4 = 0; i4 < 928; i4++) {
            this.b[this.f1688a[i4]] = i4;
        }
        this.f1689c = new G.a(this, new int[]{0});
        this.f1690d = new G.a(this, new int[]{1});
    }

    public final int a(int i2, int i3) {
        return (i2 + i3) % 929;
    }

    public final int b(int i2) {
        if (i2 != 0) {
            return this.f1688a[928 - this.b[i2]];
        }
        throw new ArithmeticException();
    }

    public final int c(int i2, int i3) {
        if (i2 == 0 || i3 == 0) {
            return 0;
        }
        int[] iArr = this.b;
        return this.f1688a[(iArr[i2] + iArr[i3]) % 928];
    }
}
