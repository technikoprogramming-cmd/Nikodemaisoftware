package z0;

public class a extends y0.a {
}
