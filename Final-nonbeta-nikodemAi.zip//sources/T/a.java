package T;

import S.n;
import Z.b;

public final class a {

    /* renamed from: a  reason: collision with root package name */
    public final b f272a;
    public final n[] b;

    /* renamed from: c  reason: collision with root package name */
    public final boolean f273c;

    /* renamed from: d  reason: collision with root package name */
    public final int f274d;

    /* renamed from: e  reason: collision with root package name */
    public final int f275e;

    public a(b bVar, n[] nVarArr, boolean z2, int i2, int i3) {
        this.f272a = bVar;
        this.b = nVarArr;
        this.f273c = z2;
        this.f274d = i2;
        this.f275e = i3;
    }
}
