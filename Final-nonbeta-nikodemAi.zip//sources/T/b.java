package T;

import S.j;
import S.n;

public final class b implements j {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f276a;

    public /* synthetic */ b(int i2) {
        this.f276a = i2;
    }

    public static int c(n nVar, n nVar2) {
        if (nVar == null || nVar2 == null) {
            return 0;
        }
        return (int) Math.abs(nVar.f271a - nVar2.f271a);
    }

    public static int d(n nVar, n nVar2) {
        if (nVar == null || nVar2 == null) {
            return Integer.MAX_VALUE;
        }
        return (int) Math.abs(nVar.f271a - nVar2.f271a);
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v0, resolved type: int} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r16v0, resolved type: n0.e} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r8v4, resolved type: char} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r16v1, resolved type: n0.e} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r8v5, resolved type: char} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v11, resolved type: int} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v3, resolved type: int} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r30v1, resolved type: char} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r10v11, resolved type: n0.e} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r18v0, resolved type: n0.e} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r18v1, resolved type: n0.e} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r14v2, resolved type: int} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r10v12, resolved type: n0.e} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r18v2, resolved type: n0.e} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r10v13, resolved type: n0.e} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v9, resolved type: G.a[]} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r20v0, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v24, resolved type: int} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v25, resolved type: int} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v40, resolved type: int} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r35v0, resolved type: char} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v3, resolved type: int[]} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r8v11, resolved type: G.a} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r10v15, resolved type: G.a} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r30v2, resolved type: char} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r8v13, resolved type: int} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r12v3, resolved type: G.a} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r9v6, resolved type: G.a} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r9v7, resolved type: G.a} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r13v4, resolved type: int} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r30v3, resolved type: char} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r10v16, resolved type: G.a} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r30v4, resolved type: char} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r30v5, resolved type: char} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r30v6, resolved type: char} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r15v6, resolved type: G.a} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r8v17, resolved type: G.a} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r8v19, resolved type: char} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r30v8, resolved type: char} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r8v35, resolved type: int} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r9v24, resolved type: int[]} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r16v2, resolved type: n0.e} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r16v3, resolved type: n0.e} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r13v8, resolved type: int} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r10v34, resolved type: byte[]} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r16v4, resolved type: n0.e} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r8v39, resolved type: char} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r14v14, resolved type: int} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r12v12, resolved type: int} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r30v18, resolved type: char} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r10v43, resolved type: G.a} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r13v26, resolved type: int} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r9v45, resolved type: G.a} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r13v31, resolved type: G.a} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r10v62, resolved type: G.a} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r9v63, resolved type: G.a} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r12v31, resolved type: java.lang.Object[]} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r42v9, resolved type: int} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v32, resolved type: int} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r35v1, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v34, resolved type: int} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r15v32, resolved type: char} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r15v33, resolved type: char} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r34v1, resolved type: int} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r35v2, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v13, resolved type: n0.a} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v36, resolved type: int} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v39, resolved type: int} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r8v45, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v20, resolved type: G.a} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v46, resolved type: int} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v47, resolved type: int} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r8v51, resolved type: G.a} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r8v54, resolved type: int} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r8v56, resolved type: int} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v54, resolved type: int} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v55, resolved type: int} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v56, resolved type: G.a} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v57, resolved type: int} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v58, resolved type: int} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v59, resolved type: int} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v60, resolved type: int} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v61, resolved type: int} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r35v3, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v27, resolved type: n0.a} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v29, resolved type: G.a} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r35v4, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r15v38, resolved type: char} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v74, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v75, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v76, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r20v11, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r20v12, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v77, resolved type: n0.f} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v78, resolved type: n0.f} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r18v7, resolved type: n0.f} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r13v32, resolved type: n0.e} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r10v72, resolved type: n0.e} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r10v74, resolved type: n0.e} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r42v15, resolved type: n0.f} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r10v76, resolved type: n0.a} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r13v33, resolved type: n0.e} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r42v16, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r10v77, resolved type: n0.a} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r42v17, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r42v18, resolved type: n0.f} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r42v19, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r13v37, resolved type: n0.e} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r42v21, resolved type: n0.f} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r16v5, resolved type: n0.e} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r16v6, resolved type: n0.e} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r18v9, resolved type: n0.e} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r18v10, resolved type: n0.f} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v32, resolved type: n0.a} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r18v11, resolved type: n0.e} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r18v12, resolved type: n0.e} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r42v22, resolved type: n0.f} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r42v23, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r42v24, resolved type: n0.f} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r10v90, resolved type: n0.a} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r10v91, resolved type: n0.a} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r10v92, resolved type: n0.a} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r10v93, resolved type: n0.a} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r10v94, resolved type: n0.a} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r42v25, resolved type: n0.f} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r42v26, resolved type: n0.f} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r42v27, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r42v28, resolved type: n0.f} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r42v29, resolved type: n0.f} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r18v13, resolved type: n0.f} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v93, resolved type: n0.f} */
    /* JADX WARNING: type inference failed for: r7v2, types: [U.a, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r6v5, types: [U.a, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r42v13 */
    /* JADX WARNING: type inference failed for: r42v20 */
    /* JADX WARNING: Code restructure failed: missing block: B:37:0x0170, code lost:
        if (r0 != r12.f) goto L_0x0172;
     */
    /* JADX WARNING: Failed to insert additional move for type inference */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Removed duplicated region for block: B:136:0x02da  */
    /* JADX WARNING: Removed duplicated region for block: B:137:0x02dc  */
    /* JADX WARNING: Removed duplicated region for block: B:142:0x02f7  */
    /* JADX WARNING: Removed duplicated region for block: B:386:0x075c  */
    /* JADX WARNING: Removed duplicated region for block: B:396:0x0779  */
    /* JADX WARNING: Removed duplicated region for block: B:402:0x078d A[LOOP:27: B:401:0x078b->B:402:0x078d, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:405:0x07aa  */
    /* JADX WARNING: Removed duplicated region for block: B:408:0x07b3  */
    /* JADX WARNING: Removed duplicated region for block: B:415:0x01df A[SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:42:0x017f  */
    /* JADX WARNING: Removed duplicated region for block: B:50:0x01b7  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final S.l a(G.a r42, java.util.EnumMap r43) {
        /*
            r41 = this;
            r1 = r43
            S.m r2 = S.m.f263c
            r4 = 0
            r5 = 2
            r6 = 1
            r7 = r41
            int r8 = r7.f276a
            switch(r8) {
                case 0: goto L_0x0726;
                default: goto L_0x000e;
            }
        L_0x000e:
            java.util.ArrayList r1 = new java.util.ArrayList
            r1.<init>()
            Z.b r8 = r42.k()
            java.util.ArrayList r9 = p0.a.a(r8)
            boolean r10 = r9.isEmpty()
            if (r10 == 0) goto L_0x0074
            Z.b r9 = new Z.b
            int[] r10 = r8.f304d
            java.lang.Object r10 = r10.clone()
            int[] r10 = (int[]) r10
            int r11 = r8.f302a
            int r12 = r8.b
            int r8 = r8.f303c
            r9.<init>(r11, r12, r8, r10)
            Z.a r8 = new Z.a
            r8.<init>(r11)
            Z.a r10 = new Z.a
            r10.<init>(r11)
            r11 = r4
        L_0x003f:
            int r12 = r9.b
            int r13 = r12 + 1
            int r13 = r13 / r5
            if (r11 >= r13) goto L_0x006b
            Z.a r8 = r9.d(r8, r11)
            int r12 = r12 - r6
            int r12 = r12 - r11
            Z.a r10 = r9.d(r10, r12)
            r8.e()
            r10.e()
            int[] r13 = r10.f301a
            int r14 = r9.f303c
            int r15 = r11 * r14
            r16 = 0
            int[] r3 = r9.f304d
            java.lang.System.arraycopy(r13, r4, r3, r15, r14)
            int[] r13 = r8.f301a
            int r12 = r12 * r14
            java.lang.System.arraycopy(r13, r4, r3, r12, r14)
            int r11 = r11 + r6
            goto L_0x003f
        L_0x006b:
            r16 = 0
            java.util.ArrayList r3 = p0.a.a(r9)
            r10 = r9
            r9 = r3
            goto L_0x0077
        L_0x0074:
            r16 = 0
            r10 = r8
        L_0x0077:
            int r3 = r9.size()
            r8 = r4
        L_0x007c:
            if (r8 >= r3) goto L_0x070b
            java.lang.Object r11 = r9.get(r8)
            int r8 = r8 + r6
            S.n[] r11 = (S.n[]) r11
            r25 = 4
            r12 = r11[r25]
            r26 = 5
            r13 = r11[r26]
            r27 = 6
            r14 = r11[r27]
            r28 = 7
            r15 = r11[r28]
            r29 = r4
            r4 = r11[r29]
            int r4 = d(r4, r12)
            r30 = r6
            r6 = r11[r27]
            r0 = r11[r5]
            int r0 = d(r6, r0)
            int r0 = r0 * 17
            int r0 = r0 / 18
            int r0 = java.lang.Math.min(r4, r0)
            r4 = r11[r30]
            r6 = r11[r26]
            int r4 = d(r4, r6)
            r6 = r11[r28]
            r32 = 3
            r33 = r5
            r5 = r11[r32]
            int r5 = d(r6, r5)
            int r5 = r5 * 17
            int r5 = r5 / 18
            int r4 = java.lang.Math.min(r4, r5)
            int r0 = java.lang.Math.min(r0, r4)
            r4 = r11[r29]
            r5 = r11[r25]
            int r4 = c(r4, r5)
            r5 = r11[r27]
            r6 = r11[r33]
            int r5 = c(r5, r6)
            int r5 = r5 * 17
            int r5 = r5 / 18
            int r4 = java.lang.Math.max(r4, r5)
            r5 = r11[r30]
            r6 = r11[r26]
            int r5 = c(r5, r6)
            r6 = r11[r28]
            r42 = r0
            r0 = r11[r32]
            int r0 = c(r6, r0)
            int r0 = r0 * 17
            int r0 = r0 / 18
            int r0 = java.lang.Math.max(r5, r0)
            int r0 = java.lang.Math.max(r4, r0)
            C.j r4 = n0.h.f1662a
            r17 = r10
            n0.c r10 = new n0.c
            r4 = r11
            r11 = r17
            r10.<init>(r11, r12, r13, r14, r15)
            r5 = r14
            r11 = r10
            r10 = r16
            r13 = r10
            r18 = r13
            r6 = r29
            r14 = r33
        L_0x011c:
            if (r6 >= r14) goto L_0x01e2
            if (r12 == 0) goto L_0x012d
            r13 = 1
            r14 = r42
            r15 = r0
            r10 = r17
            n0.f r0 = n0.h.d(r10, r11, r12, r13, r14, r15)
        L_0x012a:
            r19 = r12
            goto L_0x0132
        L_0x012d:
            r14 = r42
            r15 = r0
            r0 = r10
            goto L_0x012a
        L_0x0132:
            if (r5 == 0) goto L_0x013c
            r13 = 0
            r12 = r5
            r10 = r17
            n0.f r18 = n0.h.d(r10, r11, r12, r13, r14, r15)
        L_0x013c:
            if (r0 != 0) goto L_0x0148
            if (r18 != 0) goto L_0x0148
            r42 = r0
        L_0x0142:
            r43 = r3
            r13 = r16
            goto L_0x01b5
        L_0x0148:
            if (r0 == 0) goto L_0x0150
            n0.a r10 = r0.J()
            if (r10 != 0) goto L_0x0153
        L_0x0150:
            r42 = r0
            goto L_0x0175
        L_0x0153:
            if (r18 == 0) goto L_0x015b
            n0.a r12 = r18.J()
            if (r12 != 0) goto L_0x015e
        L_0x015b:
            r42 = r0
            goto L_0x017c
        L_0x015e:
            int r13 = r10.b
            r42 = r0
            int r0 = r12.b
            if (r13 == r0) goto L_0x017c
            int r0 = r10.f1642c
            int r13 = r12.f1642c
            if (r0 == r13) goto L_0x017c
            int r0 = r10.f
            int r12 = r12.f
            if (r0 == r12) goto L_0x017c
        L_0x0172:
            r10 = r16
            goto L_0x017c
        L_0x0175:
            if (r18 != 0) goto L_0x0178
            goto L_0x0172
        L_0x0178:
            n0.a r10 = r18.J()
        L_0x017c:
            if (r10 != 0) goto L_0x017f
            goto L_0x0142
        L_0x017f:
            n0.c r0 = n0.h.a(r42)
            n0.c r12 = n0.h.a(r18)
            if (r0 != 0) goto L_0x018d
            r43 = r3
            r0 = r12
            goto L_0x01af
        L_0x018d:
            if (r12 != 0) goto L_0x0192
            r43 = r3
            goto L_0x01af
        L_0x0192:
            n0.c r34 = new n0.c
            Z.b r13 = r0.f1646a
            r43 = r3
            S.n r3 = r0.b
            S.n r0 = r0.f1647c
            r37 = r0
            S.n r0 = r12.f1648d
            S.n r12 = r12.f1649e
            r38 = r0
            r36 = r3
            r39 = r12
            r35 = r13
            r34.<init>(r35, r36, r37, r38, r39)
            r0 = r34
        L_0x01af:
            n0.e r3 = new n0.e
            r3.<init>(r10, r0)
            r13 = r3
        L_0x01b5:
            if (r13 == 0) goto L_0x01df
            if (r6 != 0) goto L_0x01da
            java.lang.Object r0 = r13.f1659e
            n0.c r0 = (n0.c) r0
            if (r0 == 0) goto L_0x01da
            int r3 = r0.f1651h
            int r10 = r11.f1651h
            if (r3 < r10) goto L_0x01cb
            int r3 = r0.f1652i
            int r10 = r11.f1652i
            if (r3 <= r10) goto L_0x01da
        L_0x01cb:
            int r6 = r6 + 1
            r10 = r42
            r3 = r43
            r11 = r0
            r42 = r14
            r0 = r15
            r12 = r19
            r14 = 2
            goto L_0x011c
        L_0x01da:
            r13.f1659e = r11
            r10 = r42
            goto L_0x01e7
        L_0x01df:
            S.h r0 = S.h.f252c
            throw r0
        L_0x01e2:
            r14 = r42
            r15 = r0
            r43 = r3
        L_0x01e7:
            int r0 = r13.b
            int r0 = r0 + 1
            java.lang.Object r3 = r13.f1658d
            G.a[] r3 = (G.a[]) r3
            r3[r29] = r10
            r3[r0] = r18
            if (r10 == 0) goto L_0x01f8
            r20 = r30
            goto L_0x01fa
        L_0x01f8:
            r20 = r29
        L_0x01fa:
            r5 = r30
        L_0x01fc:
            int r6 = r13.b
            if (r5 > r0) goto L_0x0341
            if (r20 == 0) goto L_0x0204
            r10 = r5
            goto L_0x0206
        L_0x0204:
            int r10 = r0 - r5
        L_0x0206:
            r12 = r3[r10]
            if (r12 != 0) goto L_0x0334
            if (r10 == 0) goto L_0x0217
            if (r10 != r0) goto L_0x020f
            goto L_0x0217
        L_0x020f:
            G.a r12 = new G.a
            r12.<init>((n0.c) r11)
            r42 = r0
            goto L_0x0225
        L_0x0217:
            n0.f r12 = new n0.f
            r42 = r0
            if (r10 != 0) goto L_0x0220
            r0 = r30
            goto L_0x0222
        L_0x0220:
            r0 = r29
        L_0x0222:
            r12.<init>(r11, r0)
        L_0x0225:
            r3[r10] = r12
            int r0 = r11.f1651h
            r23 = r14
            r24 = r15
            r14 = -1
        L_0x022e:
            int r15 = r11.f1652i
            if (r0 > r15) goto L_0x032a
            if (r20 == 0) goto L_0x0239
            r15 = r30
        L_0x0236:
            r34 = r5
            goto L_0x023b
        L_0x0239:
            r15 = -1
            goto L_0x0236
        L_0x023b:
            int r5 = r10 - r15
            if (r5 < 0) goto L_0x0252
            int r7 = r6 + 1
            if (r5 > r7) goto L_0x0252
            r7 = r3[r5]
            r35 = r8
            java.lang.Object r8 = r7.f59c
            n0.a[] r8 = (n0.a[]) r8
            int r7 = r7.p(r0)
            r7 = r8[r7]
            goto L_0x0256
        L_0x0252:
            r35 = r8
            r7 = r16
        L_0x0256:
            if (r7 == 0) goto L_0x0263
            if (r20 == 0) goto L_0x0260
            int r5 = r7.f1642c
        L_0x025c:
            r22 = r0
            goto L_0x02d4
        L_0x0260:
            int r5 = r7.b
            goto L_0x025c
        L_0x0263:
            r7 = r3[r10]
            n0.a r7 = r7.m(r0)
            if (r7 == 0) goto L_0x0273
            if (r20 == 0) goto L_0x0270
            int r5 = r7.b
            goto L_0x025c
        L_0x0270:
            int r5 = r7.f1642c
            goto L_0x025c
        L_0x0273:
            if (r5 < 0) goto L_0x027f
            int r8 = r6 + 1
            if (r5 > r8) goto L_0x027f
            r5 = r3[r5]
            n0.a r7 = r5.m(r0)
        L_0x027f:
            if (r7 == 0) goto L_0x0289
            if (r20 == 0) goto L_0x0286
            int r5 = r7.f1642c
            goto L_0x025c
        L_0x0286:
            int r5 = r7.b
            goto L_0x025c
        L_0x0289:
            r5 = r10
            r7 = r29
        L_0x028c:
            int r5 = r5 - r15
            if (r5 < 0) goto L_0x02c3
            int r8 = r6 + 1
            if (r5 > r8) goto L_0x02c3
            r8 = r3[r5]
            java.lang.Object r8 = r8.f59c
            n0.a[] r8 = (n0.a[]) r8
            r22 = r0
            int r0 = r8.length
            r18 = r5
            r5 = r29
        L_0x02a0:
            if (r5 >= r0) goto L_0x02bc
            r19 = r0
            r0 = r8[r5]
            if (r0 == 0) goto L_0x02b7
            int r5 = r0.b
            int r0 = r0.f1642c
            if (r20 == 0) goto L_0x02b0
            r8 = r0
            goto L_0x02b1
        L_0x02b0:
            r8 = r5
        L_0x02b1:
            int r15 = r15 * r7
            int r0 = r0 - r5
            int r0 = r0 * r15
            int r5 = r0 + r8
            goto L_0x02d4
        L_0x02b7:
            int r5 = r5 + 1
            r0 = r19
            goto L_0x02a0
        L_0x02bc:
            int r7 = r7 + 1
            r5 = r18
            r0 = r22
            goto L_0x028c
        L_0x02c3:
            r22 = r0
            if (r20 == 0) goto L_0x02ce
            java.lang.Object r0 = r13.f1659e
            n0.c r0 = (n0.c) r0
            int r5 = r0.f
            goto L_0x02d4
        L_0x02ce:
            java.lang.Object r0 = r13.f1659e
            n0.c r0 = (n0.c) r0
            int r5 = r0.f1650g
        L_0x02d4:
            if (r5 < 0) goto L_0x02da
            int r0 = r11.f1650g
            if (r5 <= r0) goto L_0x02dc
        L_0x02da:
            r0 = -1
            goto L_0x02df
        L_0x02dc:
            r21 = r5
            goto L_0x02e3
        L_0x02df:
            if (r14 == r0) goto L_0x0317
            r21 = r14
        L_0x02e3:
            int r0 = r11.f
            int r5 = r11.f1650g
            r18 = r0
            r19 = r5
            n0.a r0 = n0.h.c(r17, r18, r19, r20, r21, r22, r23, r24)
            r5 = r22
            r7 = r23
            r15 = r24
            if (r0 == 0) goto L_0x031d
            java.lang.Object r8 = r12.f59c
            n0.a[] r8 = (n0.a[]) r8
            int r14 = r12.p(r5)
            r8[r14] = r0
            int r8 = r0.f1642c
            int r0 = r0.b
            int r14 = r8 - r0
            int r7 = java.lang.Math.min(r7, r14)
            int r8 = r8 - r0
            int r0 = java.lang.Math.max(r15, r8)
            r24 = r0
            r14 = r21
        L_0x0314:
            r23 = r7
            goto L_0x0320
        L_0x0317:
            r5 = r22
            r7 = r23
            r15 = r24
        L_0x031d:
            r24 = r15
            goto L_0x0314
        L_0x0320:
            int r0 = r5 + 1
            r7 = r41
            r5 = r34
            r8 = r35
            goto L_0x022e
        L_0x032a:
            r7 = r23
            r15 = r24
            r14 = r7
        L_0x032f:
            r34 = r5
            r35 = r8
            goto L_0x0337
        L_0x0334:
            r42 = r0
            goto L_0x032f
        L_0x0337:
            int r5 = r34 + 1
            r7 = r41
            r0 = r42
            r8 = r35
            goto L_0x01fc
        L_0x0341:
            r35 = r8
            java.lang.Object r0 = r13.f1657c
            n0.a r0 = (n0.a) r0
            r14 = 2
            int r5 = r6 + 2
            int[] r7 = new int[r14]
            r7[r30] = r5
            int r5 = r0.f
            r7[r29] = r5
            java.lang.Class<n0.b> r8 = n0.b.class
            java.lang.Object r7 = java.lang.reflect.Array.newInstance(r8, r7)
            n0.b[][] r7 = (n0.b[][]) r7
            r8 = r29
        L_0x035c:
            int r10 = r7.length
            if (r8 >= r10) goto L_0x0373
            r10 = r29
        L_0x0361:
            r11 = r7[r8]
            int r12 = r11.length
            if (r10 >= r12) goto L_0x0370
            n0.b r12 = new n0.b
            r12.<init>()
            r11[r10] = r12
            int r10 = r10 + 1
            goto L_0x0361
        L_0x0370:
            int r8 = r8 + 1
            goto L_0x035c
        L_0x0373:
            r8 = r3[r29]
            r13.a(r8)
            int r8 = r6 + 1
            r10 = r3[r8]
            r13.a(r10)
            r11 = 928(0x3a0, float:1.3E-42)
        L_0x0381:
            r12 = r3[r29]
            if (r12 == 0) goto L_0x0389
            r13 = r3[r8]
            if (r13 != 0) goto L_0x038c
        L_0x0389:
            r18 = r9
            goto L_0x03d5
        L_0x038c:
            r14 = r29
        L_0x038e:
            java.lang.Object r15 = r12.f59c
            n0.a[] r15 = (n0.a[]) r15
            int r10 = r15.length
            if (r14 >= r10) goto L_0x0389
            r10 = r15[r14]
            r18 = r9
            if (r10 == 0) goto L_0x03d0
            java.lang.Object r9 = r13.f59c
            n0.a[] r9 = (n0.a[]) r9
            r9 = r9[r14]
            if (r9 == 0) goto L_0x03d0
            int r10 = r10.f
            int r9 = r9.f
            if (r10 != r9) goto L_0x03d0
            r9 = r30
        L_0x03ab:
            if (r9 > r6) goto L_0x03d0
            r10 = r3[r9]
            java.lang.Object r10 = r10.f59c
            n0.a[] r10 = (n0.a[]) r10
            r10 = r10[r14]
            r19 = r9
            if (r10 == 0) goto L_0x03cd
            r9 = r15[r14]
            int r9 = r9.f
            r10.f = r9
            boolean r9 = r10.a(r9)
            if (r9 != 0) goto L_0x03cd
            r9 = r3[r19]
            java.lang.Object r9 = r9.f59c
            n0.a[] r9 = (n0.a[]) r9
            r9[r14] = r16
        L_0x03cd:
            int r9 = r19 + 1
            goto L_0x03ab
        L_0x03d0:
            int r14 = r14 + 1
            r9 = r18
            goto L_0x038e
        L_0x03d5:
            r9 = r3[r29]
            if (r9 != 0) goto L_0x03dc
            r12 = r29
            goto L_0x0432
        L_0x03dc:
            r10 = r29
            r12 = r10
        L_0x03df:
            java.lang.Object r13 = r9.f59c
            n0.a[] r13 = (n0.a[]) r13
            int r14 = r13.length
            if (r10 >= r14) goto L_0x0432
            r13 = r13[r10]
            if (r13 == 0) goto L_0x0429
            int r13 = r13.f
            r15 = r29
            r14 = r30
        L_0x03f0:
            if (r14 >= r8) goto L_0x0429
            r19 = r9
            r9 = 2
            if (r15 >= r9) goto L_0x042b
            r9 = r3[r14]
            java.lang.Object r9 = r9.f59c
            n0.a[] r9 = (n0.a[]) r9
            r9 = r9[r10]
            r20 = r10
            if (r9 == 0) goto L_0x0422
            int r10 = r9.f
            boolean r10 = r9.a(r10)
            if (r10 != 0) goto L_0x0418
            boolean r10 = r9.a(r13)
            if (r10 == 0) goto L_0x0416
            r9.f = r13
            r15 = r29
            goto L_0x0418
        L_0x0416:
            int r15 = r15 + 1
        L_0x0418:
            int r10 = r9.f
            boolean r9 = r9.a(r10)
            if (r9 != 0) goto L_0x0422
            int r12 = r12 + 1
        L_0x0422:
            int r14 = r14 + 1
            r9 = r19
            r10 = r20
            goto L_0x03f0
        L_0x0429:
            r19 = r9
        L_0x042b:
            r20 = r10
            int r10 = r20 + 1
            r9 = r19
            goto L_0x03df
        L_0x0432:
            r9 = r3[r8]
            if (r9 != 0) goto L_0x0439
            r13 = r29
            goto L_0x0494
        L_0x0439:
            r10 = r29
            r13 = r10
        L_0x043c:
            java.lang.Object r14 = r9.f59c
            n0.a[] r14 = (n0.a[]) r14
            int r15 = r14.length
            if (r10 >= r15) goto L_0x0494
            r14 = r14[r10]
            if (r14 == 0) goto L_0x048b
            int r14 = r14.f
            r15 = r8
            r19 = r9
            r9 = r29
        L_0x044e:
            r20 = r10
            if (r15 <= 0) goto L_0x048f
            r10 = 2
            if (r9 >= r10) goto L_0x048f
            r10 = r3[r15]
            java.lang.Object r10 = r10.f59c
            n0.a[] r10 = (n0.a[]) r10
            r10 = r10[r20]
            r21 = r9
            if (r10 == 0) goto L_0x0484
            int r9 = r10.f
            boolean r9 = r10.a(r9)
            if (r9 != 0) goto L_0x0478
            boolean r9 = r10.a(r14)
            if (r9 == 0) goto L_0x0474
            r10.f = r14
            r21 = r29
            goto L_0x0478
        L_0x0474:
            int r9 = r21 + 1
            r21 = r9
        L_0x0478:
            int r9 = r10.f
            boolean r9 = r10.a(r9)
            if (r9 != 0) goto L_0x0482
            int r13 = r13 + 1
        L_0x0482:
            r9 = r21
        L_0x0484:
            r31 = -1
            int r15 = r15 + -1
            r10 = r20
            goto L_0x044e
        L_0x048b:
            r19 = r9
            r20 = r10
        L_0x048f:
            int r10 = r20 + 1
            r9 = r19
            goto L_0x043c
        L_0x0494:
            int r12 = r12 + r13
            if (r12 != 0) goto L_0x049d
            r12 = r29
        L_0x0499:
            r20 = r8
            goto L_0x058b
        L_0x049d:
            r9 = r30
        L_0x049f:
            if (r9 >= r8) goto L_0x0499
            r10 = r3[r9]
            java.lang.Object r10 = r10.f59c
            n0.a[] r10 = (n0.a[]) r10
            r13 = r29
        L_0x04a9:
            int r14 = r10.length
            if (r13 >= r14) goto L_0x0581
            r14 = r10[r13]
            if (r14 == 0) goto L_0x0571
            int r15 = r14.f
            boolean r14 = r14.a(r15)
            if (r14 != 0) goto L_0x0571
            r14 = r10[r13]
            int r15 = r9 + -1
            r15 = r3[r15]
            java.lang.Object r15 = r15.f59c
            n0.a[] r15 = (n0.a[]) r15
            int r19 = r9 + 1
            r20 = r8
            r8 = r3[r19]
            if (r8 == 0) goto L_0x04d1
            java.lang.Object r8 = r8.f59c
            n0.a[] r8 = (n0.a[]) r8
            r19 = r8
            goto L_0x04d3
        L_0x04d1:
            r19 = r15
        L_0x04d3:
            r8 = 14
            r21 = r9
            n0.a[] r9 = new n0.a[r8]
            r22 = r15[r13]
            r33 = 2
            r9[r33] = r22
            r22 = r19[r13]
            r9[r32] = r22
            if (r13 <= 0) goto L_0x04f3
            int r22 = r13 + -1
            r23 = r10[r22]
            r9[r29] = r23
            r23 = r15[r22]
            r9[r25] = r23
            r22 = r19[r22]
            r9[r26] = r22
        L_0x04f3:
            r8 = r30
            if (r13 <= r8) goto L_0x050d
            r33 = 2
            int r8 = r13 + -2
            r23 = r10[r8]
            r24 = 8
            r9[r24] = r23
            r23 = 10
            r24 = r15[r8]
            r9[r23] = r24
            r23 = 11
            r8 = r19[r8]
            r9[r23] = r8
        L_0x050d:
            int r8 = r10.length
            r30 = 1
            int r8 = r8 + -1
            if (r13 >= r8) goto L_0x0522
            int r8 = r13 + 1
            r23 = r10[r8]
            r9[r30] = r23
            r23 = r15[r8]
            r9[r27] = r23
            r8 = r19[r8]
            r9[r28] = r8
        L_0x0522:
            int r8 = r10.length
            r33 = 2
            int r8 = r8 + -2
            if (r13 >= r8) goto L_0x053d
            int r8 = r13 + 2
            r23 = r10[r8]
            r24 = 9
            r9[r24] = r23
            r23 = 12
            r15 = r15[r8]
            r9[r23] = r15
            r15 = 13
            r8 = r19[r8]
            r9[r15] = r8
        L_0x053d:
            r15 = r29
        L_0x053f:
            r8 = 14
            if (r15 >= r8) goto L_0x056e
            r8 = r9[r15]
            if (r8 != 0) goto L_0x054e
            r19 = r9
        L_0x0549:
            r23 = r10
        L_0x054b:
            r30 = 1
            goto L_0x0567
        L_0x054e:
            r19 = r9
            int r9 = r8.f
            boolean r9 = r8.a(r9)
            if (r9 == 0) goto L_0x0549
            int r9 = r14.f1643d
            r23 = r10
            int r10 = r8.f1643d
            if (r10 != r9) goto L_0x054b
            int r8 = r8.f
            r14.f = r8
        L_0x0564:
            r30 = 1
            goto L_0x0577
        L_0x0567:
            int r15 = r15 + 1
            r9 = r19
            r10 = r23
            goto L_0x053f
        L_0x056e:
            r23 = r10
            goto L_0x0564
        L_0x0571:
            r20 = r8
            r21 = r9
            r23 = r10
        L_0x0577:
            int r13 = r13 + 1
            r8 = r20
            r9 = r21
            r10 = r23
            goto L_0x04a9
        L_0x0581:
            r20 = r8
            r21 = r9
            int r9 = r21 + 1
            r30 = 1
            goto L_0x049f
        L_0x058b:
            if (r12 <= 0) goto L_0x0599
            if (r12 < r11) goto L_0x0590
            goto L_0x0599
        L_0x0590:
            r11 = r12
            r9 = r18
            r8 = r20
            r30 = 1
            goto L_0x0381
        L_0x0599:
            int r8 = r3.length
            r9 = r29
            r10 = r9
        L_0x059d:
            if (r9 >= r8) goto L_0x05d8
            r11 = r3[r9]
            if (r11 == 0) goto L_0x05cd
            java.lang.Object r11 = r11.f59c
            n0.a[] r11 = (n0.a[]) r11
            int r12 = r11.length
            r13 = r29
        L_0x05aa:
            if (r13 >= r12) goto L_0x05cd
            r14 = r11[r13]
            if (r14 == 0) goto L_0x05c5
            int r15 = r14.f
            if (r15 < 0) goto L_0x05c5
            r19 = r3
            int r3 = r7.length
            if (r15 >= r3) goto L_0x05c2
            r3 = r7[r15]
            r3 = r3[r10]
            int r14 = r14.f1644e
            r3.b(r14)
        L_0x05c2:
            r30 = 1
            goto L_0x05c8
        L_0x05c5:
            r19 = r3
            goto L_0x05c2
        L_0x05c8:
            int r13 = r13 + 1
            r3 = r19
            goto L_0x05aa
        L_0x05cd:
            r19 = r3
            r30 = 1
            int r10 = r10 + 1
            int r9 = r9 + 1
            r3 = r19
            goto L_0x059d
        L_0x05d8:
            r30 = 1
            r3 = r7[r29]
            r3 = r3[r30]
            int[] r3 = r3.a()
            int r8 = r6 * r5
            int r0 = r0.f1642c
            r33 = 2
            int r9 = r33 << r0
            int r9 = r8 - r9
            int r10 = r3.length
            if (r10 != 0) goto L_0x0602
            if (r9 <= 0) goto L_0x05ff
            r3 = 928(0x3a0, float:1.3E-42)
            if (r9 > r3) goto L_0x05ff
            r3 = r7[r29]
            r30 = 1
            r3 = r3[r30]
            r3.b(r9)
            goto L_0x060f
        L_0x05ff:
            S.h r0 = S.h.f252c
            throw r0
        L_0x0602:
            r30 = 1
            r3 = r3[r29]
            if (r3 == r9) goto L_0x060f
            r3 = r7[r29]
            r3 = r3[r30]
            r3.b(r9)
        L_0x060f:
            java.util.ArrayList r3 = new java.util.ArrayList
            r3.<init>()
            int[] r8 = new int[r8]
            java.util.ArrayList r9 = new java.util.ArrayList
            r9.<init>()
            java.util.ArrayList r10 = new java.util.ArrayList
            r10.<init>()
            r11 = r29
        L_0x0622:
            if (r11 >= r5) goto L_0x0665
            r12 = r29
        L_0x0626:
            if (r12 >= r6) goto L_0x065e
            r13 = r7[r11]
            r30 = 1
            int r14 = r12 + 1
            r13 = r13[r14]
            int[] r13 = r13.a()
            int r15 = r11 * r6
            int r15 = r15 + r12
            int r12 = r13.length
            if (r12 != 0) goto L_0x0645
            java.lang.Integer r12 = java.lang.Integer.valueOf(r15)
            r3.add(r12)
            r42 = r3
            r3 = 1
            goto L_0x065a
        L_0x0645:
            int r12 = r13.length
            r42 = r3
            r3 = 1
            if (r12 != r3) goto L_0x0650
            r12 = r13[r29]
            r8[r15] = r12
            goto L_0x065a
        L_0x0650:
            java.lang.Integer r12 = java.lang.Integer.valueOf(r15)
            r10.add(r12)
            r9.add(r13)
        L_0x065a:
            r3 = r42
            r12 = r14
            goto L_0x0626
        L_0x065e:
            r42 = r3
            r3 = 1
            int r11 = r11 + r3
            r3 = r42
            goto L_0x0622
        L_0x0665:
            r42 = r3
            r3 = 1
            int r5 = r9.size()
            int[][] r6 = new int[r5][]
            r7 = r29
        L_0x0670:
            if (r7 >= r5) goto L_0x067c
            java.lang.Object r11 = r9.get(r7)
            int[] r11 = (int[]) r11
            r6[r7] = r11
            int r7 = r7 + r3
            goto L_0x0670
        L_0x067c:
            int[] r3 = m0.a.a(r42)
            int[] r5 = m0.a.a(r10)
            int r7 = r5.length
            int[] r9 = new int[r7]
            r10 = 100
            r31 = -1
        L_0x068b:
            int r11 = r10 + -1
            if (r10 <= 0) goto L_0x0706
            r10 = r29
        L_0x0691:
            if (r10 >= r7) goto L_0x06a2
            r12 = r5[r10]
            r13 = r6[r10]
            r14 = r9[r10]
            r13 = r13[r14]
            r8[r12] = r13
            r30 = 1
            int r10 = r10 + 1
            goto L_0x0691
        L_0x06a2:
            Z.e r0 = n0.h.b(r8, r0, r3)     // Catch:{ b -> 0x06d7 }
            S.l r3 = new S.l
            S.a r5 = S.a.f229k
            java.lang.String r6 = r0.b
            r10 = r16
            r3.<init>(r6, r10, r4, r5)
            java.lang.String r4 = r0.f313d
            r3.a(r2, r4)
            java.lang.Object r0 = r0.f314e
            m0.b r0 = (m0.b) r0
            if (r0 == 0) goto L_0x06c1
            S.m r4 = S.m.f267h
            r3.a(r4, r0)
        L_0x06c1:
            r1.add(r3)
            r7 = r41
            r3 = r43
            r16 = r10
            r10 = r17
            r9 = r18
            r4 = r29
            r5 = r33
            r8 = r35
            r6 = 1
            goto L_0x007c
        L_0x06d7:
            r10 = r16
            if (r7 == 0) goto L_0x0701
            r12 = r29
        L_0x06dd:
            if (r12 >= r7) goto L_0x06fd
            r13 = r9[r12]
            r14 = r6[r12]
            int r14 = r14.length
            r30 = 1
            int r14 = r14 + -1
            if (r13 >= r14) goto L_0x06ef
            int r13 = r13 + 1
            r9[r12] = r13
            goto L_0x06fd
        L_0x06ef:
            r9[r12] = r29
            int r13 = r7 + -1
            if (r12 == r13) goto L_0x06f8
            int r12 = r12 + 1
            goto L_0x06dd
        L_0x06f8:
            S.b r0 = S.b.a()
            throw r0
        L_0x06fd:
            r16 = r10
            r10 = r11
            goto L_0x068b
        L_0x0701:
            S.b r0 = S.b.a()
            throw r0
        L_0x0706:
            S.b r0 = S.b.a()
            throw r0
        L_0x070b:
            r29 = r4
            int r0 = r1.size()
            S.l[] r0 = new S.l[r0]
            java.lang.Object[] r0 = r1.toArray(r0)
            S.l[] r0 = (S.l[]) r0
            if (r0 == 0) goto L_0x0723
            int r1 = r0.length
            if (r1 == 0) goto L_0x0723
            r0 = r0[r29]
            if (r0 == 0) goto L_0x0723
            return r0
        L_0x0723:
            S.h r0 = S.h.f252c
            throw r0
        L_0x0726:
            r29 = r4
            r10 = 0
            V.a r3 = new V.a
            Z.b r0 = r42.k()
            r3.<init>(r0)
            T.a r0 = r3.a(r4)     // Catch:{ h -> 0x0754, d -> 0x074e }
            S.n[] r5 = r0.b     // Catch:{ h -> 0x0754, d -> 0x074e }
            U.a r6 = new U.a     // Catch:{ h -> 0x0748, d -> 0x0746 }
            r6.<init>()     // Catch:{ h -> 0x0748, d -> 0x0746 }
            Z.e r0 = r6.a(r0)     // Catch:{ h -> 0x0748, d -> 0x0746 }
            r6 = r10
            r10 = r0
            r0 = r5
            r5 = r6
            goto L_0x075a
        L_0x0746:
            r0 = move-exception
            goto L_0x0750
        L_0x0748:
            r0 = move-exception
            goto L_0x0756
        L_0x074a:
            r5 = r10
            goto L_0x0750
        L_0x074c:
            r5 = r10
            goto L_0x0756
        L_0x074e:
            r0 = move-exception
            goto L_0x074a
        L_0x0750:
            r6 = r0
            r0 = r5
            r5 = r10
            goto L_0x075a
        L_0x0754:
            r0 = move-exception
            goto L_0x074c
        L_0x0756:
            r6 = r5
            r5 = r0
            r0 = r6
            r6 = r10
        L_0x075a:
            if (r10 != 0) goto L_0x0779
            r8 = 1
            T.a r0 = r3.a(r8)     // Catch:{ h -> 0x0771, d -> 0x076f }
            S.n[] r3 = r0.b     // Catch:{ h -> 0x0771, d -> 0x076f }
            U.a r7 = new U.a     // Catch:{ h -> 0x0771, d -> 0x076f }
            r7.<init>()     // Catch:{ h -> 0x0771, d -> 0x076f }
            Z.e r10 = r7.a(r0)     // Catch:{ h -> 0x0771, d -> 0x076f }
            r0 = r10
            r10 = r3
            goto L_0x077e
        L_0x076f:
            r0 = move-exception
            goto L_0x0772
        L_0x0771:
            r0 = move-exception
        L_0x0772:
            if (r5 != 0) goto L_0x0778
            if (r6 == 0) goto L_0x0777
            throw r6
        L_0x0777:
            throw r0
        L_0x0778:
            throw r5
        L_0x0779:
            r40 = r10
            r10 = r0
            r0 = r40
        L_0x077e:
            if (r1 == 0) goto L_0x0797
            S.c r3 = S.c.NEED_RESULT_POINT_CALLBACK
            java.lang.Object r1 = r1.get(r3)
            S.o r1 = (S.o) r1
            if (r1 == 0) goto L_0x0797
            int r3 = r10.length
        L_0x078b:
            if (r4 >= r3) goto L_0x0797
            r5 = r10[r4]
            r1.a(r5)
            r30 = 1
            int r4 = r4 + 1
            goto L_0x078b
        L_0x0797:
            S.l r7 = new S.l
            S.a r11 = S.a.f221a
            java.lang.System.currentTimeMillis()
            byte[] r9 = r0.f311a
            r12 = 0
            java.lang.String r8 = r0.b
            r7.<init>(r8, r9, r10, r11, r12)
            java.util.ArrayList r1 = r0.f312c
            if (r1 == 0) goto L_0x07af
            S.m r3 = S.m.b
            r7.a(r3, r1)
        L_0x07af:
            java.lang.String r0 = r0.f313d
            if (r0 == 0) goto L_0x07b6
            r7.a(r2, r0)
        L_0x07b6:
            return r7
        */
        throw new UnsupportedOperationException("Method not decompiled: T.b.a(G.a, java.util.EnumMap):S.l");
    }

    public final void b() {
        int i2 = this.f276a;
    }

    private final void e() {
    }

    private final void f() {
    }
}
