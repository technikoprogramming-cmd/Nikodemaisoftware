package i;

public final class O0 {

    /* renamed from: a  reason: collision with root package name */
    public int f1296a;
    public int b;

    /* renamed from: c  reason: collision with root package name */
    public int f1297c;

    /* renamed from: d  reason: collision with root package name */
    public int f1298d;

    /* renamed from: e  reason: collision with root package name */
    public int f1299e;
    public int f;

    /* renamed from: g  reason: collision with root package name */
    public boolean f1300g;

    /* renamed from: h  reason: collision with root package name */
    public boolean f1301h;

    public final void a(int i2, int i3) {
        this.f1297c = i2;
        this.f1298d = i3;
        this.f1301h = true;
        if (this.f1300g) {
            if (i3 != Integer.MIN_VALUE) {
                this.f1296a = i3;
            }
            if (i2 != Integer.MIN_VALUE) {
                this.b = i2;
                return;
            }
            return;
        }
        if (i2 != Integer.MIN_VALUE) {
            this.f1296a = i2;
        }
        if (i3 != Integer.MIN_VALUE) {
            this.b = i3;
        }
    }
}
