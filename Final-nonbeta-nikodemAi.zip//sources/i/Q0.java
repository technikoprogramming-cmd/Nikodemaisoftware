package i;

import g.C0036b;

public abstract class Q0 extends C0105x0 implements C0036b {
}
