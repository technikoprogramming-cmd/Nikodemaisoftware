package i;

import android.os.Handler;
import android.widget.AbsListView;

public final class D0 implements AbsListView.OnScrollListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ F0 f1237a;

    public D0(F0 f02) {
        this.f1237a = f02;
    }

    public final void onScrollStateChanged(AbsListView absListView, int i2) {
        if (i2 == 1) {
            F0 f02 = this.f1237a;
            if (f02.f1266y.getInputMethodMode() != 2 && f02.f1266y.getContentView() != null) {
                Handler handler = f02.f1262u;
                B0 b02 = f02.f1258q;
                handler.removeCallbacks(b02);
                b02.run();
            }
        }
    }

    public final void onScroll(AbsListView absListView, int i2, int i3, int i4) {
    }
}
