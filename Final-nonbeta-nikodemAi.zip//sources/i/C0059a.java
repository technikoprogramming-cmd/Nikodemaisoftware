package i;

import androidx.appcompat.widget.ActionBarContextView;
import y.Q;

/* renamed from: i.a  reason: case insensitive filesystem */
public final class C0059a implements Q {

    /* renamed from: a  reason: collision with root package name */
    public boolean f1339a = false;
    public int b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ ActionBarContextView f1340c;

    public C0059a(ActionBarContextView actionBarContextView) {
        this.f1340c = actionBarContextView;
    }

    public final void a() {
        if (!this.f1339a) {
            ActionBarContextView actionBarContextView = this.f1340c;
            actionBarContextView.f = null;
            C0059a.super.setVisibility(this.b);
        }
    }

    public final void b() {
        this.f1339a = true;
    }

    public final void c() {
        C0059a.super.setVisibility(0);
        this.f1339a = false;
    }
}
