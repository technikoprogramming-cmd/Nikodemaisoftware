package i;

import android.view.Window;

/* renamed from: i.k0  reason: case insensitive filesystem */
public interface C0080k0 {
    void setWindowCallback(Window.Callback callback);

    void setWindowTitle(CharSequence charSequence);
}
