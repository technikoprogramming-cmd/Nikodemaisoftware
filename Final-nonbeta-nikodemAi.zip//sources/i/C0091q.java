package i;

import C.h;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import d.C0012a;
import java.util.WeakHashMap;
import y.C0200z;
import y.J;

/* renamed from: i.q  reason: case insensitive filesystem */
public final class C0091q {

    /* renamed from: a  reason: collision with root package name */
    public final View f1436a;
    public final C0098u b;

    /* renamed from: c  reason: collision with root package name */
    public int f1437c = -1;

    /* renamed from: d  reason: collision with root package name */
    public T0 f1438d;

    /* renamed from: e  reason: collision with root package name */
    public T0 f1439e;
    public T0 f;

    public C0091q(View view) {
        this.f1436a = view;
        this.b = C0098u.a();
    }

    /* JADX WARNING: type inference failed for: r2v5, types: [i.T0, java.lang.Object] */
    public final void a() {
        View view = this.f1436a;
        Drawable background = view.getBackground();
        if (background != null) {
            if (this.f1438d != null) {
                if (this.f == null) {
                    this.f = new Object();
                }
                T0 t02 = this.f;
                t02.f1318a = null;
                t02.f1320d = false;
                t02.b = null;
                t02.f1319c = false;
                WeakHashMap weakHashMap = J.f1949a;
                ColorStateList g2 = C0200z.g(view);
                if (g2 != null) {
                    t02.f1320d = true;
                    t02.f1318a = g2;
                }
                PorterDuff.Mode h2 = C0200z.h(view);
                if (h2 != null) {
                    t02.f1319c = true;
                    t02.b = h2;
                }
                if (t02.f1320d || t02.f1319c) {
                    C0098u.d(background, t02, view.getDrawableState());
                    return;
                }
            }
            T0 t03 = this.f1439e;
            if (t03 != null) {
                C0098u.d(background, t03, view.getDrawableState());
                return;
            }
            T0 t04 = this.f1438d;
            if (t04 != null) {
                C0098u.d(background, t04, view.getDrawableState());
            }
        }
    }

    public final ColorStateList b() {
        T0 t02 = this.f1439e;
        if (t02 != null) {
            return t02.f1318a;
        }
        return null;
    }

    public final PorterDuff.Mode c() {
        T0 t02 = this.f1439e;
        if (t02 != null) {
            return t02.b;
        }
        return null;
    }

    public final void d(AttributeSet attributeSet, int i2) {
        ColorStateList f2;
        View view = this.f1436a;
        Context context = view.getContext();
        int[] iArr = C0012a.f823y;
        h t2 = h.t(context, attributeSet, iArr, i2);
        TypedArray typedArray = (TypedArray) t2.b;
        View view2 = this.f1436a;
        J.g(view2, view2.getContext(), iArr, attributeSet, (TypedArray) t2.b, i2);
        try {
            if (typedArray.hasValue(0)) {
                this.f1437c = typedArray.getResourceId(0, -1);
                C0098u uVar = this.b;
                Context context2 = view.getContext();
                int i3 = this.f1437c;
                synchronized (uVar) {
                    f2 = uVar.f1461a.f(context2, i3);
                }
                if (f2 != null) {
                    g(f2);
                }
            }
            if (typedArray.hasValue(1)) {
                C0200z.q(view, t2.m(1));
            }
            if (typedArray.hasValue(2)) {
                C0200z.r(view, C0084m0.b(typedArray.getInt(2, -1), (PorterDuff.Mode) null));
            }
            t2.x();
        } catch (Throwable th) {
            Throwable th2 = th;
            t2.x();
            throw th2;
        }
    }

    public final void e() {
        this.f1437c = -1;
        g((ColorStateList) null);
        a();
    }

    public final void f(int i2) {
        ColorStateList colorStateList;
        this.f1437c = i2;
        C0098u uVar = this.b;
        if (uVar != null) {
            Context context = this.f1436a.getContext();
            synchronized (uVar) {
                colorStateList = uVar.f1461a.f(context, i2);
            }
        } else {
            colorStateList = null;
        }
        g(colorStateList);
        a();
    }

    /* JADX WARNING: type inference failed for: r0v2, types: [i.T0, java.lang.Object] */
    public final void g(ColorStateList colorStateList) {
        if (colorStateList != null) {
            if (this.f1438d == null) {
                this.f1438d = new Object();
            }
            T0 t02 = this.f1438d;
            t02.f1318a = colorStateList;
            t02.f1320d = true;
        } else {
            this.f1438d = null;
        }
        a();
    }

    /* JADX WARNING: type inference failed for: r0v2, types: [i.T0, java.lang.Object] */
    public final void h(ColorStateList colorStateList) {
        if (this.f1439e == null) {
            this.f1439e = new Object();
        }
        T0 t02 = this.f1439e;
        t02.f1318a = colorStateList;
        t02.f1320d = true;
        a();
    }

    /* JADX WARNING: type inference failed for: r0v2, types: [i.T0, java.lang.Object] */
    public final void i(PorterDuff.Mode mode) {
        if (this.f1439e == null) {
            this.f1439e = new Object();
        }
        T0 t02 = this.f1439e;
        t02.b = mode;
        t02.f1319c = true;
        a();
    }
}
