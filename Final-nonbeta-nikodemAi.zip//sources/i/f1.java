package i;

public final /* synthetic */ class f1 implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f1367a;
    public final /* synthetic */ g1 b;

    public /* synthetic */ f1(g1 g1Var, int i2) {
        this.f1367a = i2;
        this.b = g1Var;
    }

    public final void run() {
        switch (this.f1367a) {
            case 0:
                this.b.c(false);
                return;
            default:
                this.b.a();
                return;
        }
    }
}
