package i;

import android.view.View;
import android.widget.AdapterView;

/* renamed from: i.y0  reason: case insensitive filesystem */
public final class C0107y0 implements AdapterView.OnItemSelectedListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ F0 f1491a;

    public C0107y0(F0 f02) {
        this.f1491a = f02;
    }

    public final void onItemSelected(AdapterView adapterView, View view, int i2, long j2) {
        C0095s0 s0Var;
        if (i2 != -1 && (s0Var = this.f1491a.f1245c) != null) {
            s0Var.setListSelectionHidden(false);
        }
    }

    public final void onNothingSelected(AdapterView adapterView) {
    }
}
