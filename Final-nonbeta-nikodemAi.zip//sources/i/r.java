package i;

import B0.a;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import ncs.nikodemai.ntabium.polskieoprogramowanie.R;

public final class r extends Button {

    /* renamed from: a  reason: collision with root package name */
    public final C0091q f1441a;
    public final Y b;

    /* renamed from: c  reason: collision with root package name */
    public C0104x f1442c;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public r(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, R.attr.buttonStyle);
        S0.a(context);
        R0.a(this, getContext());
        C0091q qVar = new C0091q(this);
        this.f1441a = qVar;
        qVar.d(attributeSet, R.attr.buttonStyle);
        Y y2 = new Y(this);
        this.b = y2;
        y2.f(attributeSet, R.attr.buttonStyle);
        y2.b();
        getEmojiTextViewHelper().a(attributeSet, R.attr.buttonStyle);
    }

    private C0104x getEmojiTextViewHelper() {
        if (this.f1442c == null) {
            this.f1442c = new C0104x(this);
        }
        return this.f1442c;
    }

    public final void drawableStateChanged() {
        super.drawableStateChanged();
        C0091q qVar = this.f1441a;
        if (qVar != null) {
            qVar.a();
        }
        Y y2 = this.b;
        if (y2 != null) {
            y2.b();
        }
    }

    public int getAutoSizeMaxTextSize() {
        if (l1.f1424c) {
            return super.getAutoSizeMaxTextSize();
        }
        Y y2 = this.b;
        if (y2 != null) {
            return Math.round(y2.f1331i.f1385e);
        }
        return -1;
    }

    public int getAutoSizeMinTextSize() {
        if (l1.f1424c) {
            return super.getAutoSizeMinTextSize();
        }
        Y y2 = this.b;
        if (y2 != null) {
            return Math.round(y2.f1331i.f1384d);
        }
        return -1;
    }

    public int getAutoSizeStepGranularity() {
        if (l1.f1424c) {
            return super.getAutoSizeStepGranularity();
        }
        Y y2 = this.b;
        if (y2 != null) {
            return Math.round(y2.f1331i.f1383c);
        }
        return -1;
    }

    public int[] getAutoSizeTextAvailableSizes() {
        if (l1.f1424c) {
            return super.getAutoSizeTextAvailableSizes();
        }
        Y y2 = this.b;
        if (y2 != null) {
            return y2.f1331i.f;
        }
        return new int[0];
    }

    public int getAutoSizeTextType() {
        if (!l1.f1424c) {
            Y y2 = this.b;
            if (y2 != null) {
                return y2.f1331i.f1382a;
            }
            return 0;
        } else if (super.getAutoSizeTextType() == 1) {
            return 1;
        } else {
            return 0;
        }
    }

    public ActionMode.Callback getCustomSelectionActionModeCallback() {
        return a.W(super.getCustomSelectionActionModeCallback());
    }

    public ColorStateList getSupportBackgroundTintList() {
        C0091q qVar = this.f1441a;
        if (qVar != null) {
            return qVar.b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0091q qVar = this.f1441a;
        if (qVar != null) {
            return qVar.c();
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.b.d();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.b.e();
    }

    public final void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName(Button.class.getName());
    }

    public final void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName(Button.class.getName());
    }

    public final void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        super.onLayout(z2, i2, i3, i4, i5);
        Y y2 = this.b;
        if (y2 != null && !l1.f1424c) {
            y2.f1331i.a();
        }
    }

    public final void onTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
        super.onTextChanged(charSequence, i2, i3, i4);
        Y y2 = this.b;
        if (y2 != null && !l1.f1424c) {
            C0074h0 h0Var = y2.f1331i;
            if (h0Var.f()) {
                h0Var.a();
            }
        }
    }

    public void setAllCaps(boolean z2) {
        super.setAllCaps(z2);
        getEmojiTextViewHelper().b(z2);
    }

    public final void setAutoSizeTextTypeUniformWithConfiguration(int i2, int i3, int i4, int i5) {
        if (l1.f1424c) {
            super.setAutoSizeTextTypeUniformWithConfiguration(i2, i3, i4, i5);
            return;
        }
        Y y2 = this.b;
        if (y2 != null) {
            y2.i(i2, i3, i4, i5);
        }
    }

    public final void setAutoSizeTextTypeUniformWithPresetSizes(int[] iArr, int i2) {
        if (l1.f1424c) {
            super.setAutoSizeTextTypeUniformWithPresetSizes(iArr, i2);
            return;
        }
        Y y2 = this.b;
        if (y2 != null) {
            y2.j(iArr, i2);
        }
    }

    public void setAutoSizeTextTypeWithDefaults(int i2) {
        if (l1.f1424c) {
            super.setAutoSizeTextTypeWithDefaults(i2);
            return;
        }
        Y y2 = this.b;
        if (y2 != null) {
            y2.k(i2);
        }
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0091q qVar = this.f1441a;
        if (qVar != null) {
            qVar.e();
        }
    }

    public void setBackgroundResource(int i2) {
        super.setBackgroundResource(i2);
        C0091q qVar = this.f1441a;
        if (qVar != null) {
            qVar.f(i2);
        }
    }

    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(a.Y(callback, this));
    }

    public void setEmojiCompatEnabled(boolean z2) {
        getEmojiTextViewHelper().c(z2);
    }

    public void setFilters(InputFilter[] inputFilterArr) {
        super.setFilters(((a) getEmojiTextViewHelper().b.b).t(inputFilterArr));
    }

    public void setSupportAllCaps(boolean z2) {
        Y y2 = this.b;
        if (y2 != null) {
            y2.f1325a.setAllCaps(z2);
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C0091q qVar = this.f1441a;
        if (qVar != null) {
            qVar.h(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C0091q qVar = this.f1441a;
        if (qVar != null) {
            qVar.i(mode);
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        Y y2 = this.b;
        y2.l(colorStateList);
        y2.b();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        Y y2 = this.b;
        y2.m(mode);
        y2.b();
    }

    public final void setTextAppearance(Context context, int i2) {
        super.setTextAppearance(context, i2);
        Y y2 = this.b;
        if (y2 != null) {
            y2.g(context, i2);
        }
    }

    public final void setTextSize(int i2, float f) {
        boolean z2 = l1.f1424c;
        if (z2) {
            super.setTextSize(i2, f);
            return;
        }
        Y y2 = this.b;
        if (y2 != null && !z2) {
            C0074h0 h0Var = y2.f1331i;
            if (!h0Var.f()) {
                h0Var.g(i2, f);
            }
        }
    }
}
