package i;

import B0.a;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.widget.ToggleButton;

/* renamed from: i.i0  reason: case insensitive filesystem */
public final class C0076i0 extends ToggleButton {

    /* renamed from: a  reason: collision with root package name */
    public final C0091q f1397a;
    public final Y b;

    /* renamed from: c  reason: collision with root package name */
    public C0104x f1398c;

    public C0076i0(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 16842827);
        R0.a(this, getContext());
        C0091q qVar = new C0091q(this);
        this.f1397a = qVar;
        qVar.d(attributeSet, 16842827);
        Y y2 = new Y(this);
        this.b = y2;
        y2.f(attributeSet, 16842827);
        getEmojiTextViewHelper().a(attributeSet, 16842827);
    }

    private C0104x getEmojiTextViewHelper() {
        if (this.f1398c == null) {
            this.f1398c = new C0104x(this);
        }
        return this.f1398c;
    }

    public final void drawableStateChanged() {
        super.drawableStateChanged();
        C0091q qVar = this.f1397a;
        if (qVar != null) {
            qVar.a();
        }
        Y y2 = this.b;
        if (y2 != null) {
            y2.b();
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        C0091q qVar = this.f1397a;
        if (qVar != null) {
            return qVar.b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0091q qVar = this.f1397a;
        if (qVar != null) {
            return qVar.c();
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.b.d();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.b.e();
    }

    public void setAllCaps(boolean z2) {
        super.setAllCaps(z2);
        getEmojiTextViewHelper().b(z2);
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0091q qVar = this.f1397a;
        if (qVar != null) {
            qVar.e();
        }
    }

    public void setBackgroundResource(int i2) {
        super.setBackgroundResource(i2);
        C0091q qVar = this.f1397a;
        if (qVar != null) {
            qVar.f(i2);
        }
    }

    public final void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        Y y2 = this.b;
        if (y2 != null) {
            y2.b();
        }
    }

    public final void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        Y y2 = this.b;
        if (y2 != null) {
            y2.b();
        }
    }

    public void setEmojiCompatEnabled(boolean z2) {
        getEmojiTextViewHelper().c(z2);
    }

    public void setFilters(InputFilter[] inputFilterArr) {
        super.setFilters(((a) getEmojiTextViewHelper().b.b).t(inputFilterArr));
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C0091q qVar = this.f1397a;
        if (qVar != null) {
            qVar.h(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C0091q qVar = this.f1397a;
        if (qVar != null) {
            qVar.i(mode);
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        Y y2 = this.b;
        y2.l(colorStateList);
        y2.b();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        Y y2 = this.b;
        y2.m(mode);
        y2.b();
    }
}
