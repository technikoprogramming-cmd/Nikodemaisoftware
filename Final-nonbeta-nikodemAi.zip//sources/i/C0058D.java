package i;

import C.h;
import C.j;
import G.a;
import G.c;
import G.f;
import G.i;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ClipDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.RoundRectShape;
import android.text.method.KeyListener;
import android.text.method.NumberKeyListener;
import android.util.AttributeSet;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.AbsSeekBar;
import android.widget.EditText;
import androidx.emoji2.text.k;
import d.C0012a;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import s.C0167d;
import s.C0168e;
import x.b;

/* renamed from: i.D  reason: case insensitive filesystem */
public class C0058D {

    /* renamed from: d  reason: collision with root package name */
    public static final int[] f1234d = {16843067, 16843068};

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f1235a = 2;
    public View b;

    /* renamed from: c  reason: collision with root package name */
    public Object f1236c;

    public /* synthetic */ C0058D() {
    }

    public KeyListener a(KeyListener keyListener) {
        if (keyListener instanceof NumberKeyListener) {
            return keyListener;
        }
        ((a) ((j) this.f1236c).b).getClass();
        if (keyListener instanceof f) {
            return keyListener;
        }
        if (keyListener == null) {
            return null;
        }
        if (keyListener instanceof NumberKeyListener) {
            return keyListener;
        }
        return new f(keyListener);
    }

    /* JADX INFO: finally extract failed */
    public void b(AttributeSet attributeSet, int i2) {
        switch (this.f1235a) {
            case 0:
                AbsSeekBar absSeekBar = (AbsSeekBar) this.b;
                h t2 = h.t(absSeekBar.getContext(), attributeSet, f1234d, i2);
                Drawable o2 = t2.o(0);
                if (o2 != null) {
                    if (o2 instanceof AnimationDrawable) {
                        AnimationDrawable animationDrawable = (AnimationDrawable) o2;
                        int numberOfFrames = animationDrawable.getNumberOfFrames();
                        AnimationDrawable animationDrawable2 = new AnimationDrawable();
                        animationDrawable2.setOneShot(animationDrawable.isOneShot());
                        for (int i3 = 0; i3 < numberOfFrames; i3++) {
                            Drawable e2 = e(animationDrawable.getFrame(i3), true);
                            e2.setLevel(10000);
                            animationDrawable2.addFrame(e2, animationDrawable.getDuration(i3));
                        }
                        animationDrawable2.setLevel(10000);
                        o2 = animationDrawable2;
                    }
                    absSeekBar.setIndeterminateDrawable(o2);
                }
                Drawable o3 = t2.o(1);
                if (o3 != null) {
                    absSeekBar.setProgressDrawable(e(o3, false));
                }
                t2.x();
                return;
            default:
                TypedArray obtainStyledAttributes = ((EditText) this.b).getContext().obtainStyledAttributes(attributeSet, C0012a.f807i, i2, 0);
                try {
                    boolean z2 = true;
                    if (obtainStyledAttributes.hasValue(14)) {
                        z2 = obtainStyledAttributes.getBoolean(14, true);
                    }
                    obtainStyledAttributes.recycle();
                    d(z2);
                    return;
                } catch (Throwable th) {
                    obtainStyledAttributes.recycle();
                    throw th;
                }
        }
    }

    public c c(InputConnection inputConnection, EditorInfo editorInfo) {
        j jVar = (j) this.f1236c;
        if (inputConnection == null) {
            jVar.getClass();
            inputConnection = null;
        } else {
            a aVar = (a) jVar.b;
            aVar.getClass();
            if (!(inputConnection instanceof c)) {
                inputConnection = new c((EditText) aVar.b, inputConnection, editorInfo);
            }
        }
        return (c) inputConnection;
    }

    public void d(boolean z2) {
        G.j jVar = (G.j) ((a) ((j) this.f1236c).b).f59c;
        if (jVar.f72c != z2) {
            if (jVar.b != null) {
                k a2 = k.a();
                i iVar = jVar.b;
                a2.getClass();
                b.d(iVar, "initCallback cannot be null");
                ReentrantReadWriteLock reentrantReadWriteLock = a2.f594a;
                reentrantReadWriteLock.writeLock().lock();
                try {
                    a2.b.remove(iVar);
                } finally {
                    reentrantReadWriteLock.writeLock().unlock();
                }
            }
            jVar.f72c = z2;
            if (z2) {
                G.j.a(jVar.f71a, k.a().b());
            }
        }
    }

    public Drawable e(Drawable drawable, boolean z2) {
        boolean z3;
        if (drawable instanceof C0167d) {
            ((C0168e) ((C0167d) drawable)).getClass();
        } else if (drawable instanceof LayerDrawable) {
            LayerDrawable layerDrawable = (LayerDrawable) drawable;
            int numberOfLayers = layerDrawable.getNumberOfLayers();
            Drawable[] drawableArr = new Drawable[numberOfLayers];
            for (int i2 = 0; i2 < numberOfLayers; i2++) {
                int id = layerDrawable.getId(i2);
                Drawable drawable2 = layerDrawable.getDrawable(i2);
                if (id == 16908301 || id == 16908303) {
                    z3 = true;
                } else {
                    z3 = false;
                }
                drawableArr[i2] = e(drawable2, z3);
            }
            LayerDrawable layerDrawable2 = new LayerDrawable(drawableArr);
            for (int i3 = 0; i3 < numberOfLayers; i3++) {
                layerDrawable2.setId(i3, layerDrawable.getId(i3));
                layerDrawable2.setLayerGravity(i3, layerDrawable.getLayerGravity(i3));
                layerDrawable2.setLayerWidth(i3, layerDrawable.getLayerWidth(i3));
                layerDrawable2.setLayerHeight(i3, layerDrawable.getLayerHeight(i3));
                layerDrawable2.setLayerInsetLeft(i3, layerDrawable.getLayerInsetLeft(i3));
                layerDrawable2.setLayerInsetRight(i3, layerDrawable.getLayerInsetRight(i3));
                layerDrawable2.setLayerInsetTop(i3, layerDrawable.getLayerInsetTop(i3));
                layerDrawable2.setLayerInsetBottom(i3, layerDrawable.getLayerInsetBottom(i3));
                layerDrawable2.setLayerInsetStart(i3, layerDrawable.getLayerInsetStart(i3));
                layerDrawable2.setLayerInsetEnd(i3, layerDrawable.getLayerInsetEnd(i3));
            }
            return layerDrawable2;
        } else if (drawable instanceof BitmapDrawable) {
            BitmapDrawable bitmapDrawable = (BitmapDrawable) drawable;
            Bitmap bitmap = bitmapDrawable.getBitmap();
            if (((Bitmap) this.f1236c) == null) {
                this.f1236c = bitmap;
            }
            ShapeDrawable shapeDrawable = new ShapeDrawable(new RoundRectShape(new float[]{5.0f, 5.0f, 5.0f, 5.0f, 5.0f, 5.0f, 5.0f, 5.0f}, (RectF) null, (float[]) null));
            shapeDrawable.getPaint().setShader(new BitmapShader(bitmap, Shader.TileMode.REPEAT, Shader.TileMode.CLAMP));
            shapeDrawable.getPaint().setColorFilter(bitmapDrawable.getPaint().getColorFilter());
            if (z2) {
                return new ClipDrawable(shapeDrawable, 3, 1);
            }
            return shapeDrawable;
        }
        return drawable;
    }

    public C0058D(AbsSeekBar absSeekBar) {
        this.b = absSeekBar;
    }

    public C0058D(EditText editText) {
        this.b = editText;
        this.f1236c = new j(editText);
    }
}
