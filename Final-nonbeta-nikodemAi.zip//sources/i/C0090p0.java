package i;

import android.widget.AbsListView;

/* renamed from: i.p0  reason: case insensitive filesystem */
public abstract class C0090p0 {
    public static boolean a(AbsListView absListView) {
        return absListView.isSelectedChildViewEnabled();
    }

    public static void b(AbsListView absListView, boolean z2) {
        absListView.setSelectedChildViewEnabled(z2);
    }
}
