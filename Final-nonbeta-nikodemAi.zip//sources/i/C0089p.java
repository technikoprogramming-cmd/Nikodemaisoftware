package i;

import B0.a;
import C.h;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.method.KeyListener;
import android.text.method.NumberKeyListener;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;
import ncs.nikodemai.ntabium.polskieoprogramowanie.R;

/* renamed from: i.p  reason: case insensitive filesystem */
public class C0089p extends AutoCompleteTextView {

    /* renamed from: d  reason: collision with root package name */
    public static final int[] f1433d = {16843126};

    /* renamed from: a  reason: collision with root package name */
    public final C0091q f1434a;
    public final Y b;

    /* renamed from: c  reason: collision with root package name */
    public final C0058D f1435c;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public C0089p(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, R.attr.autoCompleteTextViewStyle);
        S0.a(context);
        R0.a(this, getContext());
        h t2 = h.t(getContext(), attributeSet, f1433d, R.attr.autoCompleteTextViewStyle);
        if (((TypedArray) t2.b).hasValue(0)) {
            setDropDownBackgroundDrawable(t2.n(0));
        }
        t2.x();
        C0091q qVar = new C0091q(this);
        this.f1434a = qVar;
        qVar.d(attributeSet, R.attr.autoCompleteTextViewStyle);
        Y y2 = new Y(this);
        this.b = y2;
        y2.f(attributeSet, R.attr.autoCompleteTextViewStyle);
        y2.b();
        C0058D d2 = new C0058D((EditText) this);
        this.f1435c = d2;
        d2.b(attributeSet, R.attr.autoCompleteTextViewStyle);
        KeyListener keyListener = getKeyListener();
        if (!(keyListener instanceof NumberKeyListener)) {
            boolean isFocusable = super.isFocusable();
            boolean isClickable = super.isClickable();
            boolean isLongClickable = super.isLongClickable();
            int inputType = super.getInputType();
            KeyListener a2 = d2.a(keyListener);
            if (a2 != keyListener) {
                super.setKeyListener(a2);
                super.setRawInputType(inputType);
                super.setFocusable(isFocusable);
                super.setClickable(isClickable);
                super.setLongClickable(isLongClickable);
            }
        }
    }

    public final void drawableStateChanged() {
        super.drawableStateChanged();
        C0091q qVar = this.f1434a;
        if (qVar != null) {
            qVar.a();
        }
        Y y2 = this.b;
        if (y2 != null) {
            y2.b();
        }
    }

    public ActionMode.Callback getCustomSelectionActionModeCallback() {
        return a.W(super.getCustomSelectionActionModeCallback());
    }

    public ColorStateList getSupportBackgroundTintList() {
        C0091q qVar = this.f1434a;
        if (qVar != null) {
            return qVar.b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0091q qVar = this.f1434a;
        if (qVar != null) {
            return qVar.c();
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.b.d();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.b.e();
    }

    public InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        InputConnection onCreateInputConnection = super.onCreateInputConnection(editorInfo);
        a.D(editorInfo, onCreateInputConnection, this);
        return this.f1435c.c(onCreateInputConnection, editorInfo);
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0091q qVar = this.f1434a;
        if (qVar != null) {
            qVar.e();
        }
    }

    public void setBackgroundResource(int i2) {
        super.setBackgroundResource(i2);
        C0091q qVar = this.f1434a;
        if (qVar != null) {
            qVar.f(i2);
        }
    }

    public final void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        Y y2 = this.b;
        if (y2 != null) {
            y2.b();
        }
    }

    public final void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        Y y2 = this.b;
        if (y2 != null) {
            y2.b();
        }
    }

    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(a.Y(callback, this));
    }

    public void setDropDownBackgroundResource(int i2) {
        setDropDownBackgroundDrawable(a.r(getContext(), i2));
    }

    public void setEmojiCompatEnabled(boolean z2) {
        this.f1435c.d(z2);
    }

    public void setKeyListener(KeyListener keyListener) {
        super.setKeyListener(this.f1435c.a(keyListener));
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C0091q qVar = this.f1434a;
        if (qVar != null) {
            qVar.h(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C0091q qVar = this.f1434a;
        if (qVar != null) {
            qVar.i(mode);
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        Y y2 = this.b;
        y2.l(colorStateList);
        y2.b();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        Y y2 = this.b;
        y2.m(mode);
        y2.b();
    }

    public final void setTextAppearance(Context context, int i2) {
        super.setTextAppearance(context, i2);
        Y y2 = this.b;
        if (y2 != null) {
            y2.g(context, i2);
        }
    }
}
