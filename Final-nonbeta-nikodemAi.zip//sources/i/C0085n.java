package i;

/* renamed from: i.n  reason: case insensitive filesystem */
public final class C0085n extends C0103w0 {

    /* renamed from: a  reason: collision with root package name */
    public boolean f1426a;
    public int b;

    /* renamed from: c  reason: collision with root package name */
    public int f1427c;

    /* renamed from: d  reason: collision with root package name */
    public boolean f1428d;

    /* renamed from: e  reason: collision with root package name */
    public boolean f1429e;
    public boolean f;
}
