package i;

public interface Z {
    void d(int i2);

    void o(int i2, float f);

    void v(int i2);
}
