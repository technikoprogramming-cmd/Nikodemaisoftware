package i;

import android.view.View;
import h.l;
import h.n;

/* renamed from: i.j  reason: case insensitive filesystem */
public final class C0077j implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final C0073h f1400a;
    public final /* synthetic */ C0081l b;

    public C0077j(C0081l lVar, C0073h hVar) {
        this.b = lVar;
        this.f1400a = hVar;
    }

    public final void run() {
        l lVar;
        C0081l lVar2 = this.b;
        n nVar = lVar2.f1403c;
        if (!(nVar == null || (lVar = nVar.f1160e) == null)) {
            lVar.g(nVar);
        }
        View view = (View) lVar2.f1407h;
        if (!(view == null || view.getWindowToken() == null)) {
            C0073h hVar = this.f1400a;
            if (!hVar.b()) {
                if (hVar.f1220e != null) {
                    hVar.d(0, 0, false, false);
                }
            }
            lVar2.f1418s = hVar;
        }
        lVar2.f1420u = null;
    }
}
