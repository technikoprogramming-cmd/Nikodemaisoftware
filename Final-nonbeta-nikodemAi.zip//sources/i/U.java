package i;

import android.graphics.Typeface;
import android.widget.TextView;

public final class U implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ TextView f1321a;
    public final /* synthetic */ Typeface b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ int f1322c;

    public U(TextView textView, Typeface typeface, int i2) {
        this.f1321a = textView;
        this.b = typeface;
        this.f1322c = i2;
    }

    public final void run() {
        this.f1321a.setTypeface(this.b, this.f1322c);
    }
}
