package i;

import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewParent;

/* renamed from: i.u0  reason: case insensitive filesystem */
public final class C0099u0 implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f1462a;
    public final /* synthetic */ C0101v0 b;

    public /* synthetic */ C0099u0(C0101v0 v0Var, int i2) {
        this.f1462a = i2;
        this.b = v0Var;
    }

    public final void run() {
        switch (this.f1462a) {
            case 0:
                ViewParent parent = this.b.f1466d.getParent();
                if (parent != null) {
                    parent.requestDisallowInterceptTouchEvent(true);
                    return;
                }
                return;
            default:
                C0101v0 v0Var = this.b;
                v0Var.a();
                View view = v0Var.f1466d;
                if (view.isEnabled() && !view.isLongClickable() && v0Var.c()) {
                    view.getParent().requestDisallowInterceptTouchEvent(true);
                    long uptimeMillis = SystemClock.uptimeMillis();
                    MotionEvent obtain = MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, 0.0f, 0.0f, 0);
                    view.onTouchEvent(obtain);
                    obtain.recycle();
                    v0Var.f1468g = true;
                    return;
                }
                return;
        }
    }
}
