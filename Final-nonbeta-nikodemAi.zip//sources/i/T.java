package i;

import android.graphics.Typeface;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.widget.TextView;
import androidx.activity.c;
import java.lang.ref.WeakReference;

public final class T {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f1315a;
    public final /* synthetic */ int b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ WeakReference f1316c;

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ Y f1317d;

    public T(Y y2, int i2, int i3, WeakReference weakReference) {
        this.f1317d = y2;
        this.f1315a = i2;
        this.b = i3;
        this.f1316c = weakReference;
    }

    public final void a() {
        new Handler(Looper.getMainLooper()).post(new c(6, this));
    }

    public final void b(Typeface typeface) {
        int i2;
        boolean z2;
        if (Build.VERSION.SDK_INT >= 28 && (i2 = this.f1315a) != -1) {
            if ((this.b & 2) != 0) {
                z2 = true;
            } else {
                z2 = false;
            }
            typeface = X.a(typeface, i2, z2);
        }
        Y y2 = this.f1317d;
        if (y2.f1335m) {
            y2.f1334l = typeface;
            TextView textView = (TextView) this.f1316c.get();
            if (textView == null) {
                return;
            }
            if (textView.isAttachedToWindow()) {
                textView.post(new U(textView, typeface, y2.f1332j));
            } else {
                textView.setTypeface(typeface, y2.f1332j);
            }
        }
    }
}
