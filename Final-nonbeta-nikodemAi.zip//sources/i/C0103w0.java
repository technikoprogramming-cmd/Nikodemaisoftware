package i;

import android.widget.LinearLayout;

/* renamed from: i.w0  reason: case insensitive filesystem */
public class C0103w0 extends LinearLayout.LayoutParams {
}
