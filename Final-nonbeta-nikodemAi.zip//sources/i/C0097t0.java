package i;

/* renamed from: i.t0  reason: case insensitive filesystem */
public interface C0097t0 {
}
