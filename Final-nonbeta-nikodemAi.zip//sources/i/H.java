package i;

import C.h;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.AbsSeekBar;
import d.C0012a;
import ncs.nikodemai.ntabium.polskieoprogramowanie.R;
import s.C0164a;
import s.C0165b;
import y.J;

public final class H extends C0058D {

    /* renamed from: e  reason: collision with root package name */
    public final G f1268e;
    public Drawable f;

    /* renamed from: g  reason: collision with root package name */
    public ColorStateList f1269g = null;

    /* renamed from: h  reason: collision with root package name */
    public PorterDuff.Mode f1270h = null;

    /* renamed from: i  reason: collision with root package name */
    public boolean f1271i = false;

    /* renamed from: j  reason: collision with root package name */
    public boolean f1272j = false;

    public H(G g2) {
        super((AbsSeekBar) g2);
        this.f1268e = g2;
    }

    public final void b(AttributeSet attributeSet, int i2) {
        super.b(attributeSet, R.attr.seekBarStyle);
        G g2 = this.f1268e;
        Context context = g2.getContext();
        int[] iArr = C0012a.f805g;
        h t2 = h.t(context, attributeSet, iArr, R.attr.seekBarStyle);
        J.g(g2, g2.getContext(), iArr, attributeSet, (TypedArray) t2.b, R.attr.seekBarStyle);
        Drawable o2 = t2.o(0);
        if (o2 != null) {
            g2.setThumb(o2);
        }
        Drawable n2 = t2.n(1);
        Drawable drawable = this.f;
        if (drawable != null) {
            drawable.setCallback((Drawable.Callback) null);
        }
        this.f = n2;
        if (n2 != null) {
            n2.setCallback(g2);
            C0165b.b(n2, g2.getLayoutDirection());
            if (n2.isStateful()) {
                n2.setState(g2.getDrawableState());
            }
            f();
        }
        g2.invalidate();
        TypedArray typedArray = (TypedArray) t2.b;
        if (typedArray.hasValue(3)) {
            this.f1270h = C0084m0.b(typedArray.getInt(3, -1), this.f1270h);
            this.f1272j = true;
        }
        if (typedArray.hasValue(2)) {
            this.f1269g = t2.m(2);
            this.f1271i = true;
        }
        t2.x();
        f();
    }

    public final void f() {
        Drawable drawable = this.f;
        if (drawable == null) {
            return;
        }
        if (this.f1271i || this.f1272j) {
            Drawable mutate = drawable.mutate();
            this.f = mutate;
            if (this.f1271i) {
                C0164a.h(mutate, this.f1269g);
            }
            if (this.f1272j) {
                C0164a.i(this.f, this.f1270h);
            }
            if (this.f.isStateful()) {
                this.f.setState(this.f1268e.getDrawableState());
            }
        }
    }

    public final void g(Canvas canvas) {
        int i2;
        if (this.f != null) {
            G g2 = this.f1268e;
            int max = g2.getMax();
            int i3 = 1;
            if (max > 1) {
                int intrinsicWidth = this.f.getIntrinsicWidth();
                int intrinsicHeight = this.f.getIntrinsicHeight();
                if (intrinsicWidth >= 0) {
                    i2 = intrinsicWidth / 2;
                } else {
                    i2 = 1;
                }
                if (intrinsicHeight >= 0) {
                    i3 = intrinsicHeight / 2;
                }
                this.f.setBounds(-i2, -i3, i2, i3);
                float width = ((float) ((g2.getWidth() - g2.getPaddingLeft()) - g2.getPaddingRight())) / ((float) max);
                int save = canvas.save();
                canvas.translate((float) g2.getPaddingLeft(), (float) (g2.getHeight() / 2));
                for (int i4 = 0; i4 <= max; i4++) {
                    this.f.draw(canvas);
                    canvas.translate(width, 0.0f);
                }
                canvas.restoreToCount(save);
            }
        }
    }
}
