package i;

public interface a1 {
}
