package i;

public interface j1 {
}
