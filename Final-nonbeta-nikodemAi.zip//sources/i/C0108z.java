package i;

import B0.a;
import C.h;
import D.g;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.ImageView;
import d.C0012a;
import y.J;

/* renamed from: i.z  reason: case insensitive filesystem */
public final class C0108z {

    /* renamed from: a  reason: collision with root package name */
    public int f1492a = 0;
    public Object b;

    /* renamed from: c  reason: collision with root package name */
    public Object f1493c;

    public C0108z(ImageView imageView) {
        this.b = imageView;
    }

    public void a() {
        T0 t02;
        ImageView imageView = (ImageView) this.b;
        Drawable drawable = imageView.getDrawable();
        if (drawable != null) {
            C0084m0.a(drawable);
        }
        if (drawable != null && (t02 = (T0) this.f1493c) != null) {
            C0098u.d(drawable, t02, imageView.getDrawableState());
        }
    }

    public void b(AttributeSet attributeSet, int i2) {
        ImageView imageView = (ImageView) this.b;
        Context context = imageView.getContext();
        int[] iArr = C0012a.f;
        h t2 = h.t(context, attributeSet, iArr, i2);
        J.g(imageView, imageView.getContext(), iArr, attributeSet, (TypedArray) t2.b, i2);
        try {
            Drawable drawable = imageView.getDrawable();
            TypedArray typedArray = (TypedArray) t2.b;
            if (drawable == null) {
                int resourceId = typedArray.getResourceId(1, -1);
                if (!(resourceId == -1 || (drawable = a.r(imageView.getContext(), resourceId)) == null)) {
                    imageView.setImageDrawable(drawable);
                }
            }
            if (drawable != null) {
                C0084m0.a(drawable);
            }
            if (typedArray.hasValue(2)) {
                g.c(imageView, t2.m(2));
            }
            if (typedArray.hasValue(3)) {
                g.d(imageView, C0084m0.b(typedArray.getInt(3, -1), (PorterDuff.Mode) null));
            }
            t2.x();
        } catch (Throwable th) {
            Throwable th2 = th;
            t2.x();
            throw th2;
        }
    }
}
