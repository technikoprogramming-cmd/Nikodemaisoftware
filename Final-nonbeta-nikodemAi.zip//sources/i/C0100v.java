package i;

/* renamed from: i.v  reason: case insensitive filesystem */
public final class C0100v {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ C0102w f1463a;

    public C0100v(C0102w wVar) {
        this.f1463a = wVar;
    }
}
