package i;

public final class B0 implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f1232a;
    public final /* synthetic */ F0 b;

    public /* synthetic */ B0(F0 f02, int i2) {
        this.f1232a = i2;
        this.b = f02;
    }

    public final void run() {
        switch (this.f1232a) {
            case 0:
                C0095s0 s0Var = this.b.f1245c;
                if (s0Var != null) {
                    s0Var.setListSelectionHidden(true);
                    s0Var.requestLayout();
                    return;
                }
                return;
            default:
                F0 f02 = this.b;
                C0095s0 s0Var2 = f02.f1245c;
                if (s0Var2 != null && s0Var2.isAttachedToWindow() && f02.f1245c.getCount() > f02.f1245c.getChildCount() && f02.f1245c.getChildCount() <= f02.f1254m) {
                    f02.f1266y.setInputMethodMode(2);
                    f02.h();
                    return;
                }
                return;
        }
    }
}
