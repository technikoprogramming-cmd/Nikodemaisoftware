package i;

import B0.a;
import C.j;
import D.o;
import D.r;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.InputFilter;
import android.text.TextDirectionHeuristic;
import android.text.TextDirectionHeuristics;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.ActionMode;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.view.textclassifier.TextClassifier;
import android.widget.TextView;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import r.C0161f;
import w.C0173b;
import w.C0174c;

/* renamed from: i.c0  reason: case insensitive filesystem */
public class C0064c0 extends TextView {

    /* renamed from: a  reason: collision with root package name */
    public final C0091q f1347a;
    public final Y b;

    /* renamed from: c  reason: collision with root package name */
    public final C0058D f1348c;

    /* renamed from: d  reason: collision with root package name */
    public C0104x f1349d;

    /* renamed from: e  reason: collision with root package name */
    public boolean f1350e;
    public j f;

    /* renamed from: g  reason: collision with root package name */
    public Future f1351g;

    public C0064c0(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 16842884);
    }

    private C0104x getEmojiTextViewHelper() {
        if (this.f1349d == null) {
            this.f1349d = new C0104x(this);
        }
        return this.f1349d;
    }

    public final void drawableStateChanged() {
        super.drawableStateChanged();
        C0091q qVar = this.f1347a;
        if (qVar != null) {
            qVar.a();
        }
        Y y2 = this.b;
        if (y2 != null) {
            y2.b();
        }
    }

    public final void g() {
        Future future = this.f1351g;
        if (future != null) {
            try {
                this.f1351g = null;
                if (future.get() != null) {
                    throw new ClassCastException();
                } else if (Build.VERSION.SDK_INT >= 29) {
                    throw null;
                } else {
                    a.y(this);
                    throw null;
                }
            } catch (InterruptedException | ExecutionException unused) {
            }
        }
    }

    public int getAutoSizeMaxTextSize() {
        if (l1.f1424c) {
            return super.getAutoSizeMaxTextSize();
        }
        Y y2 = this.b;
        if (y2 != null) {
            return Math.round(y2.f1331i.f1385e);
        }
        return -1;
    }

    public int getAutoSizeMinTextSize() {
        if (l1.f1424c) {
            return super.getAutoSizeMinTextSize();
        }
        Y y2 = this.b;
        if (y2 != null) {
            return Math.round(y2.f1331i.f1384d);
        }
        return -1;
    }

    public int getAutoSizeStepGranularity() {
        if (l1.f1424c) {
            return super.getAutoSizeStepGranularity();
        }
        Y y2 = this.b;
        if (y2 != null) {
            return Math.round(y2.f1331i.f1383c);
        }
        return -1;
    }

    public int[] getAutoSizeTextAvailableSizes() {
        if (l1.f1424c) {
            return super.getAutoSizeTextAvailableSizes();
        }
        Y y2 = this.b;
        if (y2 != null) {
            return y2.f1331i.f;
        }
        return new int[0];
    }

    public int getAutoSizeTextType() {
        if (!l1.f1424c) {
            Y y2 = this.b;
            if (y2 != null) {
                return y2.f1331i.f1382a;
            }
            return 0;
        } else if (super.getAutoSizeTextType() == 1) {
            return 1;
        } else {
            return 0;
        }
    }

    public ActionMode.Callback getCustomSelectionActionModeCallback() {
        return a.W(super.getCustomSelectionActionModeCallback());
    }

    public int getFirstBaselineToTopHeight() {
        return getPaddingTop() - getPaint().getFontMetricsInt().top;
    }

    public int getLastBaselineToBottomHeight() {
        return getPaddingBottom() + getPaint().getFontMetricsInt().bottom;
    }

    public Z getSuperCaller() {
        if (this.f == null) {
            int i2 = Build.VERSION.SDK_INT;
            if (i2 >= 34) {
                this.f = new C0062b0(this);
            } else if (i2 >= 28) {
                this.f = new C0060a0(this);
            } else if (i2 >= 26) {
                this.f = new j(17, (Object) this);
            }
        }
        return this.f;
    }

    public ColorStateList getSupportBackgroundTintList() {
        C0091q qVar = this.f1347a;
        if (qVar != null) {
            return qVar.b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0091q qVar = this.f1347a;
        if (qVar != null) {
            return qVar.c();
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.b.d();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.b.e();
    }

    public CharSequence getText() {
        g();
        return super.getText();
    }

    public TextClassifier getTextClassifier() {
        C0058D d2;
        if (Build.VERSION.SDK_INT >= 28 || (d2 = this.f1348c) == null) {
            return super.getTextClassifier();
        }
        TextClassifier textClassifier = (TextClassifier) d2.f1236c;
        if (textClassifier == null) {
            return S.a((TextView) d2.b);
        }
        return textClassifier;
    }

    public C0173b getTextMetricsParamsCompat() {
        return a.y(this);
    }

    public final InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        InputConnection onCreateInputConnection = super.onCreateInputConnection(editorInfo);
        this.b.getClass();
        Y.h(editorInfo, onCreateInputConnection, this);
        a.D(editorInfo, onCreateInputConnection, this);
        return onCreateInputConnection;
    }

    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 30 && i2 < 33 && onCheckIsTextEditor()) {
            ((InputMethodManager) getContext().getSystemService("input_method")).isActive(this);
        }
    }

    public final void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        super.onLayout(z2, i2, i3, i4, i5);
        Y y2 = this.b;
        if (y2 != null && !l1.f1424c) {
            y2.f1331i.a();
        }
    }

    public void onMeasure(int i2, int i3) {
        g();
        super.onMeasure(i2, i3);
    }

    public final void onTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
        super.onTextChanged(charSequence, i2, i3, i4);
        Y y2 = this.b;
        if (y2 != null && !l1.f1424c) {
            C0074h0 h0Var = y2.f1331i;
            if (h0Var.f()) {
                h0Var.a();
            }
        }
    }

    public void setAllCaps(boolean z2) {
        super.setAllCaps(z2);
        getEmojiTextViewHelper().b(z2);
    }

    public final void setAutoSizeTextTypeUniformWithConfiguration(int i2, int i3, int i4, int i5) {
        if (l1.f1424c) {
            super.setAutoSizeTextTypeUniformWithConfiguration(i2, i3, i4, i5);
            return;
        }
        Y y2 = this.b;
        if (y2 != null) {
            y2.i(i2, i3, i4, i5);
        }
    }

    public final void setAutoSizeTextTypeUniformWithPresetSizes(int[] iArr, int i2) {
        if (l1.f1424c) {
            super.setAutoSizeTextTypeUniformWithPresetSizes(iArr, i2);
            return;
        }
        Y y2 = this.b;
        if (y2 != null) {
            y2.j(iArr, i2);
        }
    }

    public void setAutoSizeTextTypeWithDefaults(int i2) {
        if (l1.f1424c) {
            super.setAutoSizeTextTypeWithDefaults(i2);
            return;
        }
        Y y2 = this.b;
        if (y2 != null) {
            y2.k(i2);
        }
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0091q qVar = this.f1347a;
        if (qVar != null) {
            qVar.e();
        }
    }

    public void setBackgroundResource(int i2) {
        super.setBackgroundResource(i2);
        C0091q qVar = this.f1347a;
        if (qVar != null) {
            qVar.f(i2);
        }
    }

    public final void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        Y y2 = this.b;
        if (y2 != null) {
            y2.b();
        }
    }

    public final void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        Y y2 = this.b;
        if (y2 != null) {
            y2.b();
        }
    }

    public final void setCompoundDrawablesRelativeWithIntrinsicBounds(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelativeWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
        Y y2 = this.b;
        if (y2 != null) {
            y2.b();
        }
    }

    public final void setCompoundDrawablesWithIntrinsicBounds(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
        Y y2 = this.b;
        if (y2 != null) {
            y2.b();
        }
    }

    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(a.Y(callback, this));
    }

    public void setEmojiCompatEnabled(boolean z2) {
        getEmojiTextViewHelper().c(z2);
    }

    public void setFilters(InputFilter[] inputFilterArr) {
        super.setFilters(((a) getEmojiTextViewHelper().b.b).t(inputFilterArr));
    }

    public void setFirstBaselineToTopHeight(int i2) {
        if (Build.VERSION.SDK_INT >= 28) {
            getSuperCaller().d(i2);
        } else {
            a.R(this, i2);
        }
    }

    public void setLastBaselineToBottomHeight(int i2) {
        if (Build.VERSION.SDK_INT >= 28) {
            getSuperCaller().v(i2);
        } else {
            a.S(this, i2);
        }
    }

    public void setLineHeight(int i2) {
        a.T(this, i2);
    }

    public void setPrecomputedText(C0174c cVar) {
        if (Build.VERSION.SDK_INT >= 29) {
            throw null;
        }
        a.y(this);
        throw null;
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C0091q qVar = this.f1347a;
        if (qVar != null) {
            qVar.h(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C0091q qVar = this.f1347a;
        if (qVar != null) {
            qVar.i(mode);
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        Y y2 = this.b;
        y2.l(colorStateList);
        y2.b();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        Y y2 = this.b;
        y2.m(mode);
        y2.b();
    }

    public final void setTextAppearance(Context context, int i2) {
        super.setTextAppearance(context, i2);
        Y y2 = this.b;
        if (y2 != null) {
            y2.g(context, i2);
        }
    }

    public void setTextClassifier(TextClassifier textClassifier) {
        C0058D d2;
        if (Build.VERSION.SDK_INT >= 28 || (d2 = this.f1348c) == null) {
            super.setTextClassifier(textClassifier);
        } else {
            d2.f1236c = textClassifier;
        }
    }

    public void setTextFuture(Future<C0174c> future) {
        this.f1351g = future;
        if (future != null) {
            requestLayout();
        }
    }

    public void setTextMetricsParamsCompat(C0173b bVar) {
        TextDirectionHeuristic textDirectionHeuristic;
        TextDirectionHeuristic textDirectionHeuristic2 = bVar.b;
        TextDirectionHeuristic textDirectionHeuristic3 = TextDirectionHeuristics.FIRSTSTRONG_RTL;
        int i2 = 1;
        if (!(textDirectionHeuristic2 == textDirectionHeuristic3 || textDirectionHeuristic2 == (textDirectionHeuristic = TextDirectionHeuristics.FIRSTSTRONG_LTR))) {
            if (textDirectionHeuristic2 == TextDirectionHeuristics.ANYRTL_LTR) {
                i2 = 2;
            } else if (textDirectionHeuristic2 == TextDirectionHeuristics.LTR) {
                i2 = 3;
            } else if (textDirectionHeuristic2 == TextDirectionHeuristics.RTL) {
                i2 = 4;
            } else if (textDirectionHeuristic2 == TextDirectionHeuristics.LOCALE) {
                i2 = 5;
            } else if (textDirectionHeuristic2 == textDirectionHeuristic) {
                i2 = 6;
            } else if (textDirectionHeuristic2 == textDirectionHeuristic3) {
                i2 = 7;
            }
        }
        setTextDirection(i2);
        getPaint().set(bVar.f1927a);
        o.e(this, bVar.f1928c);
        o.h(this, bVar.f1929d);
    }

    public final void setTextSize(int i2, float f2) {
        boolean z2 = l1.f1424c;
        if (z2) {
            super.setTextSize(i2, f2);
            return;
        }
        Y y2 = this.b;
        if (y2 != null && !z2) {
            C0074h0 h0Var = y2.f1331i;
            if (!h0Var.f()) {
                h0Var.g(i2, f2);
            }
        }
    }

    public final void setTypeface(Typeface typeface, int i2) {
        Typeface typeface2;
        if (!this.f1350e) {
            if (typeface == null || i2 <= 0) {
                typeface2 = null;
            } else {
                Context context = getContext();
                a aVar = C0161f.f1734a;
                if (context != null) {
                    typeface2 = Typeface.create(typeface, i2);
                } else {
                    throw new IllegalArgumentException("Context cannot be null");
                }
            }
            this.f1350e = true;
            if (typeface2 != null) {
                typeface = typeface2;
            }
            try {
                super.setTypeface(typeface, i2);
            } finally {
                this.f1350e = false;
            }
        }
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public C0064c0(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        S0.a(context);
        this.f1350e = false;
        this.f = null;
        R0.a(this, getContext());
        C0091q qVar = new C0091q(this);
        this.f1347a = qVar;
        qVar.d(attributeSet, i2);
        Y y2 = new Y(this);
        this.b = y2;
        y2.f(attributeSet, i2);
        y2.b();
        C0058D d2 = new C0058D();
        d2.b = this;
        this.f1348c = d2;
        getEmojiTextViewHelper().a(attributeSet, i2);
    }

    public final void setLineHeight(int i2, float f2) {
        int i3 = Build.VERSION.SDK_INT;
        if (i3 >= 34) {
            getSuperCaller().o(i2, f2);
        } else if (i3 >= 34) {
            r.a(this, i2, f2);
        } else {
            a.T(this, Math.round(TypedValue.applyDimension(i2, f2, getResources().getDisplayMetrics())));
        }
    }

    public final void setCompoundDrawablesRelativeWithIntrinsicBounds(int i2, int i3, int i4, int i5) {
        Context context = getContext();
        Drawable drawable = null;
        Drawable r2 = i2 != 0 ? a.r(context, i2) : null;
        Drawable r3 = i3 != 0 ? a.r(context, i3) : null;
        Drawable r4 = i4 != 0 ? a.r(context, i4) : null;
        if (i5 != 0) {
            drawable = a.r(context, i5);
        }
        setCompoundDrawablesRelativeWithIntrinsicBounds(r2, r3, r4, drawable);
        Y y2 = this.b;
        if (y2 != null) {
            y2.b();
        }
    }

    public final void setCompoundDrawablesWithIntrinsicBounds(int i2, int i3, int i4, int i5) {
        Context context = getContext();
        Drawable drawable = null;
        Drawable r2 = i2 != 0 ? a.r(context, i2) : null;
        Drawable r3 = i3 != 0 ? a.r(context, i3) : null;
        Drawable r4 = i4 != 0 ? a.r(context, i4) : null;
        if (i5 != 0) {
            drawable = a.r(context, i5);
        }
        setCompoundDrawablesWithIntrinsicBounds(r2, r3, r4, drawable);
        Y y2 = this.b;
        if (y2 != null) {
            y2.b();
        }
    }
}
