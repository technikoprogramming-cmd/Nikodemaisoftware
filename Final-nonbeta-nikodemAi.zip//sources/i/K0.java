package i;

import C.j;
import android.content.Context;
import android.os.Build;
import android.util.Log;
import android.widget.PopupWindow;
import h.n;
import h.p;
import java.lang.reflect.Method;

public final class K0 extends F0 implements G0 {

    /* renamed from: C  reason: collision with root package name */
    public static final Method f1280C;

    /* renamed from: B  reason: collision with root package name */
    public j f1281B;

    static {
        try {
            if (Build.VERSION.SDK_INT <= 28) {
                f1280C = PopupWindow.class.getDeclaredMethod("setTouchModal", new Class[]{Boolean.TYPE});
            }
        } catch (NoSuchMethodException unused) {
            Log.i("MenuPopupWindow", "Could not find method setTouchModal() on PopupWindow. Oh well.");
        }
    }

    public final C0095s0 o(Context context, boolean z2) {
        J0 j02 = new J0(context, z2);
        j02.setHoverListener(this);
        return j02;
    }

    public final void q(n nVar, p pVar) {
        j jVar = this.f1281B;
        if (jVar != null) {
            jVar.q(nVar, pVar);
        }
    }

    public final void t(n nVar, p pVar) {
        j jVar = this.f1281B;
        if (jVar != null) {
            jVar.t(nVar, pVar);
        }
    }
}
