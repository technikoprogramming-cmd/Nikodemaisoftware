package i;

/* renamed from: i.l0  reason: case insensitive filesystem */
public interface C0082l0 {
}
