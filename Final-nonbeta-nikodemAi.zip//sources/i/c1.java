package i;

import android.content.Context;
import android.view.View;
import android.view.Window;
import h.C0048a;

public final class c1 implements View.OnClickListener {

    /* renamed from: a  reason: collision with root package name */
    public final C0048a f1352a;
    public final /* synthetic */ d1 b;

    /* JADX WARNING: type inference failed for: r0v0, types: [java.lang.Object, h.a] */
    public c1(d1 d1Var) {
        this.b = d1Var;
        Context context = d1Var.f1354a.getContext();
        CharSequence charSequence = d1Var.f1359h;
        ? obj = new Object();
        obj.f1104e = 4096;
        obj.f1105g = 4096;
        obj.f1110l = null;
        obj.f1111m = null;
        obj.f1112n = false;
        obj.f1113o = false;
        obj.f1114p = 16;
        obj.f1107i = context;
        obj.f1101a = charSequence;
        this.f1352a = obj;
    }

    public final void onClick(View view) {
        d1 d1Var = this.b;
        Window.Callback callback = d1Var.f1362k;
        if (callback != null && d1Var.f1363l) {
            callback.onMenuItemSelected(0, this.f1352a);
        }
    }
}
