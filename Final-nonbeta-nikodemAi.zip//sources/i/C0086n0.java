package i;

import android.view.View;

/* renamed from: i.n0  reason: case insensitive filesystem */
public abstract class C0086n0 {
    public static void a(View view, float f, float f2) {
        view.drawableHotspotChanged(f, f2);
    }
}
