package i;

/* renamed from: i.b0  reason: case insensitive filesystem */
public final class C0062b0 extends C0060a0 {

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ C0064c0 f1343d;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public C0062b0(C0064c0 c0Var) {
        super(c0Var);
        this.f1343d = c0Var;
    }

    public final void o(int i2, float f) {
        C0062b0.super.setLineHeight(i2, f);
    }
}
