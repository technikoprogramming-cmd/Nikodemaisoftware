package i;

import android.database.DataSetObserver;

public final class C0 extends DataSetObserver {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ F0 f1233a;

    public C0(F0 f02) {
        this.f1233a = f02;
    }

    public final void onChanged() {
        F0 f02 = this.f1233a;
        if (f02.f1266y.isShowing()) {
            f02.h();
        }
    }

    public final void onInvalidated() {
        this.f1233a.dismiss();
    }
}
