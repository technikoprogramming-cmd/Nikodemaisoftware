package i;

import android.content.res.Resources;

public abstract class N0 extends Resources {
}
