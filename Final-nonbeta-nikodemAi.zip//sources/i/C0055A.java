package i;

import B0.a;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.util.AttributeSet;
import android.widget.ImageView;

/* renamed from: i.A  reason: case insensitive filesystem */
public class C0055A extends ImageView {

    /* renamed from: a  reason: collision with root package name */
    public final C0091q f1227a;
    public final C0108z b;

    /* renamed from: c  reason: collision with root package name */
    public boolean f1228c = false;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public C0055A(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        S0.a(context);
        R0.a(this, getContext());
        C0091q qVar = new C0091q(this);
        this.f1227a = qVar;
        qVar.d(attributeSet, i2);
        C0108z zVar = new C0108z(this);
        this.b = zVar;
        zVar.b(attributeSet, i2);
    }

    public final void drawableStateChanged() {
        super.drawableStateChanged();
        C0091q qVar = this.f1227a;
        if (qVar != null) {
            qVar.a();
        }
        C0108z zVar = this.b;
        if (zVar != null) {
            zVar.a();
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        C0091q qVar = this.f1227a;
        if (qVar != null) {
            return qVar.b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0091q qVar = this.f1227a;
        if (qVar != null) {
            return qVar.c();
        }
        return null;
    }

    public ColorStateList getSupportImageTintList() {
        T0 t02;
        C0108z zVar = this.b;
        if (zVar == null || (t02 = (T0) zVar.f1493c) == null) {
            return null;
        }
        return t02.f1318a;
    }

    public PorterDuff.Mode getSupportImageTintMode() {
        T0 t02;
        C0108z zVar = this.b;
        if (zVar == null || (t02 = (T0) zVar.f1493c) == null) {
            return null;
        }
        return t02.b;
    }

    public final boolean hasOverlappingRendering() {
        if ((((ImageView) this.b.b).getBackground() instanceof RippleDrawable) || !super.hasOverlappingRendering()) {
            return false;
        }
        return true;
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0091q qVar = this.f1227a;
        if (qVar != null) {
            qVar.e();
        }
    }

    public void setBackgroundResource(int i2) {
        super.setBackgroundResource(i2);
        C0091q qVar = this.f1227a;
        if (qVar != null) {
            qVar.f(i2);
        }
    }

    public void setImageBitmap(Bitmap bitmap) {
        super.setImageBitmap(bitmap);
        C0108z zVar = this.b;
        if (zVar != null) {
            zVar.a();
        }
    }

    public void setImageDrawable(Drawable drawable) {
        C0108z zVar = this.b;
        if (!(zVar == null || drawable == null || this.f1228c)) {
            zVar.f1492a = drawable.getLevel();
        }
        super.setImageDrawable(drawable);
        if (zVar != null) {
            zVar.a();
            if (!this.f1228c) {
                ImageView imageView = (ImageView) zVar.b;
                if (imageView.getDrawable() != null) {
                    imageView.getDrawable().setLevel(zVar.f1492a);
                }
            }
        }
    }

    public void setImageLevel(int i2) {
        super.setImageLevel(i2);
        this.f1228c = true;
    }

    public void setImageResource(int i2) {
        C0108z zVar = this.b;
        if (zVar != null) {
            ImageView imageView = (ImageView) zVar.b;
            if (i2 != 0) {
                Drawable r2 = a.r(imageView.getContext(), i2);
                if (r2 != null) {
                    C0084m0.a(r2);
                }
                imageView.setImageDrawable(r2);
            } else {
                imageView.setImageDrawable((Drawable) null);
            }
            zVar.a();
        }
    }

    public void setImageURI(Uri uri) {
        super.setImageURI(uri);
        C0108z zVar = this.b;
        if (zVar != null) {
            zVar.a();
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C0091q qVar = this.f1227a;
        if (qVar != null) {
            qVar.h(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C0091q qVar = this.f1227a;
        if (qVar != null) {
            qVar.i(mode);
        }
    }

    public void setSupportImageTintList(ColorStateList colorStateList) {
        C0108z zVar = this.b;
        if (zVar != null) {
            if (((T0) zVar.f1493c) == null) {
                zVar.f1493c = new Object();
            }
            T0 t02 = (T0) zVar.f1493c;
            t02.f1318a = colorStateList;
            t02.f1320d = true;
            zVar.a();
        }
    }

    public void setSupportImageTintMode(PorterDuff.Mode mode) {
        C0108z zVar = this.b;
        if (zVar != null) {
            if (((T0) zVar.f1493c) == null) {
                zVar.f1493c = new Object();
            }
            T0 t02 = (T0) zVar.f1493c;
            t02.b = mode;
            t02.f1319c = true;
            zVar.a();
        }
    }
}
