package i;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.SeekBar;
import ncs.nikodemai.ntabium.polskieoprogramowanie.R;

public final class G extends SeekBar {

    /* renamed from: a  reason: collision with root package name */
    public final H f1267a;

    public G(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, R.attr.seekBarStyle);
        R0.a(this, getContext());
        H h2 = new H(this);
        this.f1267a = h2;
        h2.b(attributeSet, R.attr.seekBarStyle);
    }

    public final void drawableStateChanged() {
        super.drawableStateChanged();
        H h2 = this.f1267a;
        Drawable drawable = h2.f;
        if (drawable != null && drawable.isStateful()) {
            G g2 = h2.f1268e;
            if (drawable.setState(g2.getDrawableState())) {
                g2.invalidateDrawable(drawable);
            }
        }
    }

    public final void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        Drawable drawable = this.f1267a.f;
        if (drawable != null) {
            drawable.jumpToCurrentState();
        }
    }

    public final synchronized void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        this.f1267a.g(canvas);
    }
}
