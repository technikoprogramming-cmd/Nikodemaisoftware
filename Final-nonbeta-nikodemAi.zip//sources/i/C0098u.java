package i;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.util.Log;
import f0.b;

/* renamed from: i.u  reason: case insensitive filesystem */
public final class C0098u {
    public static final PorterDuff.Mode b = PorterDuff.Mode.SRC_IN;

    /* renamed from: c  reason: collision with root package name */
    public static C0098u f1460c;

    /* renamed from: a  reason: collision with root package name */
    public M0 f1461a;

    public static synchronized C0098u a() {
        C0098u uVar;
        synchronized (C0098u.class) {
            try {
                if (f1460c == null) {
                    c();
                }
                uVar = f1460c;
            } catch (Throwable th) {
                while (true) {
                    throw th;
                }
            }
        }
        return uVar;
    }

    /* JADX WARNING: type inference failed for: r1v2, types: [i.u, java.lang.Object] */
    public static synchronized void c() {
        synchronized (C0098u.class) {
            if (f1460c == null) {
                ? obj = new Object();
                f1460c = obj;
                obj.f1461a = M0.b();
                M0 m02 = f1460c.f1461a;
                b bVar = new b();
                synchronized (m02) {
                    m02.f1289e = bVar;
                }
            }
        }
    }

    public static void d(Drawable drawable, T0 t02, int[] iArr) {
        ColorStateList colorStateList;
        PorterDuff.Mode mode;
        PorterDuff.Mode mode2 = M0.f;
        int[] state = drawable.getState();
        if (drawable.mutate() == drawable) {
            if ((drawable instanceof LayerDrawable) && drawable.isStateful()) {
                drawable.setState(new int[0]);
                drawable.setState(state);
            }
            boolean z2 = t02.f1320d;
            if (z2 || t02.f1319c) {
                PorterDuffColorFilter porterDuffColorFilter = null;
                if (z2) {
                    colorStateList = t02.f1318a;
                } else {
                    colorStateList = null;
                }
                if (t02.f1319c) {
                    mode = t02.b;
                } else {
                    mode = M0.f;
                }
                if (!(colorStateList == null || mode == null)) {
                    porterDuffColorFilter = M0.e(colorStateList.getColorForState(iArr, 0), mode);
                }
                drawable.setColorFilter(porterDuffColorFilter);
                return;
            }
            drawable.clearColorFilter();
            return;
        }
        Log.d("ResourceManagerInternal", "Mutated drawable is not the same instance as the input.");
    }

    public final synchronized Drawable b(Context context, int i2) {
        return this.f1461a.c(context, i2);
    }
}
