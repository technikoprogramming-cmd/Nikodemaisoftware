package i;

import B0.a;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import h.C0049b;
import ncs.nikodemai.ntabium.polskieoprogramowanie.R;
import s.C0164a;

/* renamed from: i.k  reason: case insensitive filesystem */
public final class C0079k extends C0055A implements C0083m {

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ C0081l f1401d;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public C0079k(C0081l lVar, Context context) {
        super(context, (AttributeSet) null, R.attr.actionOverflowButtonStyle);
        this.f1401d = lVar;
        setClickable(true);
        setFocusable(true);
        setVisibility(0);
        setEnabled(true);
        a.U(this, getContentDescription());
        setOnTouchListener(new C0049b(this, this));
    }

    public final boolean a() {
        return false;
    }

    public final boolean b() {
        return false;
    }

    public final boolean performClick() {
        if (super.performClick()) {
            return true;
        }
        playSoundEffect(0);
        this.f1401d.l();
        return true;
    }

    public final boolean setFrame(int i2, int i3, int i4, int i5) {
        boolean frame = super.setFrame(i2, i3, i4, i5);
        Drawable drawable = getDrawable();
        Drawable background = getBackground();
        if (!(drawable == null || background == null)) {
            int width = getWidth();
            int height = getHeight();
            int max = Math.max(width, height) / 2;
            int paddingLeft = (width + (getPaddingLeft() - getPaddingRight())) / 2;
            int paddingTop = (height + (getPaddingTop() - getPaddingBottom())) / 2;
            C0164a.f(background, paddingLeft - max, paddingTop - max, paddingLeft + max, paddingTop + max);
        }
        return frame;
    }
}
