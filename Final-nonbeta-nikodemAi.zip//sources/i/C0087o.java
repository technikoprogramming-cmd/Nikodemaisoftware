package i;

/* renamed from: i.o  reason: case insensitive filesystem */
public interface C0087o {
}
