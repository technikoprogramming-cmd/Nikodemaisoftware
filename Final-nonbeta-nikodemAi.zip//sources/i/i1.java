package i;

public abstract class i1 extends N0 {

    /* renamed from: a  reason: collision with root package name */
    public static final /* synthetic */ int f1399a = 0;
}
