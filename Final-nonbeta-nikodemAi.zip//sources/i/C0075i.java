package i;

import h.C0050c;

/* renamed from: i.i  reason: case insensitive filesystem */
public final class C0075i extends C0050c {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ C0081l f1396a;

    public C0075i(C0081l lVar) {
        this.f1396a = lVar;
    }
}
