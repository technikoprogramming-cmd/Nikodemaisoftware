package i;

import android.view.View;
import android.widget.AdapterView;

public final class L implements AdapterView.OnItemClickListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ N f1282a;

    public L(N n2) {
        this.f1282a = n2;
    }

    public final void onItemClick(AdapterView adapterView, View view, int i2, long j2) {
        N n2 = this.f1282a;
        n2.f1294F.setSelection(i2);
        Q q2 = n2.f1294F;
        if (q2.getOnItemClickListener() != null) {
            q2.performItemClick(view, i2, n2.f1291C.getItemId(i2));
        }
        n2.dismiss();
    }
}
