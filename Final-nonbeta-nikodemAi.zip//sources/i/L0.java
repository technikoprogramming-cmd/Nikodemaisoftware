package i;

import l.C0132f;

public final class L0 extends C0132f {
}
