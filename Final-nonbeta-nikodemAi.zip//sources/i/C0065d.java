package i;

import androidx.appcompat.widget.ActionBarOverlayLayout;

/* renamed from: i.d  reason: case insensitive filesystem */
public final class C0065d implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f1353a;
    public final /* synthetic */ ActionBarOverlayLayout b;

    public /* synthetic */ C0065d(ActionBarOverlayLayout actionBarOverlayLayout, int i2) {
        this.f1353a = i2;
        this.b = actionBarOverlayLayout;
    }

    public final void run() {
        switch (this.f1353a) {
            case 0:
                ActionBarOverlayLayout actionBarOverlayLayout = this.b;
                actionBarOverlayLayout.h();
                actionBarOverlayLayout.f469w = actionBarOverlayLayout.f451d.animate().translationY(0.0f).setListener(actionBarOverlayLayout.f470x);
                return;
            default:
                ActionBarOverlayLayout actionBarOverlayLayout2 = this.b;
                actionBarOverlayLayout2.h();
                actionBarOverlayLayout2.f469w = actionBarOverlayLayout2.f451d.animate().translationY((float) (-actionBarOverlayLayout2.f451d.getHeight())).setListener(actionBarOverlayLayout2.f470x);
                return;
        }
    }
}
