package i;

import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.drawable.Drawable;
import s.C0164a;

/* renamed from: i.q0  reason: case insensitive filesystem */
public final class C0092q0 extends Drawable implements Drawable.Callback {

    /* renamed from: a  reason: collision with root package name */
    public Drawable f1440a;
    public boolean b;

    public final void a(Canvas canvas) {
        this.f1440a.draw(canvas);
    }

    public final void b(float f, float f2) {
        C0164a.e(this.f1440a, f, f2);
    }

    public final void c(int i2, int i3, int i4, int i5) {
        C0164a.f(this.f1440a, i2, i3, i4, i5);
    }

    public final boolean d(boolean z2, boolean z3) {
        if (super.setVisible(z2, z3) || this.f1440a.setVisible(z2, z3)) {
            return true;
        }
        return false;
    }

    public final void draw(Canvas canvas) {
        if (this.b) {
            a(canvas);
        }
    }

    public final int getChangingConfigurations() {
        return this.f1440a.getChangingConfigurations();
    }

    public final Drawable getCurrent() {
        return this.f1440a.getCurrent();
    }

    public final int getIntrinsicHeight() {
        return this.f1440a.getIntrinsicHeight();
    }

    public final int getIntrinsicWidth() {
        return this.f1440a.getIntrinsicWidth();
    }

    public final int getMinimumHeight() {
        return this.f1440a.getMinimumHeight();
    }

    public final int getMinimumWidth() {
        return this.f1440a.getMinimumWidth();
    }

    public final int getOpacity() {
        return this.f1440a.getOpacity();
    }

    public final boolean getPadding(Rect rect) {
        return this.f1440a.getPadding(rect);
    }

    public final int[] getState() {
        return this.f1440a.getState();
    }

    public final Region getTransparentRegion() {
        return this.f1440a.getTransparentRegion();
    }

    public final void invalidateDrawable(Drawable drawable) {
        invalidateSelf();
    }

    public final boolean isAutoMirrored() {
        return this.f1440a.isAutoMirrored();
    }

    public final boolean isStateful() {
        return this.f1440a.isStateful();
    }

    public final void jumpToCurrentState() {
        this.f1440a.jumpToCurrentState();
    }

    public final void onBoundsChange(Rect rect) {
        this.f1440a.setBounds(rect);
    }

    public final boolean onLevelChange(int i2) {
        return this.f1440a.setLevel(i2);
    }

    public final void scheduleDrawable(Drawable drawable, Runnable runnable, long j2) {
        scheduleSelf(runnable, j2);
    }

    public final void setAlpha(int i2) {
        this.f1440a.setAlpha(i2);
    }

    public final void setAutoMirrored(boolean z2) {
        this.f1440a.setAutoMirrored(z2);
    }

    public final void setChangingConfigurations(int i2) {
        this.f1440a.setChangingConfigurations(i2);
    }

    public final void setColorFilter(ColorFilter colorFilter) {
        this.f1440a.setColorFilter(colorFilter);
    }

    public final void setDither(boolean z2) {
        this.f1440a.setDither(z2);
    }

    public final void setFilterBitmap(boolean z2) {
        this.f1440a.setFilterBitmap(z2);
    }

    public final void setHotspot(float f, float f2) {
        if (this.b) {
            b(f, f2);
        }
    }

    public final void setHotspotBounds(int i2, int i3, int i4, int i5) {
        if (this.b) {
            c(i2, i3, i4, i5);
        }
    }

    public final boolean setState(int[] iArr) {
        if (this.b) {
            return this.f1440a.setState(iArr);
        }
        return false;
    }

    public final void setTint(int i2) {
        C0164a.g(this.f1440a, i2);
    }

    public final void setTintList(ColorStateList colorStateList) {
        C0164a.h(this.f1440a, colorStateList);
    }

    public final void setTintMode(PorterDuff.Mode mode) {
        C0164a.i(this.f1440a, mode);
    }

    public final boolean setVisible(boolean z2, boolean z3) {
        if (this.b) {
            return d(z2, z3);
        }
        return false;
    }

    public final void unscheduleDrawable(Drawable drawable, Runnable runnable) {
        unscheduleSelf(runnable);
    }
}
