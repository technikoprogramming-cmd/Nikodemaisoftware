package i;

import android.content.Context;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ViewTreeObserver;
import android.widget.ListAdapter;
import h.C0051d;
import ncs.nikodemai.ntabium.polskieoprogramowanie.R;

public final class N extends F0 implements P {

    /* renamed from: B  reason: collision with root package name */
    public CharSequence f1290B;

    /* renamed from: C  reason: collision with root package name */
    public K f1291C;

    /* renamed from: D  reason: collision with root package name */
    public final Rect f1292D = new Rect();

    /* renamed from: E  reason: collision with root package name */
    public int f1293E;

    /* renamed from: F  reason: collision with root package name */
    public final /* synthetic */ Q f1294F;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public N(Q q2, Context context, AttributeSet attributeSet) {
        super(context, attributeSet, R.attr.spinnerStyle);
        this.f1294F = q2;
        this.f1256o = q2;
        this.f1265x = true;
        this.f1266y.setFocusable(true);
        this.f1257p = new L(this);
    }

    public final CharSequence b() {
        return this.f1290B;
    }

    public final void e(int i2, int i3) {
        ViewTreeObserver viewTreeObserver;
        C0057C c2 = this.f1266y;
        boolean isShowing = c2.isShowing();
        r();
        this.f1266y.setInputMethodMode(2);
        h();
        C0095s0 s0Var = this.f1245c;
        s0Var.setChoiceMode(1);
        s0Var.setTextDirection(i2);
        s0Var.setTextAlignment(i3);
        Q q2 = this.f1294F;
        int selectedItemPosition = q2.getSelectedItemPosition();
        C0095s0 s0Var2 = this.f1245c;
        if (c2.isShowing() && s0Var2 != null) {
            s0Var2.setListSelectionHidden(false);
            s0Var2.setSelection(selectedItemPosition);
            if (s0Var2.getChoiceMode() != 0) {
                s0Var2.setItemChecked(selectedItemPosition, true);
            }
        }
        if (!isShowing && (viewTreeObserver = q2.getViewTreeObserver()) != null) {
            C0051d dVar = new C0051d(3, this);
            viewTreeObserver.addOnGlobalLayoutListener(dVar);
            this.f1266y.setOnDismissListener(new M(this, dVar));
        }
    }

    public final void g(CharSequence charSequence) {
        this.f1290B = charSequence;
    }

    public final void m(ListAdapter listAdapter) {
        super.m(listAdapter);
        this.f1291C = (K) listAdapter;
    }

    public final void n(int i2) {
        this.f1293E = i2;
    }

    public final void r() {
        int i2;
        int i3;
        C0057C c2 = this.f1266y;
        Drawable background = c2.getBackground();
        Q q2 = this.f1294F;
        if (background != null) {
            background.getPadding(q2.f1308h);
            boolean z2 = l1.f1423a;
            int layoutDirection = q2.getLayoutDirection();
            Rect rect = q2.f1308h;
            if (layoutDirection == 1) {
                i2 = rect.right;
            } else {
                i2 = -rect.left;
            }
        } else {
            Rect rect2 = q2.f1308h;
            rect2.right = 0;
            rect2.left = 0;
            i2 = 0;
        }
        int paddingLeft = q2.getPaddingLeft();
        int paddingRight = q2.getPaddingRight();
        int width = q2.getWidth();
        int i4 = q2.f1307g;
        if (i4 == -2) {
            int a2 = q2.a(this.f1291C, c2.getBackground());
            int i5 = q2.getContext().getResources().getDisplayMetrics().widthPixels;
            Rect rect3 = q2.f1308h;
            int i6 = (i5 - rect3.left) - rect3.right;
            if (a2 > i6) {
                a2 = i6;
            }
            p(Math.max(a2, (width - paddingLeft) - paddingRight));
        } else if (i4 == -1) {
            p((width - paddingLeft) - paddingRight);
        } else {
            p(i4);
        }
        boolean z3 = l1.f1423a;
        if (q2.getLayoutDirection() == 1) {
            i3 = (((width - paddingRight) - this.f1247e) - this.f1293E) + i2;
        } else {
            i3 = paddingLeft + this.f1293E + i2;
        }
        this.f = i3;
    }
}
