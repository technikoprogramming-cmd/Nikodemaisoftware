package i;

import android.os.Build;
import java.lang.reflect.Method;

public abstract class l1 {

    /* renamed from: a  reason: collision with root package name */
    public static boolean f1423a;
    public static Method b;

    /* renamed from: c  reason: collision with root package name */
    public static final boolean f1424c;

    static {
        boolean z2;
        if (Build.VERSION.SDK_INT >= 27) {
            z2 = true;
        } else {
            z2 = false;
        }
        f1424c = z2;
    }
}
