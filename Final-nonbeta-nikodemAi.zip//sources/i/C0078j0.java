package i;

/* renamed from: i.j0  reason: case insensitive filesystem */
public interface C0078j0 {
}
