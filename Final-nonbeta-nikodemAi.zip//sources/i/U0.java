package i;

public abstract class U0 extends N0 {
}
