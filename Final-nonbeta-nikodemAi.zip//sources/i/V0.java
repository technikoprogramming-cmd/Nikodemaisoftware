package i;

import androidx.appcompat.widget.Toolbar;
import h.p;

public final /* synthetic */ class V0 implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f1323a;
    public final /* synthetic */ Toolbar b;

    public /* synthetic */ V0(Toolbar toolbar, int i2) {
        this.f1323a = i2;
        this.b = toolbar;
    }

    public final void run() {
        p pVar;
        switch (this.f1323a) {
            case 0:
                Y0 y02 = this.b.f507L;
                if (y02 == null) {
                    pVar = null;
                } else {
                    pVar = y02.b;
                }
                if (pVar != null) {
                    pVar.collapseActionView();
                    return;
                }
                return;
            default:
                this.b.m();
                return;
        }
    }
}
