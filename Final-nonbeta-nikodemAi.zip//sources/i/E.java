package i;

import B0.a;
import L.e;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.widget.RadioButton;
import ncs.nikodemai.ntabium.polskieoprogramowanie.R;

public final class E extends RadioButton {

    /* renamed from: a  reason: collision with root package name */
    public final e f1238a;
    public final C0091q b;

    /* renamed from: c  reason: collision with root package name */
    public final Y f1239c;

    /* renamed from: d  reason: collision with root package name */
    public C0104x f1240d;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public E(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, R.attr.radioButtonStyle);
        S0.a(context);
        R0.a(this, getContext());
        e eVar = new e(this);
        this.f1238a = eVar;
        eVar.d(attributeSet, R.attr.radioButtonStyle);
        C0091q qVar = new C0091q(this);
        this.b = qVar;
        qVar.d(attributeSet, R.attr.radioButtonStyle);
        Y y2 = new Y(this);
        this.f1239c = y2;
        y2.f(attributeSet, R.attr.radioButtonStyle);
        getEmojiTextViewHelper().a(attributeSet, R.attr.radioButtonStyle);
    }

    private C0104x getEmojiTextViewHelper() {
        if (this.f1240d == null) {
            this.f1240d = new C0104x(this);
        }
        return this.f1240d;
    }

    public final void drawableStateChanged() {
        super.drawableStateChanged();
        C0091q qVar = this.b;
        if (qVar != null) {
            qVar.a();
        }
        Y y2 = this.f1239c;
        if (y2 != null) {
            y2.b();
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        C0091q qVar = this.b;
        if (qVar != null) {
            return qVar.b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0091q qVar = this.b;
        if (qVar != null) {
            return qVar.c();
        }
        return null;
    }

    public ColorStateList getSupportButtonTintList() {
        e eVar = this.f1238a;
        if (eVar != null) {
            return (ColorStateList) eVar.f130e;
        }
        return null;
    }

    public PorterDuff.Mode getSupportButtonTintMode() {
        e eVar = this.f1238a;
        if (eVar != null) {
            return (PorterDuff.Mode) eVar.f;
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.f1239c.d();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.f1239c.e();
    }

    public void setAllCaps(boolean z2) {
        super.setAllCaps(z2);
        getEmojiTextViewHelper().b(z2);
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0091q qVar = this.b;
        if (qVar != null) {
            qVar.e();
        }
    }

    public void setBackgroundResource(int i2) {
        super.setBackgroundResource(i2);
        C0091q qVar = this.b;
        if (qVar != null) {
            qVar.f(i2);
        }
    }

    public void setButtonDrawable(Drawable drawable) {
        super.setButtonDrawable(drawable);
        e eVar = this.f1238a;
        if (eVar == null) {
            return;
        }
        if (eVar.f128c) {
            eVar.f128c = false;
            return;
        }
        eVar.f128c = true;
        eVar.a();
    }

    public final void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        Y y2 = this.f1239c;
        if (y2 != null) {
            y2.b();
        }
    }

    public final void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        Y y2 = this.f1239c;
        if (y2 != null) {
            y2.b();
        }
    }

    public void setEmojiCompatEnabled(boolean z2) {
        getEmojiTextViewHelper().c(z2);
    }

    public void setFilters(InputFilter[] inputFilterArr) {
        super.setFilters(((a) getEmojiTextViewHelper().b.b).t(inputFilterArr));
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C0091q qVar = this.b;
        if (qVar != null) {
            qVar.h(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C0091q qVar = this.b;
        if (qVar != null) {
            qVar.i(mode);
        }
    }

    public void setSupportButtonTintList(ColorStateList colorStateList) {
        e eVar = this.f1238a;
        if (eVar != null) {
            eVar.f130e = colorStateList;
            eVar.f127a = true;
            eVar.a();
        }
    }

    public void setSupportButtonTintMode(PorterDuff.Mode mode) {
        e eVar = this.f1238a;
        if (eVar != null) {
            eVar.f = mode;
            eVar.b = true;
            eVar.a();
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        Y y2 = this.f1239c;
        y2.l(colorStateList);
        y2.b();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        Y y2 = this.f1239c;
        y2.m(mode);
        y2.b();
    }

    public void setButtonDrawable(int i2) {
        setButtonDrawable(a.r(getContext(), i2));
    }
}
