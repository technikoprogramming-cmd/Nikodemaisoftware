package i;

import android.view.MenuItem;
import androidx.appcompat.widget.Toolbar;
import h.l;
import h.n;

public final class W0 implements C0087o, l {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ Toolbar f1324a;

    public /* synthetic */ W0(Toolbar toolbar) {
        this.f1324a = toolbar;
    }

    public void g(n nVar) {
        Toolbar toolbar = this.f1324a;
        C0081l lVar = toolbar.f513a.f477t;
        if (lVar == null || !lVar.h()) {
            toolbar.f502G.B();
        }
    }

    public boolean h(n nVar, MenuItem menuItem) {
        this.f1324a.getClass();
        return false;
    }
}
