package i;

import C.j;

/* renamed from: i.a0  reason: case insensitive filesystem */
public class C0060a0 extends j {

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ C0064c0 f1341c;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public C0060a0(C0064c0 c0Var) {
        super(17, (Object) c0Var);
        this.f1341c = c0Var;
    }

    public final void d(int i2) {
        C0060a0.super.setFirstBaselineToTopHeight(i2);
    }

    public final void v(int i2) {
        C0060a0.super.setLastBaselineToBottomHeight(i2);
    }
}
