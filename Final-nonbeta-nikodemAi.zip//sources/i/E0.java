package i;

import android.view.MotionEvent;
import android.view.View;

public final class E0 implements View.OnTouchListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ F0 f1241a;

    public E0(F0 f02) {
        this.f1241a = f02;
    }

    public final boolean onTouch(View view, MotionEvent motionEvent) {
        C0057C c2;
        int action = motionEvent.getAction();
        int x2 = (int) motionEvent.getX();
        int y2 = (int) motionEvent.getY();
        F0 f02 = this.f1241a;
        if (action == 0 && (c2 = f02.f1266y) != null && c2.isShowing() && x2 >= 0 && x2 < f02.f1266y.getWidth() && y2 >= 0 && y2 < f02.f1266y.getHeight()) {
            f02.f1262u.postDelayed(f02.f1258q, 250);
            return false;
        } else if (action != 1) {
            return false;
        } else {
            f02.f1262u.removeCallbacks(f02.f1258q);
            return false;
        }
    }
}
