package i;

import h.D;

public final class I extends C0101v0 {

    /* renamed from: j  reason: collision with root package name */
    public final /* synthetic */ N f1273j;

    /* renamed from: k  reason: collision with root package name */
    public final /* synthetic */ Q f1274k;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public I(Q q2, Q q3, N n2) {
        super(q3);
        this.f1274k = q2;
        this.f1273j = n2;
    }

    public final D b() {
        return this.f1273j;
    }

    public final boolean c() {
        Q q2 = this.f1274k;
        if (q2.getInternalPopup().a()) {
            return true;
        }
        q2.f.e(q2.getTextDirection(), q2.getTextAlignment());
        return true;
    }
}
