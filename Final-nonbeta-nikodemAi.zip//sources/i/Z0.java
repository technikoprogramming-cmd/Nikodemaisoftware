package i;

import android.view.ViewGroup;

public final class Z0 extends ViewGroup.MarginLayoutParams {

    /* renamed from: a  reason: collision with root package name */
    public int f1338a = 0;
    public int b;

    public Z0(Z0 z02) {
        super(z02);
        this.f1338a = z02.f1338a;
    }

    public Z0(ViewGroup.LayoutParams layoutParams) {
        super(layoutParams);
    }
}
