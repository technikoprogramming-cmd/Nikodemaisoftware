package i;

import B0.a;
import C.j;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.widget.TextView;
import d.C0012a;

/* renamed from: i.x  reason: case insensitive filesystem */
public final class C0104x {

    /* renamed from: a  reason: collision with root package name */
    public final TextView f1475a;
    public final j b;

    public C0104x(TextView textView) {
        this.f1475a = textView;
        this.b = new j(textView);
    }

    /* JADX INFO: finally extract failed */
    public final void a(AttributeSet attributeSet, int i2) {
        TypedArray obtainStyledAttributes = this.f1475a.getContext().obtainStyledAttributes(attributeSet, C0012a.f807i, i2, 0);
        try {
            boolean z2 = true;
            if (obtainStyledAttributes.hasValue(14)) {
                z2 = obtainStyledAttributes.getBoolean(14, true);
            }
            obtainStyledAttributes.recycle();
            c(z2);
        } catch (Throwable th) {
            obtainStyledAttributes.recycle();
            throw th;
        }
    }

    public final void b(boolean z2) {
        ((a) this.b.b).P(z2);
    }

    public final void c(boolean z2) {
        ((a) this.b.b).Q(z2);
    }
}
