package i;

import android.widget.AdapterView;
import android.widget.HorizontalScrollView;

public abstract class P0 extends HorizontalScrollView implements AdapterView.OnItemSelectedListener {
}
