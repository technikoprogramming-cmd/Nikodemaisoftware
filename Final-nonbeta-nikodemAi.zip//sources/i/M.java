package i;

import android.view.ViewTreeObserver;
import android.widget.PopupWindow;
import h.C0051d;

public final class M implements PopupWindow.OnDismissListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ C0051d f1283a;
    public final /* synthetic */ N b;

    public M(N n2, C0051d dVar) {
        this.b = n2;
        this.f1283a = dVar;
    }

    public final void onDismiss() {
        ViewTreeObserver viewTreeObserver = this.b.f1294F.getViewTreeObserver();
        if (viewTreeObserver != null) {
            viewTreeObserver.removeGlobalOnLayoutListener(this.f1283a);
        }
    }
}
