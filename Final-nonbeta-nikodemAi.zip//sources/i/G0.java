package i;

import h.n;
import h.p;

public interface G0 {
    void q(n nVar, p pVar);

    void t(n nVar, p pVar);
}
