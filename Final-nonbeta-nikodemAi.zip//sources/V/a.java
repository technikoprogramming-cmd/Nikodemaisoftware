package V;

import Q.f;
import S.n;
import Z.b;

public final class a {

    /* renamed from: g  reason: collision with root package name */
    public static final int[] f281g = {3808, 476, 2107, 1799};

    /* renamed from: a  reason: collision with root package name */
    public final b f282a;
    public boolean b;

    /* renamed from: c  reason: collision with root package name */
    public int f283c;

    /* renamed from: d  reason: collision with root package name */
    public int f284d;

    /* renamed from: e  reason: collision with root package name */
    public int f285e;
    public int f;

    public a(b bVar) {
        this.f282a = bVar;
    }

    public static n[] b(n[] nVarArr, float f2, float f3) {
        float f4 = f3 / (f2 * 2.0f);
        n nVar = nVarArr[0];
        float f5 = nVar.f271a;
        n nVar2 = nVarArr[2];
        float f6 = nVar2.f271a;
        float f7 = f5 - f6;
        float f8 = nVar.b;
        float f9 = nVar2.b;
        float f10 = f8 - f9;
        float f11 = (f5 + f6) / 2.0f;
        float f12 = (f8 + f9) / 2.0f;
        float f13 = f7 * f4;
        float f14 = f10 * f4;
        n nVar3 = new n(f11 + f13, f12 + f14);
        n nVar4 = new n(f11 - f13, f12 - f14);
        n nVar5 = nVarArr[1];
        float f15 = nVar5.f271a;
        n nVar6 = nVarArr[3];
        float f16 = nVar6.f271a;
        float f17 = f15 - f16;
        float f18 = nVar5.b;
        float f19 = nVar6.b;
        float f20 = f18 - f19;
        float f21 = (f15 + f16) / 2.0f;
        float f22 = (f18 + f19) / 2.0f;
        float f23 = f17 * f4;
        float f24 = f4 * f20;
        return new n[]{nVar3, new n(f21 + f23, f22 + f24), nVar4, new n(f21 - f23, f22 - f24)};
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r17v0, resolved type: int} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r20v0, resolved type: int} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r20v1, resolved type: int} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v3, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v44, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v45, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r20v2, resolved type: int} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r20v4, resolved type: int} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final T.a a(boolean r41) {
        /*
            r40 = this;
            r0 = r40
            Z.b r1 = r0.f282a
            r2 = -1
            r3 = 2
            r4 = 3
            r5 = 7
            r6 = 1
            r7 = 0
            a0.a r8 = new a0.a     // Catch:{ h -> 0x001c }
            r8.<init>(r1)     // Catch:{ h -> 0x001c }
            S.n[] r8 = r8.b()     // Catch:{ h -> 0x001c }
            r9 = r8[r7]     // Catch:{ h -> 0x001c }
            r10 = r8[r6]     // Catch:{ h -> 0x001c }
            r11 = r8[r3]     // Catch:{ h -> 0x001c }
            r8 = r8[r4]     // Catch:{ h -> 0x001c }
            goto L_0x0064
        L_0x001c:
            int r8 = r1.f302a
            int r8 = r8 / r3
            int r9 = r1.b
            int r9 = r9 / r3
            Q.f r10 = new Q.f
            int r11 = r8 + 7
            int r12 = r9 + -7
            r13 = 1
            r10.<init>(r11, r12, r13)
            Q.f r10 = r0.e(r10, r7, r6, r2)
            S.n r10 = r10.a()
            Q.f r13 = new Q.f
            int r9 = r9 + r5
            r14 = 1
            r13.<init>(r11, r9, r14)
            Q.f r11 = r0.e(r13, r7, r6, r6)
            S.n r11 = r11.a()
            Q.f r13 = new Q.f
            int r8 = r8 - r5
            r13.<init>(r8, r9, r14)
            Q.f r9 = r0.e(r13, r7, r2, r6)
            S.n r9 = r9.a()
            Q.f r13 = new Q.f
            r13.<init>(r8, r12, r14)
            Q.f r8 = r0.e(r13, r7, r2, r2)
            S.n r8 = r8.a()
            r39 = r11
            r11 = r9
            r9 = r10
            r10 = r39
        L_0x0064:
            float r12 = r9.f271a
            float r13 = r8.f271a
            float r12 = r12 + r13
            float r13 = r10.f271a
            float r12 = r12 + r13
            float r13 = r11.f271a
            float r12 = r12 + r13
            r13 = 1082130432(0x40800000, float:4.0)
            float r12 = r12 / r13
            int r12 = B0.a.N(r12)
            float r9 = r9.b
            float r8 = r8.b
            float r9 = r9 + r8
            float r8 = r10.b
            float r9 = r9 + r8
            float r8 = r11.b
            float r9 = r9 + r8
            float r9 = r9 / r13
            int r8 = B0.a.N(r9)
            r9 = 15
            a0.a r10 = new a0.a     // Catch:{ h -> 0x009c }
            r10.<init>(r1, r9, r12, r8)     // Catch:{ h -> 0x009c }
            S.n[] r10 = r10.b()     // Catch:{ h -> 0x009c }
            r11 = r10[r7]     // Catch:{ h -> 0x009c }
            r14 = r10[r6]     // Catch:{ h -> 0x009c }
            r15 = r10[r3]     // Catch:{ h -> 0x009c }
            r8 = r10[r4]     // Catch:{ h -> 0x009c }
            r16 = r4
            goto L_0x00de
        L_0x009c:
            Q.f r10 = new Q.f
            int r11 = r12 + 7
            int r14 = r8 + -7
            r15 = 1
            r10.<init>(r11, r14, r15)
            Q.f r10 = r0.e(r10, r7, r6, r2)
            S.n r10 = r10.a()
            Q.f r15 = new Q.f
            int r8 = r8 + r5
            r16 = r4
            r4 = 1
            r15.<init>(r11, r8, r4)
            Q.f r4 = r0.e(r15, r7, r6, r6)
            S.n r4 = r4.a()
            Q.f r11 = new Q.f
            int r12 = r12 - r5
            r15 = 1
            r11.<init>(r12, r8, r15)
            Q.f r8 = r0.e(r11, r7, r2, r6)
            S.n r15 = r8.a()
            Q.f r8 = new Q.f
            r11 = 1
            r8.<init>(r12, r14, r11)
            Q.f r8 = r0.e(r8, r7, r2, r2)
            S.n r8 = r8.a()
            r14 = r4
            r11 = r10
        L_0x00de:
            float r4 = r11.f271a
            float r10 = r8.f271a
            float r4 = r4 + r10
            float r10 = r14.f271a
            float r4 = r4 + r10
            float r10 = r15.f271a
            float r4 = r4 + r10
            float r4 = r4 / r13
            int r4 = B0.a.N(r4)
            float r10 = r11.b
            float r8 = r8.b
            float r10 = r10 + r8
            float r8 = r14.b
            float r10 = r10 + r8
            float r8 = r15.b
            float r10 = r10 + r8
            float r10 = r10 / r13
            int r8 = B0.a.N(r10)
            Q.f r10 = new Q.f
            r11 = 1
            r10.<init>(r4, r8, r11)
            r0.f285e = r6
            r12 = r6
            r4 = r10
            r8 = r4
            r11 = r8
        L_0x010a:
            int r13 = r0.f285e
            r14 = 9
            int r15 = r11.f160c
            r17 = r7
            int r7 = r11.b
            r18 = r9
            int r9 = r10.f160c
            int r5 = r10.b
            if (r13 >= r14) goto L_0x01f7
            Q.f r10 = r0.e(r10, r12, r6, r2)
            Q.f r13 = r0.e(r4, r12, r6, r6)
            Q.f r14 = r0.e(r8, r12, r2, r6)
            Q.f r11 = r0.e(r11, r12, r2, r2)
            int r2 = r0.f285e
            if (r2 <= r3) goto L_0x01d0
            int r2 = r11.b
            r20 = r6
            int r6 = r10.b
            int r21 = r2 - r6
            r22 = r3
            int r3 = r11.f160c
            r23 = r2
            int r2 = r10.f160c
            int r24 = r3 - r2
            int r21 = r21 * r21
            int r24 = r24 * r24
            r25 = r2
            int r2 = r24 + r21
            r21 = r3
            double r2 = (double) r2
            double r2 = java.lang.Math.sqrt(r2)
            float r2 = (float) r2
            int r3 = r0.f285e
            float r3 = (float) r3
            float r2 = r2 * r3
            int r3 = r7 - r5
            int r24 = r15 - r9
            int r3 = r3 * r3
            int r24 = r24 * r24
            int r3 = r24 + r3
            r24 = r2
            double r2 = (double) r3
            double r2 = java.lang.Math.sqrt(r2)
            float r2 = (float) r2
            int r3 = r0.f285e
            int r3 = r3 + 2
            float r3 = (float) r3
            float r2 = r2 * r3
            float r2 = r24 / r2
            double r2 = (double) r2
            r26 = 4604930618986332160(0x3fe8000000000000, double:0.75)
            int r24 = (r2 > r26 ? 1 : (r2 == r26 ? 0 : -1))
            if (r24 < 0) goto L_0x01fb
            r26 = 4608308318706860032(0x3ff4000000000000, double:1.25)
            int r2 = (r2 > r26 ? 1 : (r2 == r26 ? 0 : -1))
            if (r2 > 0) goto L_0x01fb
            Q.f r2 = new Q.f
            int r6 = r6 + -3
            int r3 = r25 + 3
            r24 = r10
            r10 = 1
            r2.<init>(r6, r3, r10)
            Q.f r3 = new Q.f
            int r6 = r13.b
            int r6 = r6 + -3
            int r10 = r13.f160c
            int r10 = r10 + -3
            r25 = r11
            r11 = 1
            r3.<init>(r6, r10, r11)
            Q.f r6 = new Q.f
            int r10 = r14.b
            int r10 = r10 + 3
            int r11 = r14.f160c
            int r11 = r11 + -3
            r26 = r12
            r12 = 1
            r6.<init>(r10, r11, r12)
            Q.f r10 = new Q.f
            int r11 = r23 + 3
            int r12 = r21 + 3
            r21 = r13
            r13 = 1
            r10.<init>(r11, r12, r13)
            int r11 = r0.c(r10, r2)
            if (r11 != 0) goto L_0x01bb
            goto L_0x01fb
        L_0x01bb:
            int r2 = r0.c(r2, r3)
            if (r2 == r11) goto L_0x01c2
            goto L_0x01fb
        L_0x01c2:
            int r2 = r0.c(r3, r6)
            if (r2 == r11) goto L_0x01c9
            goto L_0x01fb
        L_0x01c9:
            int r2 = r0.c(r6, r10)
            if (r2 != r11) goto L_0x01fb
            goto L_0x01dc
        L_0x01d0:
            r22 = r3
            r20 = r6
            r24 = r10
            r25 = r11
            r26 = r12
            r21 = r13
        L_0x01dc:
            r12 = r26 ^ 1
            int r2 = r0.f285e
            int r2 = r2 + 1
            r0.f285e = r2
            r8 = r14
            r7 = r17
            r9 = r18
            r6 = r20
            r4 = r21
            r3 = r22
            r10 = r24
            r11 = r25
            r2 = -1
            r5 = 7
            goto L_0x010a
        L_0x01f7:
            r22 = r3
            r20 = r6
        L_0x01fb:
            int r2 = r0.f285e
            r3 = 5
            if (r2 == r3) goto L_0x0207
            r6 = 7
            if (r2 != r6) goto L_0x0204
            goto L_0x0207
        L_0x0204:
            S.h r1 = S.h.f252c
            throw r1
        L_0x0207:
            if (r2 != r3) goto L_0x020c
            r3 = r20
            goto L_0x020e
        L_0x020c:
            r3 = r17
        L_0x020e:
            r0.b = r3
            S.n r3 = new S.n
            float r5 = (float) r5
            r6 = 1056964608(0x3f000000, float:0.5)
            float r5 = r5 + r6
            float r9 = (float) r9
            float r9 = r9 - r6
            r3.<init>(r5, r9)
            S.n r5 = new S.n
            int r9 = r4.b
            float r9 = (float) r9
            float r9 = r9 + r6
            int r4 = r4.f160c
            float r4 = (float) r4
            float r4 = r4 + r6
            r5.<init>(r9, r4)
            S.n r4 = new S.n
            int r9 = r8.b
            float r9 = (float) r9
            float r9 = r9 - r6
            int r8 = r8.f160c
            float r8 = (float) r8
            float r8 = r8 + r6
            r4.<init>(r9, r8)
            S.n r8 = new S.n
            float r7 = (float) r7
            float r7 = r7 - r6
            float r9 = (float) r15
            float r9 = r9 - r6
            r8.<init>(r7, r9)
            S.n[] r3 = new S.n[]{r3, r5, r4, r8}
            int r2 = r2 * 2
            int r4 = r2 + -3
            float r4 = (float) r4
            float r2 = (float) r2
            S.n[] r2 = b(r3, r4, r2)
            if (r41 == 0) goto L_0x0256
            r3 = r2[r17]
            r4 = r2[r22]
            r2[r17] = r4
            r2[r22] = r3
        L_0x0256:
            r3 = r2[r17]
            boolean r3 = r0.g(r3)
            if (r3 == 0) goto L_0x03d0
            r3 = r2[r20]
            boolean r3 = r0.g(r3)
            if (r3 == 0) goto L_0x03d0
            r3 = r2[r22]
            boolean r3 = r0.g(r3)
            if (r3 == 0) goto L_0x03d0
            r3 = r2[r16]
            boolean r3 = r0.g(r3)
            if (r3 == 0) goto L_0x03d0
            int r3 = r0.f285e
            int r3 = r3 * 2
            r4 = r2[r17]
            r5 = r2[r20]
            int r4 = r0.h(r4, r5, r3)
            r5 = r2[r20]
            r6 = r2[r22]
            int r5 = r0.h(r5, r6, r3)
            r6 = r2[r22]
            r7 = r2[r16]
            int r6 = r0.h(r6, r7, r3)
            r7 = r2[r16]
            r8 = r2[r17]
            int r7 = r0.h(r7, r8, r3)
            int[] r4 = new int[]{r4, r5, r6, r7}
            r5 = r17
            r6 = r5
        L_0x02a1:
            r7 = 4
            if (r5 >= r7) goto L_0x02b5
            r7 = r4[r5]
            int r8 = r3 + -2
            int r8 = r7 >> r8
            int r8 = r8 << 1
            r7 = r7 & 1
            int r8 = r8 + r7
            int r6 = r6 << 3
            int r6 = r6 + r8
            int r5 = r5 + 1
            goto L_0x02a1
        L_0x02b5:
            r3 = r6 & 1
            int r3 = r3 << 11
            int r5 = r6 >> 1
            int r3 = r3 + r5
            r5 = r17
        L_0x02be:
            if (r5 >= r7) goto L_0x03cd
            int[] r6 = f281g
            r6 = r6[r5]
            r6 = r6 ^ r3
            int r6 = java.lang.Integer.bitCount(r6)
            r8 = r22
            if (r6 > r8) goto L_0x03c5
            r0.f = r5
            r5 = 0
            r3 = r17
        L_0x02d3:
            r8 = 10
            if (r3 >= r7) goto L_0x02fc
            int r9 = r0.f
            int r9 = r9 + r3
            int r9 = r9 % r7
            r9 = r4[r9]
            boolean r10 = r0.b
            if (r10 == 0) goto L_0x02ec
            r19 = 7
            long r5 = r5 << r19
            int r8 = r9 >> 1
            r8 = r8 & 127(0x7f, float:1.78E-43)
        L_0x02e9:
            long r8 = (long) r8
            long r5 = r5 + r8
            goto L_0x02f9
        L_0x02ec:
            r19 = 7
            long r5 = r5 << r8
            int r8 = r9 >> 2
            r8 = r8 & 992(0x3e0, float:1.39E-42)
            int r9 = r9 >> 1
            r9 = r9 & 31
            int r8 = r8 + r9
            goto L_0x02e9
        L_0x02f9:
            int r3 = r3 + 1
            goto L_0x02d3
        L_0x02fc:
            r19 = 7
            boolean r3 = r0.b
            if (r3 == 0) goto L_0x0306
            r8 = r19
            r3 = 2
            goto L_0x0307
        L_0x0306:
            r3 = r7
        L_0x0307:
            int r4 = r8 - r3
            int[] r9 = new int[r8]
            int r8 = r8 + -1
        L_0x030d:
            if (r8 < 0) goto L_0x0318
            int r10 = (int) r5
            r10 = r10 & 15
            r9[r8] = r10
            long r5 = r5 >> r7
            int r8 = r8 + -1
            goto L_0x030d
        L_0x0318:
            C.j r5 = new C.j     // Catch:{ b -> 0x03c2 }
            b0.a r6 = b0.C0009a.f773k     // Catch:{ b -> 0x03c2 }
            r8 = 11
            r5.<init>((int) r8, (java.lang.Object) r6)     // Catch:{ b -> 0x03c2 }
            r5.x(r9, r4)     // Catch:{ b -> 0x03c2 }
            r4 = r17
            r5 = r4
        L_0x0327:
            if (r4 >= r3) goto L_0x0331
            int r5 = r5 << 4
            r6 = r9[r4]
            int r5 = r5 + r6
            int r4 = r4 + 1
            goto L_0x0327
        L_0x0331:
            boolean r3 = r0.b
            if (r3 == 0) goto L_0x0342
            int r3 = r5 >> 6
            int r3 = r3 + 1
            r0.f283c = r3
            r3 = r5 & 63
            int r3 = r3 + 1
            r0.f284d = r3
            goto L_0x034e
        L_0x0342:
            int r3 = r5 >> 11
            int r3 = r3 + 1
            r0.f283c = r3
            r3 = r5 & 2047(0x7ff, float:2.868E-42)
            int r3 = r3 + 1
            r0.f284d = r3
        L_0x034e:
            int r3 = r0.f
            int r4 = r3 % 4
            r4 = r2[r4]
            int r5 = r3 + 1
            int r5 = r5 % r7
            r5 = r2[r5]
            int r6 = r3 + 2
            int r6 = r6 % r7
            r6 = r2[r6]
            int r3 = r3 + 3
            int r3 = r3 % r7
            r3 = r2[r3]
            int r7 = r0.d()
            float r8 = (float) r7
            r9 = 1073741824(0x40000000, float:2.0)
            float r8 = r8 / r9
            int r9 = r0.f285e
            float r9 = (float) r9
            float r23 = r8 - r9
            float r25 = r8 + r9
            float r8 = r4.f271a
            float r9 = r5.f271a
            float r10 = r6.f271a
            float r11 = r3.f271a
            float r4 = r4.b
            float r5 = r5.b
            float r6 = r6.b
            float r3 = r3.b
            r24 = r23
            r26 = r23
            r27 = r25
            r28 = r25
            r29 = r23
            r30 = r25
            r38 = r3
            r32 = r4
            r34 = r5
            r36 = r6
            r31 = r8
            r33 = r9
            r35 = r10
            r37 = r11
            Z.g r3 = Z.g.a(r23, r24, r25, r26, r27, r28, r29, r30, r31, r32, r33, r34, r35, r36, r37, r38)
            Z.b r9 = B0.a.O(r1, r7, r7, r3)
            int r1 = r0.f285e
            r22 = 2
            int r1 = r1 * 2
            float r1 = (float) r1
            int r3 = r0.d()
            float r3 = (float) r3
            S.n[] r10 = b(r2, r1, r3)
            T.a r8 = new T.a
            boolean r11 = r0.b
            int r12 = r0.f284d
            int r13 = r0.f283c
            r8.<init>(r9, r10, r11, r12, r13)
            return r8
        L_0x03c2:
            S.h r1 = S.h.f252c
            throw r1
        L_0x03c5:
            r22 = r8
            r19 = 7
            int r5 = r5 + 1
            goto L_0x02be
        L_0x03cd:
            S.h r1 = S.h.f252c
            throw r1
        L_0x03d0:
            S.h r1 = S.h.f252c
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: V.a.a(boolean):T.a");
    }

    public final int c(f fVar, f fVar2) {
        int i2 = fVar.b;
        int i3 = fVar2.b;
        int i4 = i2 - i3;
        int i5 = fVar.f160c;
        int i6 = fVar2.f160c;
        int i7 = i5 - i6;
        float sqrt = (float) Math.sqrt((double) ((i7 * i7) + (i4 * i4)));
        float f2 = ((float) (i3 - i2)) / sqrt;
        float f3 = ((float) (i6 - i5)) / sqrt;
        float f4 = (float) i2;
        float f5 = (float) i5;
        b bVar = this.f282a;
        boolean b2 = bVar.b(i2, i5);
        int ceil = (int) Math.ceil((double) sqrt);
        boolean z2 = false;
        int i8 = 0;
        for (int i9 = 0; i9 < ceil; i9++) {
            f4 += f2;
            f5 += f3;
            if (bVar.b(B0.a.N(f4), B0.a.N(f5)) != b2) {
                i8++;
            }
        }
        float f6 = ((float) i8) / sqrt;
        if (f6 > 0.1f && f6 < 0.9f) {
            return 0;
        }
        if (f6 <= 0.1f) {
            z2 = true;
        }
        if (z2 == b2) {
            return 1;
        }
        return -1;
    }

    public final int d() {
        if (this.b) {
            return (this.f283c * 4) + 11;
        }
        int i2 = this.f283c;
        if (i2 <= 4) {
            return (i2 * 4) + 15;
        }
        return ((((i2 - 4) / 8) + 1) * 2) + (i2 * 4) + 15;
    }

    public final f e(f fVar, boolean z2, int i2, int i3) {
        int i4 = fVar.b + i2;
        int i5 = fVar.f160c;
        while (true) {
            i5 += i3;
            boolean f2 = f(i4, i5);
            b bVar = this.f282a;
            if (!f2 || bVar.b(i4, i5) != z2) {
                int i6 = i4 - i2;
                int i7 = i5 - i3;
            } else {
                i4 += i2;
            }
        }
        int i62 = i4 - i2;
        int i72 = i5 - i3;
        while (f(i62, i72) && bVar.b(i62, i72) == z2) {
            i62 += i2;
        }
        int i8 = i62 - i2;
        while (f(i8, i72) && bVar.b(i8, i72) == z2) {
            i72 += i3;
        }
        return new f(i8, i72 - i3, 1);
    }

    public final boolean f(int i2, int i3) {
        if (i2 < 0) {
            return false;
        }
        b bVar = this.f282a;
        if (i2 >= bVar.f302a || i3 <= 0 || i3 >= bVar.b) {
            return false;
        }
        return true;
    }

    public final boolean g(n nVar) {
        return f(B0.a.N(nVar.f271a), B0.a.N(nVar.b));
    }

    public final int h(n nVar, n nVar2, int i2) {
        float f2 = nVar.f271a - nVar2.f271a;
        float f3 = nVar.b;
        float f4 = nVar2.b;
        float f5 = f3 - f4;
        float sqrt = (float) Math.sqrt((double) ((f5 * f5) + (f2 * f2)));
        float f6 = sqrt / ((float) i2);
        float f7 = nVar2.f271a;
        float f8 = nVar.f271a;
        float f9 = ((f7 - f8) * f6) / sqrt;
        float f10 = ((f4 - f3) * f6) / sqrt;
        int i3 = 0;
        for (int i4 = 0; i4 < i2; i4++) {
            float f11 = (float) i4;
            if (this.f282a.b(B0.a.N((f11 * f9) + f8), B0.a.N((f11 * f10) + f3))) {
                i3 |= 1 << ((i2 - i4) - 1);
            }
        }
        return i3;
    }
}
