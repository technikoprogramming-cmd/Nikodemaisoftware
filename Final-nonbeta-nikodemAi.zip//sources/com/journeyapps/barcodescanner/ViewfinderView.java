package com.journeyapps.barcodescanner;

import S.n;
import W.j;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.View;
import java.util.ArrayList;
import ncs.nikodemai.ntabium.polskieoprogramowanie.R;
import t0.e;
import t0.f;

public class ViewfinderView extends View {

    /* renamed from: k  reason: collision with root package name */
    public static final int[] f792k = {0, 64, 128, 192, 255, 192, 128, 64};

    /* renamed from: a  reason: collision with root package name */
    public final Paint f793a = new Paint(1);
    public final int b;

    /* renamed from: c  reason: collision with root package name */
    public final int f794c;

    /* renamed from: d  reason: collision with root package name */
    public final int f795d;

    /* renamed from: e  reason: collision with root package name */
    public int f796e;
    public ArrayList f;

    /* renamed from: g  reason: collision with root package name */
    public ArrayList f797g;

    /* renamed from: h  reason: collision with root package name */
    public f f798h;

    /* renamed from: i  reason: collision with root package name */
    public Rect f799i;

    /* renamed from: j  reason: collision with root package name */
    public Rect f800j;

    public ViewfinderView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        Resources resources = getResources();
        TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, j.b);
        this.b = obtainStyledAttributes.getColor(3, resources.getColor(R.color.zxing_viewfinder_mask));
        obtainStyledAttributes.getColor(1, resources.getColor(R.color.zxing_result_view));
        this.f794c = obtainStyledAttributes.getColor(2, resources.getColor(R.color.zxing_viewfinder_laser));
        this.f795d = obtainStyledAttributes.getColor(0, resources.getColor(R.color.zxing_possible_result_points));
        obtainStyledAttributes.recycle();
        this.f796e = 0;
        this.f = new ArrayList(20);
        this.f797g = new ArrayList(20);
    }

    public final void onDraw(Canvas canvas) {
        Rect rect;
        f fVar = this.f798h;
        if (fVar != null) {
            Rect framingRect = fVar.getFramingRect();
            Rect previewFramingRect = this.f798h.getPreviewFramingRect();
            if (!(framingRect == null || previewFramingRect == null)) {
                this.f799i = framingRect;
                this.f800j = previewFramingRect;
            }
        }
        Rect rect2 = this.f799i;
        if (rect2 != null && (rect = this.f800j) != null) {
            int width = canvas.getWidth();
            int height = canvas.getHeight();
            Paint paint = this.f793a;
            paint.setColor(this.b);
            float f2 = (float) width;
            Canvas canvas2 = canvas;
            canvas2.drawRect(0.0f, 0.0f, f2, (float) rect2.top, paint);
            canvas2.drawRect(0.0f, (float) rect2.top, (float) rect2.left, (float) (rect2.bottom + 1), paint);
            float f3 = f2;
            canvas2.drawRect((float) (rect2.right + 1), (float) rect2.top, f3, (float) (rect2.bottom + 1), paint);
            canvas2.drawRect(0.0f, (float) (rect2.bottom + 1), f3, (float) height, paint);
            paint.setColor(this.f794c);
            paint.setAlpha(f792k[this.f796e]);
            this.f796e = (this.f796e + 1) % 8;
            int height2 = (rect2.height() / 2) + rect2.top;
            canvas2.drawRect((float) (rect2.left + 2), (float) (height2 - 1), (float) (rect2.right - 1), (float) (height2 + 2), paint);
            float width2 = ((float) rect2.width()) / ((float) rect.width());
            float height3 = ((float) rect2.height()) / ((float) rect.height());
            int i2 = rect2.left;
            int i3 = rect2.top;
            boolean isEmpty = this.f797g.isEmpty();
            int i4 = 0;
            int i5 = this.f795d;
            if (!isEmpty) {
                paint.setAlpha(80);
                paint.setColor(i5);
                ArrayList arrayList = this.f797g;
                int size = arrayList.size();
                int i6 = 0;
                while (i6 < size) {
                    Object obj = arrayList.get(i6);
                    i6++;
                    n nVar = (n) obj;
                    canvas2.drawCircle((float) (((int) (nVar.f271a * width2)) + i2), (float) (((int) (nVar.b * height3)) + i3), 3.0f, paint);
                }
                this.f797g.clear();
            }
            if (!this.f.isEmpty()) {
                paint.setAlpha(160);
                paint.setColor(i5);
                ArrayList arrayList2 = this.f;
                int size2 = arrayList2.size();
                while (i4 < size2) {
                    Object obj2 = arrayList2.get(i4);
                    i4++;
                    n nVar2 = (n) obj2;
                    canvas2.drawCircle((float) (((int) (nVar2.f271a * width2)) + i2), (float) (((int) (nVar2.b * height3)) + i3), 6.0f, paint);
                }
                ArrayList arrayList3 = this.f;
                ArrayList arrayList4 = this.f797g;
                this.f = arrayList4;
                this.f797g = arrayList3;
                arrayList4.clear();
            }
            postInvalidateDelayed(80, rect2.left - 6, rect2.top - 6, rect2.right + 6, rect2.bottom + 6);
        }
    }

    public void setCameraPreview(f fVar) {
        this.f798h = fVar;
        fVar.f1797j.add(new e(2, this));
    }
}
