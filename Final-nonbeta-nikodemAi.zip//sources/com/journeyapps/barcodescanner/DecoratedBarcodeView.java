package com.journeyapps.barcodescanner;

import W.j;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;
import ncs.nikodemai.ntabium.polskieoprogramowanie.R;
import t0.p;

public class DecoratedBarcodeView extends FrameLayout {

    /* renamed from: a  reason: collision with root package name */
    public final BarcodeView f790a;
    public final ViewfinderView b;

    /* renamed from: c  reason: collision with root package name */
    public final TextView f791c;

    public DecoratedBarcodeView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, j.f299c);
        int resourceId = obtainStyledAttributes.getResourceId(0, R.layout.zxing_barcode_scanner);
        obtainStyledAttributes.recycle();
        View.inflate(getContext(), resourceId, this);
        BarcodeView barcodeView = (BarcodeView) findViewById(R.id.zxing_barcode_surface);
        this.f790a = barcodeView;
        if (barcodeView != null) {
            barcodeView.b(attributeSet);
            ViewfinderView viewfinderView = (ViewfinderView) findViewById(R.id.zxing_viewfinder_view);
            this.b = viewfinderView;
            if (viewfinderView != null) {
                viewfinderView.setCameraPreview(this.f790a);
                this.f791c = (TextView) findViewById(R.id.zxing_status_view);
                return;
            }
            throw new IllegalArgumentException("There is no a com.journeyapps.barcodescanner.ViewfinderView on provided layout with the id \"zxing_viewfinder_view\".");
        }
        throw new IllegalArgumentException("There is no a com.journeyapps.barcodescanner.BarcodeView on provided layout with the id \"zxing_barcode_surface\".");
    }

    public BarcodeView getBarcodeView() {
        return (BarcodeView) findViewById(R.id.zxing_barcode_surface);
    }

    public TextView getStatusView() {
        return this.f791c;
    }

    public ViewfinderView getViewFinder() {
        return this.b;
    }

    public final boolean onKeyDown(int i2, KeyEvent keyEvent) {
        if (i2 == 24) {
            this.f790a.setTorch(true);
            return true;
        } else if (i2 == 25) {
            this.f790a.setTorch(false);
            return true;
        } else if (i2 == 27 || i2 == 80) {
            return true;
        } else {
            return super.onKeyDown(i2, keyEvent);
        }
    }

    public void setStatusText(String str) {
        TextView textView = this.f791c;
        if (textView != null) {
            textView.setText(str);
        }
    }

    public void setTorchListener(p pVar) {
    }
}
