package com.journeyapps.barcodescanner;

import W.i;
import android.app.Activity;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.KeyEvent;
import o.e;
import t0.j;
import u0.d;

public class CaptureActivity extends Activity {

    /* renamed from: a  reason: collision with root package name */
    public j f789a;
    public DecoratedBarcodeView b;

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r11v3, resolved type: java.lang.Class<S.a>} */
    /* JADX WARNING: type inference failed for: r7v4, types: [java.lang.Object, S.g] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Removed duplicated region for block: B:45:0x00e2  */
    /* JADX WARNING: Removed duplicated region for block: B:46:0x00e6  */
    /* JADX WARNING: Removed duplicated region for block: B:74:0x0181  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void onCreate(android.os.Bundle r18) {
        /*
            r17 = this;
            r0 = r17
            r1 = r18
            r3 = 1
            super.onCreate(r18)
            r4 = 2131427374(0x7f0b002e, float:1.8476362E38)
            r0.setContentView(r4)
            r4 = 2131230918(0x7f0800c6, float:1.8077902E38)
            android.view.View r4 = r0.findViewById(r4)
            com.journeyapps.barcodescanner.DecoratedBarcodeView r4 = (com.journeyapps.barcodescanner.DecoratedBarcodeView) r4
            r0.b = r4
            t0.j r4 = new t0.j
            com.journeyapps.barcodescanner.DecoratedBarcodeView r5 = r0.b
            r4.<init>(r0, r5)
            r0.f789a = r4
            android.content.Intent r6 = r0.getIntent()
            android.view.Window r7 = r0.getWindow()
            r8 = 128(0x80, float:1.794E-43)
            r7.addFlags(r8)
            r7 = -1
            if (r1 == 0) goto L_0x003a
            java.lang.String r8 = "SAVED_ORIENTATION_LOCK"
            int r1 = r1.getInt(r8, r7)
            r4.f1818c = r1
        L_0x003a:
            r1 = 2
            if (r6 == 0) goto L_0x01e4
            java.lang.String r8 = "SCAN_ORIENTATION_LOCKED"
            boolean r8 = r6.getBooleanExtra(r8, r3)
            if (r8 == 0) goto L_0x007e
            int r8 = r4.f1818c
            if (r8 != r7) goto L_0x0079
            android.view.WindowManager r8 = r0.getWindowManager()
            android.view.Display r8 = r8.getDefaultDisplay()
            int r8 = r8.getRotation()
            android.content.res.Resources r9 = r0.getResources()
            android.content.res.Configuration r9 = r9.getConfiguration()
            int r9 = r9.orientation
            if (r9 != r1) goto L_0x006b
            if (r8 == 0) goto L_0x0069
            if (r8 != r3) goto L_0x0066
            goto L_0x0069
        L_0x0066:
            r8 = 8
            goto L_0x0077
        L_0x0069:
            r8 = 0
            goto L_0x0077
        L_0x006b:
            if (r9 != r3) goto L_0x0069
            if (r8 == 0) goto L_0x0076
            r9 = 3
            if (r8 != r9) goto L_0x0073
            goto L_0x0076
        L_0x0073:
            r8 = 9
            goto L_0x0077
        L_0x0076:
            r8 = r3
        L_0x0077:
            r4.f1818c = r8
        L_0x0079:
            int r8 = r4.f1818c
            r0.setRequestedOrientation(r8)
        L_0x007e:
            java.lang.String r8 = "com.google.zxing.client.android.SCAN"
            java.lang.String r9 = r6.getAction()
            boolean r8 = r8.equals(r9)
            if (r8 == 0) goto L_0x01b3
            java.util.regex.Pattern r8 = W.f.f291a
            java.lang.String r8 = "SCAN_FORMATS"
            java.lang.String r8 = r6.getStringExtra(r8)
            r9 = 0
            if (r8 == 0) goto L_0x00a0
            java.util.regex.Pattern r10 = W.f.f291a
            java.lang.String[] r8 = r10.split(r8)
            java.util.List r8 = java.util.Arrays.asList(r8)
            goto L_0x00a1
        L_0x00a0:
            r8 = r9
        L_0x00a1:
            java.lang.String r10 = "SCAN_MODE"
            java.lang.String r10 = r6.getStringExtra(r10)
            if (r8 == 0) goto L_0x00c7
            java.lang.Class<S.a> r11 = S.a.class
            java.util.EnumSet r11 = java.util.EnumSet.noneOf(r11)
            java.util.Iterator r8 = r8.iterator()     // Catch:{ IllegalArgumentException -> 0x00c7 }
        L_0x00b3:
            boolean r12 = r8.hasNext()     // Catch:{ IllegalArgumentException -> 0x00c7 }
            if (r12 == 0) goto L_0x00d4
            java.lang.Object r12 = r8.next()     // Catch:{ IllegalArgumentException -> 0x00c7 }
            java.lang.String r12 = (java.lang.String) r12     // Catch:{ IllegalArgumentException -> 0x00c7 }
            S.a r12 = S.a.valueOf(r12)     // Catch:{ IllegalArgumentException -> 0x00c7 }
            r11.add(r12)     // Catch:{ IllegalArgumentException -> 0x00c7 }
            goto L_0x00b3
        L_0x00c7:
            if (r10 == 0) goto L_0x00d3
            java.util.HashMap r8 = W.f.b
            java.lang.Object r8 = r8.get(r10)
            java.util.Set r8 = (java.util.Set) r8
            r11 = r8
            goto L_0x00d4
        L_0x00d3:
            r11 = r9
        L_0x00d4:
            int r8 = W.g.f292a
            android.os.Bundle r8 = r6.getExtras()
            if (r8 == 0) goto L_0x00e2
            boolean r10 = r8.isEmpty()
            if (r10 == 0) goto L_0x00e6
        L_0x00e2:
            r16 = r3
            goto L_0x0164
        L_0x00e6:
            java.util.EnumMap r9 = new java.util.EnumMap
            java.lang.Class<S.c> r10 = S.c.class
            r9.<init>(r10)
            S.c[] r10 = S.c.values()
            int r12 = r10.length
            r13 = 0
        L_0x00f3:
            java.lang.String r14 = "g"
            if (r13 >= r12) goto L_0x0151
            r15 = r10[r13]
            S.c r1 = S.c.CHARACTER_SET
            if (r15 == r1) goto L_0x0105
            S.c r1 = S.c.NEED_RESULT_POINT_CALLBACK
            if (r15 == r1) goto L_0x0105
            S.c r1 = S.c.POSSIBLE_FORMATS
            if (r15 != r1) goto L_0x0108
        L_0x0105:
            r16 = r3
            goto L_0x014b
        L_0x0108:
            java.lang.String r1 = r15.name()
            boolean r16 = r8.containsKey(r1)
            if (r16 == 0) goto L_0x0105
            r16 = r3
            java.lang.Class r3 = r15.f247a
            java.lang.Class<java.lang.Void> r2 = java.lang.Void.class
            boolean r2 = r3.equals(r2)
            if (r2 == 0) goto L_0x0124
            java.lang.Boolean r1 = java.lang.Boolean.TRUE
            r9.put(r15, r1)
            goto L_0x014b
        L_0x0124:
            java.lang.Object r1 = r8.get(r1)
            boolean r2 = r3.isInstance(r1)
            if (r2 == 0) goto L_0x0132
            r9.put(r15, r1)
            goto L_0x014b
        L_0x0132:
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            java.lang.String r3 = "Ignoring hint "
            r2.<init>(r3)
            r2.append(r15)
            java.lang.String r3 = " because it is not assignable from "
            r2.append(r3)
            r2.append(r1)
            java.lang.String r1 = r2.toString()
            android.util.Log.w(r14, r1)
        L_0x014b:
            int r13 = r13 + 1
            r3 = r16
            r1 = 2
            goto L_0x00f3
        L_0x0151:
            r16 = r3
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            java.lang.String r2 = "Hints from the Intent: "
            r1.<init>(r2)
            r1.append(r9)
            java.lang.String r1 = r1.toString()
            android.util.Log.i(r14, r1)
        L_0x0164:
            u0.g r1 = new u0.g
            r1.<init>()
            java.lang.String r2 = "SCAN_CAMERA_ID"
            boolean r3 = r6.hasExtra(r2)
            if (r3 == 0) goto L_0x0179
            int r2 = r6.getIntExtra(r2, r7)
            if (r2 < 0) goto L_0x0179
            r1.f1879a = r2
        L_0x0179:
            java.lang.String r2 = "PROMPT_MESSAGE"
            java.lang.String r2 = r6.getStringExtra(r2)
            if (r2 == 0) goto L_0x0184
            r5.setStatusText(r2)
        L_0x0184:
            java.lang.String r2 = "SCAN_TYPE"
            r3 = 0
            int r2 = r6.getIntExtra(r2, r3)
            java.lang.String r3 = "CHARACTER_SET"
            java.lang.String r3 = r6.getStringExtra(r3)
            S.g r7 = new S.g
            r7.<init>()
            r7.d(r9)
            com.journeyapps.barcodescanner.BarcodeView r7 = r5.f790a
            r7.setCameraSettings(r1)
            com.journeyapps.barcodescanner.BarcodeView r1 = r5.f790a
            n0.e r5 = new n0.e
            r7 = r16
            r5.<init>(r7)
            r5.f1657c = r11
            r5.f1658d = r9
            r5.f1659e = r3
            r5.b = r2
            r1.setDecoderFactory(r5)
            goto L_0x01b4
        L_0x01b3:
            r7 = r3
        L_0x01b4:
            java.lang.String r1 = "BEEP_ENABLED"
            boolean r1 = r6.getBooleanExtra(r1, r7)
            if (r1 != 0) goto L_0x01c1
            W.e r1 = r4.f1821g
            r3 = 0
            r1.f290a = r3
        L_0x01c1:
            java.lang.String r1 = "TIMEOUT"
            boolean r2 = r6.hasExtra(r1)
            if (r2 == 0) goto L_0x01d9
            t0.g r2 = new t0.g
            r2.<init>(r4, r7)
            android.os.Handler r3 = r4.f1822h
            r8 = 0
            long r8 = r6.getLongExtra(r1, r8)
            r3.postDelayed(r2, r8)
        L_0x01d9:
            java.lang.String r1 = "BARCODE_IMAGE_ENABLED"
            r3 = 0
            boolean r1 = r6.getBooleanExtra(r1, r3)
            if (r1 == 0) goto L_0x01e4
            r4.f1819d = r7
        L_0x01e4:
            t0.j r1 = r0.f789a
            C.j r2 = r1.f1824j
            com.journeyapps.barcodescanner.DecoratedBarcodeView r1 = r1.b
            com.journeyapps.barcodescanner.BarcodeView r3 = r1.f790a
            G.a r4 = new G.a
            r5 = 13
            r6 = 0
            r4.<init>(r1, r2, r5, r6)
            r1 = 2
            r3.f784A = r1
            r3.f785B = r4
            r3.h()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.journeyapps.barcodescanner.CaptureActivity.onCreate(android.os.Bundle):void");
    }

    public final void onDestroy() {
        super.onDestroy();
        j jVar = this.f789a;
        jVar.f1820e = true;
        jVar.f.a();
        jVar.f1822h.removeCallbacksAndMessages((Object) null);
    }

    public final boolean onKeyDown(int i2, KeyEvent keyEvent) {
        if (this.b.onKeyDown(i2, keyEvent) || super.onKeyDown(i2, keyEvent)) {
            return true;
        }
        return false;
    }

    public final void onPause() {
        super.onPause();
        j jVar = this.f789a;
        jVar.f.a();
        BarcodeView barcodeView = jVar.b.f790a;
        d cameraInstance = barcodeView.getCameraInstance();
        barcodeView.g();
        long nanoTime = System.nanoTime();
        while (cameraInstance != null && !cameraInstance.f1860g && System.nanoTime() - nanoTime <= 2000000000) {
            try {
                Thread.sleep(1);
            } catch (InterruptedException unused) {
                return;
            }
        }
    }

    public final void onRequestPermissionsResult(int i2, String[] strArr, int[] iArr) {
        j jVar = this.f789a;
        jVar.getClass();
        if (i2 != 250) {
            return;
        }
        if (iArr.length <= 0 || iArr[0] != 0) {
            jVar.b();
        } else {
            jVar.b.f790a.c();
        }
    }

    public final void onResume() {
        super.onResume();
        j jVar = this.f789a;
        CaptureActivity captureActivity = jVar.f1817a;
        if (e.a(captureActivity, "android.permission.CAMERA") == 0) {
            jVar.b.f790a.c();
        } else if (!jVar.f1825k) {
            e.g(captureActivity, new String[]{"android.permission.CAMERA"}, 250);
            jVar.f1825k = true;
        }
        i iVar = jVar.f;
        if (!iVar.f295c) {
            iVar.f294a.registerReceiver(iVar.b, new IntentFilter("android.intent.action.BATTERY_CHANGED"));
            iVar.f295c = true;
        }
        iVar.f296d.removeCallbacksAndMessages((Object) null);
        if (iVar.f) {
            iVar.f296d.postDelayed(iVar.f297e, 300000);
        }
    }

    public final void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        bundle.putInt("SAVED_ORIENTATION_LOCK", this.f789a.f1818c);
    }
}
