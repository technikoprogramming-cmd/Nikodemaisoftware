package com.journeyapps.barcodescanner;

import G.a;
import S.c;
import android.content.Context;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.AttributeSet;
import android.util.Log;
import android.view.SurfaceView;
import android.view.TextureView;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.Set;
import n0.e;
import ncs.nikodemai.ntabium.polskieoprogramowanie.R;
import t0.b;
import t0.f;
import t0.k;
import t0.l;
import t0.o;
import t0.s;
import u0.d;

public class BarcodeView extends f {

    /* renamed from: A  reason: collision with root package name */
    public int f784A = 1;

    /* renamed from: B  reason: collision with root package name */
    public a f785B = null;

    /* renamed from: C  reason: collision with root package name */
    public o f786C;

    /* renamed from: D  reason: collision with root package name */
    public l f787D;

    /* renamed from: E  reason: collision with root package name */
    public final Handler f788E;

    public BarcodeView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        b bVar = new b(this, 0);
        this.f787D = new e(1);
        this.f788E = new Handler(bVar);
    }

    /* JADX WARNING: type inference failed for: r0v1, types: [java.lang.Object, t0.m] */
    /* JADX WARNING: type inference failed for: r1v7, types: [java.lang.Object, S.g] */
    /* JADX WARNING: type inference failed for: r2v7, types: [t0.r, t0.k] */
    public final k f() {
        k kVar;
        if (this.f787D == null) {
            this.f787D = new e(1);
        }
        ? obj = new Object();
        HashMap hashMap = new HashMap();
        hashMap.put(c.NEED_RESULT_POINT_CALLBACK, obj);
        e eVar = (e) this.f787D;
        eVar.getClass();
        EnumMap enumMap = new EnumMap(c.class);
        enumMap.putAll(hashMap);
        EnumMap enumMap2 = (EnumMap) eVar.f1658d;
        if (enumMap2 != null) {
            enumMap.putAll(enumMap2);
        }
        Set set = (Set) eVar.f1657c;
        if (set != null) {
            enumMap.put(c.POSSIBLE_FORMATS, set);
        }
        String str = (String) eVar.f1659e;
        if (str != null) {
            enumMap.put(c.CHARACTER_SET, str);
        }
        ? obj2 = new Object();
        obj2.d(enumMap);
        int i2 = eVar.b;
        if (i2 == 0) {
            kVar = new k(obj2);
        } else if (i2 == 1) {
            kVar = new k(obj2);
        } else if (i2 != 2) {
            kVar = new k(obj2);
        } else {
            ? kVar2 = new k(obj2);
            kVar2.f1837c = true;
            kVar = kVar2;
        }
        obj.f1827a = kVar;
        return kVar;
    }

    public final void g() {
        TextureView textureView;
        SurfaceView surfaceView;
        i();
        B0.a.X();
        Log.d("f", "pause()");
        this.f1796i = -1;
        d dVar = this.f1790a;
        if (dVar != null) {
            B0.a.X();
            if (dVar.f) {
                dVar.f1856a.c(dVar.f1865l);
            } else {
                dVar.f1860g = true;
            }
            dVar.f = false;
            this.f1790a = null;
            this.f1794g = false;
        } else {
            this.f1791c.sendEmptyMessage(R.id.zxing_camera_closed);
        }
        if (this.f1803p == null && (surfaceView = this.f1793e) != null) {
            surfaceView.getHolder().removeCallback(this.f1810w);
        }
        if (this.f1803p == null && (textureView = this.f) != null) {
            textureView.setSurfaceTextureListener((TextureView.SurfaceTextureListener) null);
        }
        this.f1800m = null;
        this.f1801n = null;
        this.f1805r = null;
        e eVar = this.f1795h;
        s sVar = (s) eVar.f1658d;
        if (sVar != null) {
            sVar.disable();
        }
        eVar.f1658d = null;
        eVar.f1657c = null;
        eVar.f1659e = null;
        this.f1812y.j();
    }

    public l getDecoderFactory() {
        return this.f787D;
    }

    public final void h() {
        i();
        if (this.f784A != 1 && this.f1794g) {
            o oVar = new o(getCameraInstance(), f(), this.f788E);
            this.f786C = oVar;
            oVar.f = getPreviewFramingRect();
            o oVar2 = this.f786C;
            oVar2.getClass();
            B0.a.X();
            HandlerThread handlerThread = new HandlerThread("o");
            oVar2.b = handlerThread;
            handlerThread.start();
            oVar2.f1830c = new Handler(oVar2.b.getLooper(), oVar2.f1835i);
            oVar2.f1833g = true;
            d dVar = oVar2.f1829a;
            dVar.f1861h.post(new Q.c(dVar, 5, oVar2.f1836j));
        }
    }

    public final void i() {
        o oVar = this.f786C;
        if (oVar != null) {
            oVar.getClass();
            B0.a.X();
            synchronized (oVar.f1834h) {
                oVar.f1833g = false;
                oVar.f1830c.removeCallbacksAndMessages((Object) null);
                oVar.b.quit();
            }
            this.f786C = null;
        }
    }

    public void setDecoderFactory(l lVar) {
        B0.a.X();
        this.f787D = lVar;
        o oVar = this.f786C;
        if (oVar != null) {
            oVar.f1831d = f();
        }
    }
}
