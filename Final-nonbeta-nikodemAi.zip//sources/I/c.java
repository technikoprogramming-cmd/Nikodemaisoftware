package I;

public final class c extends b {
}
