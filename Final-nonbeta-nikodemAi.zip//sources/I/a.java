package I;

public final class a extends b {
    public static final a b = new b();
}
