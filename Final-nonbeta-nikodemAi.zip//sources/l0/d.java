package l0;

import C.h;
import Z.a;
import e.x;

public abstract class d extends x {
    public final void j(StringBuilder sb, int i2) {
        sb.append("(01)");
        int length = sb.length();
        sb.append('9');
        k(sb, i2, length);
    }

    public final void k(StringBuilder sb, int i2, int i3) {
        int i4 = 0;
        for (int i5 = 0; i5 < 4; i5++) {
            int i6 = h.i((i5 * 10) + i2, 10, (a) ((h) this.b).f15a);
            if (i6 / 100 == 0) {
                sb.append('0');
            }
            if (i6 / 10 == 0) {
                sb.append('0');
            }
            sb.append(i6);
        }
        int i7 = 0;
        for (int i8 = 0; i8 < 13; i8++) {
            int charAt = sb.charAt(i8 + i3) - '0';
            if ((i8 & 1) == 0) {
                charAt *= 3;
            }
            i7 += charAt;
        }
        int i9 = 10 - (i7 % 10);
        if (i9 != 10) {
            i4 = i9;
        }
        sb.append(i4);
    }
}
