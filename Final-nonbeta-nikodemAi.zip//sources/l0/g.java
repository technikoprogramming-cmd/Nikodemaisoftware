package l0;

public final class g extends j {
    public final char b;

    public g(char c2, int i2) {
        super(i2);
        this.b = c2;
    }
}
