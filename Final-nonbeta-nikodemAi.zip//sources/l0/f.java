package l0;

import C.h;
import e.x;

public final class f extends x {
    public final String h() {
        return ((h) this.b).f(new StringBuilder(), 5);
    }
}
