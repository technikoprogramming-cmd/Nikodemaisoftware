package l0;

import S.h;

public final class a extends e {

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ int f1610c;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public /* synthetic */ a(Z.a aVar, int i2) {
        super(aVar);
        this.f1610c = i2;
    }

    public final String h() {
        if (((Z.a) this.f1000a).b == 60) {
            StringBuilder sb = new StringBuilder();
            j(sb, 5);
            n(sb, 45, 15);
            return sb.toString();
        }
        throw h.f252c;
    }

    public final void l(StringBuilder sb, int i2) {
        switch (this.f1610c) {
            case 0:
                sb.append("(3103)");
                return;
            default:
                if (i2 < 10000) {
                    sb.append("(3202)");
                    return;
                } else {
                    sb.append("(3203)");
                    return;
                }
        }
    }

    public final int m(int i2) {
        switch (this.f1610c) {
            case 0:
                return i2;
            default:
                return i2 < 10000 ? i2 : i2 - 10000;
        }
    }
}
