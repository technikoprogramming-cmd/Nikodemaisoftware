package l0;

public abstract class j {

    /* renamed from: a  reason: collision with root package name */
    public final int f1617a;

    public j(int i2) {
        this.f1617a = i2;
    }
}
