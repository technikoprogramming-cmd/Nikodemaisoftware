package l0;

import C.h;
import Z.a;

public abstract class e extends d {
    public abstract void l(StringBuilder sb, int i2);

    public abstract int m(int i2);

    public final void n(StringBuilder sb, int i2, int i3) {
        int i4 = h.i(i2, i3, (a) ((h) this.b).f15a);
        l(sb, i4);
        int m2 = m(i4);
        int i5 = 100000;
        for (int i6 = 0; i6 < 5; i6++) {
            if (m2 / i5 == 0) {
                sb.append('0');
            }
            i5 /= 10;
        }
        sb.append(m2);
    }
}
