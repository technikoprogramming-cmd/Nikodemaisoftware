package l0;

import C.h;
import Z.a;

public final class c extends e {

    /* renamed from: c  reason: collision with root package name */
    public final String f1612c;

    /* renamed from: d  reason: collision with root package name */
    public final String f1613d;

    public c(a aVar, String str, String str2) {
        super(aVar);
        this.f1612c = str2;
        this.f1613d = str;
    }

    public final String h() {
        if (((a) this.f1000a).b == 84) {
            StringBuilder sb = new StringBuilder();
            j(sb, 8);
            n(sb, 48, 20);
            int i2 = h.i(68, 16, (a) ((h) this.b).f15a);
            if (i2 != 38400) {
                sb.append('(');
                sb.append(this.f1612c);
                sb.append(')');
                int i3 = i2 % 32;
                int i4 = i2 / 32;
                int i5 = (i4 % 12) + 1;
                int i6 = i4 / 12;
                if (i6 / 10 == 0) {
                    sb.append('0');
                }
                sb.append(i6);
                if (i5 / 10 == 0) {
                    sb.append('0');
                }
                sb.append(i5);
                if (i3 / 10 == 0) {
                    sb.append('0');
                }
                sb.append(i3);
            }
            return sb.toString();
        }
        throw S.h.f252c;
    }

    public final void l(StringBuilder sb, int i2) {
        sb.append('(');
        sb.append(this.f1613d);
        sb.append(i2 / 100000);
        sb.append(')');
    }

    public final int m(int i2) {
        return i2 % 100000;
    }
}
