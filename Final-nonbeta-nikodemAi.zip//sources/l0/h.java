package l0;

public final class h extends j {
    public final String b;

    /* renamed from: c  reason: collision with root package name */
    public final int f1614c;

    /* renamed from: d  reason: collision with root package name */
    public final boolean f1615d;

    public h(int i2, String str) {
        super(i2);
        this.b = str;
        this.f1615d = false;
        this.f1614c = 0;
    }

    public h(int i2, int i3, String str) {
        super(i2);
        this.f1615d = true;
        this.f1614c = i3;
        this.b = str;
    }
}
