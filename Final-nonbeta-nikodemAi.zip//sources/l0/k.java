package l0;

import S.h;

public abstract class k {

    /* renamed from: a  reason: collision with root package name */
    public static final Object f1618a;
    public static final Object[][] b;

    /* renamed from: c  reason: collision with root package name */
    public static final Object[][] f1619c;

    /* renamed from: d  reason: collision with root package name */
    public static final Object[][] f1620d;

    /* renamed from: e  reason: collision with root package name */
    public static final Object[][] f1621e;

    static {
        Object obj = new Object();
        f1618a = obj;
        Object[] objArr = {"94", obj, 30};
        Object[] objArr2 = {"00", 18};
        Object[] objArr3 = {"10", obj, 20};
        Object[] objArr4 = {"11", 6};
        Object[] objArr5 = {"13", 6};
        Object[] objArr6 = {"17", 6};
        Object[] objArr7 = {"21", obj, 20};
        Object[] objArr8 = {"91", obj, 30};
        Object[] objArr9 = {"01", 14};
        Object[] objArr10 = {"22", obj, 29};
        Object[] objArr11 = {"90", obj, 30};
        Object[] objArr12 = {"92", obj, 30};
        Object[] objArr13 = {"95", obj, 30};
        Object[] objArr14 = {"12", 6};
        Object[] objArr15 = {"15", 6};
        Object[] objArr16 = {"20", 2};
        Object[] objArr17 = {"30", obj, 8};
        Object[] objArr18 = {"93", obj, 30};
        b = new Object[][]{objArr2, objArr9, new Object[]{"02", 14}, objArr3, objArr4, objArr14, objArr5, objArr15, objArr6, objArr16, objArr7, objArr10, objArr17, new Object[]{"37", obj, 8}, objArr11, objArr8, objArr12, objArr18, objArr, objArr13, new Object[]{"96", obj, 30}, new Object[]{"97", obj, 30}, new Object[]{"98", obj, 30}, new Object[]{"99", obj, 30}};
        Object[] objArr19 = {"422", 3};
        Object[] objArr20 = {"240", obj, 30};
        Object[] objArr21 = objArr19;
        Object[] objArr22 = {"400", obj, 30};
        Object[] objArr23 = {"401", obj, 30};
        Object[] objArr24 = {"402", 17};
        Object[] objArr25 = {"241", obj, 30};
        f1619c = new Object[][]{objArr20, objArr25, new Object[]{"242", obj, 6}, new Object[]{"250", obj, 30}, new Object[]{"251", obj, 30}, new Object[]{"253", obj, 17}, new Object[]{"254", obj, 20}, objArr22, objArr23, objArr24, new Object[]{"403", obj, 30}, new Object[]{"410", 13}, new Object[]{"411", 13}, new Object[]{"412", 13}, new Object[]{"413", 13}, new Object[]{"414", 13}, new Object[]{"420", obj, 20}, new Object[]{"421", obj, 15}, objArr21, new Object[]{"423", obj, 15}, new Object[]{"424", 3}, new Object[]{"425", 3}, new Object[]{"426", 3}};
        f1620d = new Object[][]{new Object[]{"310", 6}, new Object[]{"311", 6}, new Object[]{"312", 6}, new Object[]{"313", 6}, new Object[]{"314", 6}, new Object[]{"315", 6}, new Object[]{"316", 6}, new Object[]{"320", 6}, new Object[]{"321", 6}, new Object[]{"322", 6}, new Object[]{"323", 6}, new Object[]{"324", 6}, new Object[]{"325", 6}, new Object[]{"326", 6}, new Object[]{"327", 6}, new Object[]{"328", 6}, new Object[]{"329", 6}, new Object[]{"330", 6}, new Object[]{"331", 6}, new Object[]{"332", 6}, new Object[]{"333", 6}, new Object[]{"334", 6}, new Object[]{"335", 6}, new Object[]{"336", 6}, new Object[]{"340", 6}, new Object[]{"341", 6}, new Object[]{"342", 6}, new Object[]{"343", 6}, new Object[]{"344", 6}, new Object[]{"345", 6}, new Object[]{"346", 6}, new Object[]{"347", 6}, new Object[]{"348", 6}, new Object[]{"349", 6}, new Object[]{"350", 6}, new Object[]{"351", 6}, new Object[]{"352", 6}, new Object[]{"353", 6}, new Object[]{"354", 6}, new Object[]{"355", 6}, new Object[]{"356", 6}, new Object[]{"357", 6}, new Object[]{"360", 6}, new Object[]{"361", 6}, new Object[]{"362", 6}, new Object[]{"363", 6}, new Object[]{"364", 6}, new Object[]{"365", 6}, new Object[]{"366", 6}, new Object[]{"367", 6}, new Object[]{"368", 6}, new Object[]{"369", 6}, new Object[]{"390", obj, 15}, new Object[]{"391", obj, 18}, new Object[]{"392", obj, 15}, new Object[]{"393", obj, 18}, new Object[]{"703", obj, 30}};
        f1621e = new Object[][]{new Object[]{"7001", 13}, new Object[]{"7002", obj, 30}, new Object[]{"7003", 10}, new Object[]{"8001", 14}, new Object[]{"8002", obj, 20}, new Object[]{"8003", obj, 30}, new Object[]{"8004", obj, 30}, new Object[]{"8005", 6}, new Object[]{"8006", 18}, new Object[]{"8007", obj, 30}, new Object[]{"8008", obj, 12}, new Object[]{"8018", 18}, new Object[]{"8020", obj, 25}, new Object[]{"8100", 6}, new Object[]{"8101", 10}, new Object[]{"8102", 2}, new Object[]{"8110", obj, 70}, new Object[]{"8200", obj, 70}};
    }

    public static String a(String str) {
        if (str.isEmpty()) {
            return null;
        }
        if (str.length() >= 2) {
            String substring = str.substring(0, 2);
            Object[][] objArr = b;
            int i2 = 0;
            while (true) {
                Object obj = f1618a;
                if (i2 < 24) {
                    Object[] objArr2 = objArr[i2];
                    if (objArr2[0].equals(substring)) {
                        Object obj2 = objArr2[1];
                        if (obj2 == obj) {
                            return c(2, ((Integer) objArr2[2]).intValue(), str);
                        }
                        return b(2, ((Integer) obj2).intValue(), str);
                    }
                    i2++;
                } else if (str.length() >= 3) {
                    String substring2 = str.substring(0, 3);
                    Object[][] objArr3 = f1619c;
                    for (int i3 = 0; i3 < 23; i3++) {
                        Object[] objArr4 = objArr3[i3];
                        if (objArr4[0].equals(substring2)) {
                            Object obj3 = objArr4[1];
                            if (obj3 == obj) {
                                return c(3, ((Integer) objArr4[2]).intValue(), str);
                            }
                            return b(3, ((Integer) obj3).intValue(), str);
                        }
                    }
                    Object[][] objArr5 = f1620d;
                    for (int i4 = 0; i4 < 57; i4++) {
                        Object[] objArr6 = objArr5[i4];
                        if (objArr6[0].equals(substring2)) {
                            Object obj4 = objArr6[1];
                            if (obj4 == obj) {
                                return c(4, ((Integer) objArr6[2]).intValue(), str);
                            }
                            return b(4, ((Integer) obj4).intValue(), str);
                        }
                    }
                    if (str.length() >= 4) {
                        String substring3 = str.substring(0, 4);
                        Object[][] objArr7 = f1621e;
                        for (int i5 = 0; i5 < 18; i5++) {
                            Object[] objArr8 = objArr7[i5];
                            if (objArr8[0].equals(substring3)) {
                                Object obj5 = objArr8[1];
                                if (obj5 == obj) {
                                    return c(4, ((Integer) objArr8[2]).intValue(), str);
                                }
                                return b(4, ((Integer) obj5).intValue(), str);
                            }
                        }
                        throw h.f252c;
                    }
                    throw h.f252c;
                } else {
                    throw h.f252c;
                }
            }
        } else {
            throw h.f252c;
        }
    }

    public static String b(int i2, int i3, String str) {
        if (str.length() >= i2) {
            String substring = str.substring(0, i2);
            int i4 = i3 + i2;
            if (str.length() >= i4) {
                String substring2 = str.substring(i2, i4);
                String str2 = "(" + substring + ')' + substring2;
                String a2 = a(str.substring(i4));
                if (a2 == null) {
                    return str2;
                }
                return str2 + a2;
            }
            throw h.f252c;
        }
        throw h.f252c;
    }

    public static String c(int i2, int i3, String str) {
        String substring = str.substring(0, i2);
        int i4 = i3 + i2;
        if (str.length() < i4) {
            i4 = str.length();
        }
        String substring2 = str.substring(i2, i4);
        String str2 = "(" + substring + ')' + substring2;
        String a2 = a(str.substring(i4));
        if (a2 == null) {
            return str2;
        }
        return str2 + a2;
    }
}
