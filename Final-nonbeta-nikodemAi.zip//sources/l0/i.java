package l0;

import S.d;

public final class i extends j {
    public final int b;

    /* renamed from: c  reason: collision with root package name */
    public final int f1616c;

    public i(int i2, int i3, int i4) {
        super(i2);
        if (i3 < 0 || i3 > 10 || i4 < 0 || i4 > 10) {
            throw d.a();
        }
        this.b = i3;
        this.f1616c = i4;
    }
}
