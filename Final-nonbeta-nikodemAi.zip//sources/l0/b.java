package l0;

import C.h;
import Z.a;

public final class b extends d {

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ int f1611c;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public /* synthetic */ b(a aVar, int i2) {
        super(aVar);
        this.f1611c = i2;
    }

    public final String h() {
        switch (this.f1611c) {
            case 0:
                if (((a) this.f1000a).b >= 48) {
                    StringBuilder sb = new StringBuilder();
                    j(sb, 8);
                    h hVar = (h) this.b;
                    int i2 = h.i(48, 2, (a) hVar.f15a);
                    sb.append("(392");
                    sb.append(i2);
                    sb.append(')');
                    sb.append(hVar.g(50, (String) null).b);
                    return sb.toString();
                }
                throw S.h.f252c;
            case 1:
                if (((a) this.f1000a).b >= 48) {
                    StringBuilder sb2 = new StringBuilder();
                    j(sb2, 8);
                    h hVar2 = (h) this.b;
                    int i3 = h.i(48, 2, (a) hVar2.f15a);
                    sb2.append("(393");
                    sb2.append(i3);
                    sb2.append(')');
                    int i4 = h.i(50, 10, (a) hVar2.f15a);
                    if (i4 / 100 == 0) {
                        sb2.append('0');
                    }
                    if (i4 / 10 == 0) {
                        sb2.append('0');
                    }
                    sb2.append(i4);
                    sb2.append(hVar2.g(60, (String) null).b);
                    return sb2.toString();
                }
                throw S.h.f252c;
            default:
                StringBuilder sb3 = new StringBuilder();
                sb3.append("(01)");
                int length = sb3.length();
                h hVar3 = (h) this.b;
                sb3.append(h.i(4, 4, (a) hVar3.f15a));
                k(sb3, 8, length);
                return hVar3.f(sb3, 48);
        }
    }
}
