package b0;

import G.a;

/* renamed from: b0.a  reason: case insensitive filesystem */
public final class C0009a {

    /* renamed from: h  reason: collision with root package name */
    public static final C0009a f770h = new C0009a(4201, 4096, 1);

    /* renamed from: i  reason: collision with root package name */
    public static final C0009a f771i = new C0009a(1033, 1024, 1);

    /* renamed from: j  reason: collision with root package name */
    public static final C0009a f772j;

    /* renamed from: k  reason: collision with root package name */
    public static final C0009a f773k = new C0009a(19, 16, 1);

    /* renamed from: l  reason: collision with root package name */
    public static final C0009a f774l = new C0009a(285, 256, 0);

    /* renamed from: m  reason: collision with root package name */
    public static final C0009a f775m;

    /* renamed from: n  reason: collision with root package name */
    public static final C0009a f776n;

    /* renamed from: o  reason: collision with root package name */
    public static final C0009a f777o;

    /* renamed from: a  reason: collision with root package name */
    public final int[] f778a;
    public final int[] b;

    /* renamed from: c  reason: collision with root package name */
    public final a f779c;

    /* renamed from: d  reason: collision with root package name */
    public final a f780d;

    /* renamed from: e  reason: collision with root package name */
    public final int f781e;
    public final int f;

    /* renamed from: g  reason: collision with root package name */
    public final int f782g;

    static {
        C0009a aVar = new C0009a(67, 64, 1);
        f772j = aVar;
        C0009a aVar2 = new C0009a(301, 256, 1);
        f775m = aVar2;
        f776n = aVar2;
        f777o = aVar;
    }

    public C0009a(int i2, int i3, int i4) {
        this.f = i2;
        this.f781e = i3;
        this.f782g = i4;
        this.f778a = new int[i3];
        this.b = new int[i3];
        int i5 = 1;
        for (int i6 = 0; i6 < i3; i6++) {
            this.f778a[i6] = i5;
            i5 <<= 1;
            if (i5 >= i3) {
                i5 = (i5 ^ i2) & (i3 - 1);
            }
        }
        for (int i7 = 0; i7 < i3 - 1; i7++) {
            this.b[this.f778a[i7]] = i7;
        }
        this.f779c = new a(this, new int[]{0});
        this.f780d = new a(this, new int[]{1});
    }

    public final int a(int i2) {
        if (i2 != 0) {
            int i3 = this.b[i2];
            return this.f778a[(this.f781e - i3) - 1];
        }
        throw new ArithmeticException();
    }

    public final int b(int i2, int i3) {
        if (i2 == 0 || i3 == 0) {
            return 0;
        }
        int[] iArr = this.b;
        return this.f778a[(iArr[i2] + iArr[i3]) % (this.f781e - 1)];
    }

    public final String toString() {
        return "GF(0x" + Integer.toHexString(this.f) + ',' + this.f781e + ')';
    }
}
