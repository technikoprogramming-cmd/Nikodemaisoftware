package G0;

public interface a {
}
