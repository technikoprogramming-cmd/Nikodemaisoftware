package y;

import android.graphics.Rect;
import android.os.Build;
import android.util.Log;
import android.view.View;
import android.view.WindowInsets;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Objects;
import r.C0158c;

public abstract class X extends c0 {

    /* renamed from: h  reason: collision with root package name */
    public static boolean f1964h = false;

    /* renamed from: i  reason: collision with root package name */
    public static Method f1965i;

    /* renamed from: j  reason: collision with root package name */
    public static Class f1966j;

    /* renamed from: k  reason: collision with root package name */
    public static Field f1967k;

    /* renamed from: l  reason: collision with root package name */
    public static Field f1968l;

    /* renamed from: c  reason: collision with root package name */
    public final WindowInsets f1969c;

    /* renamed from: d  reason: collision with root package name */
    public C0158c[] f1970d;

    /* renamed from: e  reason: collision with root package name */
    public C0158c f1971e = null;
    public e0 f;

    /* renamed from: g  reason: collision with root package name */
    public C0158c f1972g;

    public X(e0 e0Var, WindowInsets windowInsets) {
        super(e0Var);
        this.f1969c = windowInsets;
    }

    private C0158c r(int i2, boolean z2) {
        C0158c cVar = C0158c.f1729e;
        for (int i3 = 1; i3 <= 256; i3 <<= 1) {
            if ((i2 & i3) != 0) {
                C0158c s2 = s(i3, z2);
                cVar = C0158c.a(Math.max(cVar.f1730a, s2.f1730a), Math.max(cVar.b, s2.b), Math.max(cVar.f1731c, s2.f1731c), Math.max(cVar.f1732d, s2.f1732d));
            }
        }
        return cVar;
    }

    private C0158c t() {
        e0 e0Var = this.f;
        if (e0Var != null) {
            return e0Var.f1986a.h();
        }
        return C0158c.f1729e;
    }

    private C0158c u(View view) {
        if (Build.VERSION.SDK_INT < 30) {
            if (!f1964h) {
                v();
            }
            Method method = f1965i;
            if (!(method == null || f1966j == null || f1967k == null)) {
                try {
                    Object invoke = method.invoke(view, (Object[]) null);
                    if (invoke == null) {
                        Log.w("WindowInsetsCompat", "Failed to get visible insets. getViewRootImpl() returned null from the provided view. This means that the view is either not attached or the method has been overridden", new NullPointerException());
                        return null;
                    }
                    Rect rect = (Rect) f1967k.get(f1968l.get(invoke));
                    if (rect != null) {
                        return C0158c.a(rect.left, rect.top, rect.right, rect.bottom);
                    }
                } catch (ReflectiveOperationException e2) {
                    Log.e("WindowInsetsCompat", "Failed to get visible insets. (Reflection error). " + e2.getMessage(), e2);
                }
            }
            return null;
        }
        throw new UnsupportedOperationException("getVisibleInsets() should not be called on API >= 30. Use WindowInsets.isVisible() instead.");
    }

    private static void v() {
        try {
            f1965i = View.class.getDeclaredMethod("getViewRootImpl", (Class[]) null);
            Class<?> cls = Class.forName("android.view.View$AttachInfo");
            f1966j = cls;
            f1967k = cls.getDeclaredField("mVisibleInsets");
            f1968l = Class.forName("android.view.ViewRootImpl").getDeclaredField("mAttachInfo");
            f1967k.setAccessible(true);
            f1968l.setAccessible(true);
        } catch (ReflectiveOperationException e2) {
            Log.e("WindowInsetsCompat", "Failed to get visible insets. (Reflection error). " + e2.getMessage(), e2);
        }
        f1964h = true;
    }

    public void d(View view) {
        C0158c u2 = u(view);
        if (u2 == null) {
            u2 = C0158c.f1729e;
        }
        w(u2);
    }

    public boolean equals(Object obj) {
        if (!super.equals(obj)) {
            return false;
        }
        return Objects.equals(this.f1972g, ((X) obj).f1972g);
    }

    public C0158c f(int i2) {
        return r(i2, false);
    }

    public final C0158c j() {
        if (this.f1971e == null) {
            WindowInsets windowInsets = this.f1969c;
            this.f1971e = C0158c.a(windowInsets.getSystemWindowInsetLeft(), windowInsets.getSystemWindowInsetTop(), windowInsets.getSystemWindowInsetRight(), windowInsets.getSystemWindowInsetBottom());
        }
        return this.f1971e;
    }

    public e0 l(int i2, int i3, int i4, int i5) {
        W w2;
        e0 c2 = e0.c(this.f1969c, (View) null);
        int i6 = Build.VERSION.SDK_INT;
        if (i6 >= 30) {
            w2 = new V(c2);
        } else if (i6 >= 29) {
            w2 = new U(c2);
        } else {
            w2 = new T(c2);
        }
        w2.d(e0.a(j(), i2, i3, i4, i5));
        w2.c(e0.a(h(), i2, i3, i4, i5));
        return w2.b();
    }

    public boolean n() {
        return this.f1969c.isRound();
    }

    public void o(C0158c[] cVarArr) {
        this.f1970d = cVarArr;
    }

    public void p(e0 e0Var) {
        this.f = e0Var;
    }

    public C0158c s(int i2, boolean z2) {
        int i3;
        C0185j jVar;
        int i4;
        int i5;
        int i6;
        int i7 = 0;
        if (i2 != 1) {
            C0158c cVar = null;
            if (i2 != 2) {
                C0158c cVar2 = C0158c.f1729e;
                if (i2 == 8) {
                    C0158c[] cVarArr = this.f1970d;
                    if (cVarArr != null) {
                        cVar = cVarArr[3];
                    }
                    if (cVar != null) {
                        return cVar;
                    }
                    C0158c j2 = j();
                    C0158c t2 = t();
                    int i8 = j2.f1732d;
                    if (i8 > t2.f1732d) {
                        return C0158c.a(0, 0, 0, i8);
                    }
                    C0158c cVar3 = this.f1972g;
                    if (cVar3 != null && !cVar3.equals(cVar2) && (i3 = this.f1972g.f1732d) > t2.f1732d) {
                        return C0158c.a(0, 0, 0, i3);
                    }
                } else if (i2 == 16) {
                    return i();
                } else {
                    if (i2 == 32) {
                        return g();
                    }
                    if (i2 == 64) {
                        return k();
                    }
                    if (i2 == 128) {
                        e0 e0Var = this.f;
                        if (e0Var != null) {
                            jVar = e0Var.f1986a.e();
                        } else {
                            jVar = e();
                        }
                        if (jVar != null) {
                            int i9 = Build.VERSION.SDK_INT;
                            if (i9 >= 28) {
                                i4 = C0184i.d(jVar.f1994a);
                            } else {
                                i4 = 0;
                            }
                            if (i9 >= 28) {
                                i5 = C0184i.f(jVar.f1994a);
                            } else {
                                i5 = 0;
                            }
                            if (i9 >= 28) {
                                i6 = C0184i.e(jVar.f1994a);
                            } else {
                                i6 = 0;
                            }
                            if (i9 >= 28) {
                                i7 = C0184i.c(jVar.f1994a);
                            }
                            return C0158c.a(i4, i5, i6, i7);
                        }
                    }
                }
                return cVar2;
            } else if (z2) {
                C0158c t3 = t();
                C0158c h2 = h();
                return C0158c.a(Math.max(t3.f1730a, h2.f1730a), 0, Math.max(t3.f1731c, h2.f1731c), Math.max(t3.f1732d, h2.f1732d));
            } else {
                C0158c j3 = j();
                e0 e0Var2 = this.f;
                if (e0Var2 != null) {
                    cVar = e0Var2.f1986a.h();
                }
                int i10 = j3.f1732d;
                if (cVar != null) {
                    i10 = Math.min(i10, cVar.f1732d);
                }
                return C0158c.a(j3.f1730a, 0, j3.f1731c, i10);
            }
        } else if (z2) {
            return C0158c.a(0, Math.max(t().b, j().b), 0, 0);
        } else {
            return C0158c.a(0, j().b, 0, 0);
        }
    }

    public void w(C0158c cVar) {
        this.f1972g = cVar;
    }
}
