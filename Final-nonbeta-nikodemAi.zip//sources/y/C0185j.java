package y;

import android.view.DisplayCutout;
import java.util.Objects;

/* renamed from: y.j  reason: case insensitive filesystem */
public final class C0185j {

    /* renamed from: a  reason: collision with root package name */
    public final DisplayCutout f1994a;

    public C0185j(DisplayCutout displayCutout) {
        this.f1994a = displayCutout;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || C0185j.class != obj.getClass()) {
            return false;
        }
        return Objects.equals(this.f1994a, ((C0185j) obj).f1994a);
    }

    public final int hashCode() {
        return this.f1994a.hashCode();
    }

    public final String toString() {
        return "DisplayCutoutCompat{" + this.f1994a + "}";
    }
}
