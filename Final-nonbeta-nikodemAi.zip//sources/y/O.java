package y;

import C.j;
import android.animation.ValueAnimator;
import android.view.View;
import e.K;

public final /* synthetic */ class O implements ValueAnimator.AnimatorUpdateListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ j f1954a;

    public /* synthetic */ O(j jVar, View view) {
        this.f1954a = jVar;
    }

    public final void onAnimationUpdate(ValueAnimator valueAnimator) {
        ((View) ((K) this.f1954a.b).f924n.getParent()).invalidate();
    }
}
