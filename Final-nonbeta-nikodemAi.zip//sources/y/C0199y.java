package y;

import android.os.Build;
import android.view.View;
import android.view.WindowInsets;
import java.util.WeakHashMap;

/* renamed from: y.y  reason: case insensitive filesystem */
public final class C0199y implements View.OnApplyWindowInsetsListener {

    /* renamed from: a  reason: collision with root package name */
    public e0 f2002a = null;
    public final /* synthetic */ View b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ C0190o f2003c;

    public C0199y(View view, C0190o oVar) {
        this.b = view;
        this.f2003c = oVar;
    }

    public WindowInsets onApplyWindowInsets(View view, WindowInsets windowInsets) {
        e0 c2 = e0.c(windowInsets, view);
        int i2 = Build.VERSION.SDK_INT;
        C0190o oVar = this.f2003c;
        if (i2 < 30) {
            C0200z.a(windowInsets, this.b);
            if (c2.equals(this.f2002a)) {
                return oVar.a(view, c2).b();
            }
        }
        this.f2002a = c2;
        e0 a2 = oVar.a(view, c2);
        if (i2 >= 30) {
            return a2.b();
        }
        WeakHashMap weakHashMap = J.f1949a;
        C0198x.c(view);
        return a2.b();
    }
}
