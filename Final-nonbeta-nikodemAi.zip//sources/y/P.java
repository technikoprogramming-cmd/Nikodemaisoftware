package y;

import android.animation.Animator;
import android.view.View;
import i.C0063c;
import java.lang.ref.WeakReference;

public final class P {

    /* renamed from: a  reason: collision with root package name */
    public final WeakReference f1955a;

    public P(View view) {
        this.f1955a = new WeakReference(view);
    }

    public final void a(float f) {
        View view = (View) this.f1955a.get();
        if (view != null) {
            view.animate().alpha(f);
        }
    }

    public final void b() {
        View view = (View) this.f1955a.get();
        if (view != null) {
            view.animate().cancel();
        }
    }

    public final void c(long j2) {
        View view = (View) this.f1955a.get();
        if (view != null) {
            view.animate().setDuration(j2);
        }
    }

    public final void d(Q q2) {
        View view = (View) this.f1955a.get();
        if (view == null) {
            return;
        }
        if (q2 != null) {
            view.animate().setListener(new C0063c(q2, view));
        } else {
            view.animate().setListener((Animator.AnimatorListener) null);
        }
    }

    public final void e(float f) {
        View view = (View) this.f1955a.get();
        if (view != null) {
            view.animate().translationY(f);
        }
    }
}
