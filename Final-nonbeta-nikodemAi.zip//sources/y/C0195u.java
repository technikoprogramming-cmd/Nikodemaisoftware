package y;

/* renamed from: y.u  reason: case insensitive filesystem */
public final /* synthetic */ class C0195u implements C0192q {
    public final C0182g a(C0182g gVar) {
        return gVar;
    }
}
