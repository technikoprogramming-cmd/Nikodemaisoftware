package y;

import android.os.Build;
import android.view.View;
import android.view.WindowInsets;
import java.util.Objects;
import java.util.WeakHashMap;
import r.C0158c;

public final class e0 {
    public static final e0 b;

    /* renamed from: a  reason: collision with root package name */
    public final c0 f1986a;

    static {
        if (Build.VERSION.SDK_INT >= 30) {
            b = b0.f1980q;
        } else {
            b = c0.b;
        }
    }

    public e0(WindowInsets windowInsets) {
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 30) {
            this.f1986a = new b0(this, windowInsets);
        } else if (i2 >= 29) {
            this.f1986a = new a0(this, windowInsets);
        } else if (i2 >= 28) {
            this.f1986a = new Z(this, windowInsets);
        } else {
            this.f1986a = new Y(this, windowInsets);
        }
    }

    public static C0158c a(C0158c cVar, int i2, int i3, int i4, int i5) {
        int max = Math.max(0, cVar.f1730a - i2);
        int max2 = Math.max(0, cVar.b - i3);
        int max3 = Math.max(0, cVar.f1731c - i4);
        int max4 = Math.max(0, cVar.f1732d - i5);
        if (max == i2 && max2 == i3 && max3 == i4 && max4 == i5) {
            return cVar;
        }
        return C0158c.a(max, max2, max3, max4);
    }

    public static e0 c(WindowInsets windowInsets, View view) {
        windowInsets.getClass();
        e0 e0Var = new e0(windowInsets);
        if (view != null && view.isAttachedToWindow()) {
            WeakHashMap weakHashMap = J.f1949a;
            e0 a2 = A.a(view);
            c0 c0Var = e0Var.f1986a;
            c0Var.p(a2);
            c0Var.d(view.getRootView());
        }
        return e0Var;
    }

    public final WindowInsets b() {
        c0 c0Var = this.f1986a;
        if (c0Var instanceof X) {
            return ((X) c0Var).f1969c;
        }
        return null;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof e0)) {
            return false;
        }
        return Objects.equals(this.f1986a, ((e0) obj).f1986a);
    }

    public final int hashCode() {
        c0 c0Var = this.f1986a;
        if (c0Var == null) {
            return 0;
        }
        return c0Var.hashCode();
    }

    public e0() {
        this.f1986a = new c0(this);
    }
}
