package y;

public interface Q {
    void a();

    void b();

    void c();
}
