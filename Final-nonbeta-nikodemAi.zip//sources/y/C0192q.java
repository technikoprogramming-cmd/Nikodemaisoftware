package y;

/* renamed from: y.q  reason: case insensitive filesystem */
public interface C0192q {
    C0182g a(C0182g gVar);
}
