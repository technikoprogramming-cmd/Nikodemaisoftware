package y;

import android.os.Build;
import android.view.View;
import java.util.Objects;
import r.C0158c;

public class c0 {
    public static final e0 b;

    /* renamed from: a  reason: collision with root package name */
    public final e0 f1981a;

    static {
        W w2;
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 30) {
            w2 = new V();
        } else if (i2 >= 29) {
            w2 = new U();
        } else {
            w2 = new T();
        }
        b = w2.b().f1986a.a().f1986a.b().f1986a.c();
    }

    public c0(e0 e0Var) {
        this.f1981a = e0Var;
    }

    public e0 a() {
        return this.f1981a;
    }

    public e0 b() {
        return this.f1981a;
    }

    public e0 c() {
        return this.f1981a;
    }

    public C0185j e() {
        return null;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof c0)) {
            return false;
        }
        c0 c0Var = (c0) obj;
        if (n() != c0Var.n() || m() != c0Var.m() || !Objects.equals(j(), c0Var.j()) || !Objects.equals(h(), c0Var.h()) || !Objects.equals(e(), c0Var.e())) {
            return false;
        }
        return true;
    }

    public C0158c f(int i2) {
        return C0158c.f1729e;
    }

    public C0158c g() {
        return j();
    }

    public C0158c h() {
        return C0158c.f1729e;
    }

    public int hashCode() {
        return Objects.hash(new Object[]{Boolean.valueOf(n()), Boolean.valueOf(m()), j(), h(), e()});
    }

    public C0158c i() {
        return j();
    }

    public C0158c j() {
        return C0158c.f1729e;
    }

    public C0158c k() {
        return j();
    }

    public e0 l(int i2, int i3, int i4, int i5) {
        return b;
    }

    public boolean m() {
        return false;
    }

    public boolean n() {
        return false;
    }

    public void d(View view) {
    }

    public void o(C0158c[] cVarArr) {
    }

    public void p(e0 e0Var) {
    }

    public void q(C0158c cVar) {
    }
}
