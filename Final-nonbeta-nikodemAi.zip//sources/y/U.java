package y;

import N.a;
import android.view.View;
import android.view.WindowInsets;
import r.C0158c;

public class U extends W {

    /* renamed from: a  reason: collision with root package name */
    public final WindowInsets.Builder f1963a;

    public U() {
        this.f1963a = a.d();
    }

    public e0 b() {
        a();
        e0 c2 = e0.c(this.f1963a.build(), (View) null);
        c2.f1986a.o((C0158c[]) null);
        return c2;
    }

    public void c(C0158c cVar) {
        this.f1963a.setStableInsets(cVar.c());
    }

    public void d(C0158c cVar) {
        this.f1963a.setSystemWindowInsets(cVar.c());
    }

    public U(e0 e0Var) {
        super(e0Var);
        WindowInsets.Builder builder;
        WindowInsets b = e0Var.b();
        if (b != null) {
            builder = a.e(b);
        } else {
            builder = a.d();
        }
        this.f1963a = builder;
    }
}
