package y;

import android.os.Build;
import android.util.Log;
import android.view.ViewConfiguration;

public abstract class M {

    /* renamed from: a  reason: collision with root package name */
    public static final /* synthetic */ int f1953a = 0;

    static {
        if (Build.VERSION.SDK_INT == 25) {
            try {
                ViewConfiguration.class.getDeclaredMethod("getScaledScrollFactor", (Class[]) null);
            } catch (Exception unused) {
                Log.i("ViewConfigCompat", "Could not find method getScaledScrollFactor() on ViewConfiguration");
            }
        }
    }
}
