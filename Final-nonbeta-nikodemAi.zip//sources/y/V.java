package y;

public final class V extends U {
    public V() {
    }

    public V(e0 e0Var) {
        super(e0Var);
    }
}
