package y;

import android.view.KeyEvent;

/* renamed from: y.k  reason: case insensitive filesystem */
public interface C0186k {
    boolean d(KeyEvent keyEvent);
}
