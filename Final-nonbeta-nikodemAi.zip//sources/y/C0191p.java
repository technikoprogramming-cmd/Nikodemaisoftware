package y;

/* renamed from: y.p  reason: case insensitive filesystem */
public interface C0191p {
}
