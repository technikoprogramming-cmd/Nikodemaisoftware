package y;

/* renamed from: y.g  reason: case insensitive filesystem */
public final class C0182g {

    /* renamed from: a  reason: collision with root package name */
    public final C0181f f1987a;

    public C0182g(C0181f fVar) {
        this.f1987a = fVar;
    }

    public final String toString() {
        return this.f1987a.toString();
    }
}
