package y;

import C.j;
import D.t;
import android.view.ContentInfo;
import android.view.OnReceiveContentListener;
import android.view.View;
import java.util.Objects;

public final class G implements OnReceiveContentListener {

    /* renamed from: a  reason: collision with root package name */
    public final C0191p f1945a;

    public G(C0191p pVar) {
        this.f1945a = pVar;
    }

    public final ContentInfo onReceiveContent(View view, ContentInfo contentInfo) {
        C0182g gVar = new C0182g(new j(contentInfo));
        C0182g a2 = ((t) this.f1945a).a(view, gVar);
        if (a2 == null) {
            return null;
        }
        if (a2 == gVar) {
            return contentInfo;
        }
        ContentInfo r2 = a2.f1987a.r();
        Objects.requireNonNull(r2);
        return C0178c.e(r2);
    }
}
