package y;

import android.view.WindowInsets;

public abstract class d0 {
    public static int a(int i2) {
        int a2;
        int i3 = 0;
        for (int i4 = 1; i4 <= 256; i4 <<= 1) {
            if ((i2 & i4) != 0) {
                if (i4 == 1) {
                    a2 = WindowInsets.Type.statusBars();
                } else if (i4 == 2) {
                    a2 = WindowInsets.Type.navigationBars();
                } else if (i4 == 4) {
                    a2 = WindowInsets.Type.captionBar();
                } else if (i4 == 8) {
                    a2 = WindowInsets.Type.ime();
                } else if (i4 == 16) {
                    a2 = WindowInsets.Type.systemGestures();
                } else if (i4 == 32) {
                    a2 = WindowInsets.Type.mandatorySystemGestures();
                } else if (i4 == 64) {
                    a2 = WindowInsets.Type.tappableElement();
                } else if (i4 == 128) {
                    a2 = WindowInsets.Type.displayCutout();
                }
                i3 |= a2;
            }
        }
        return i3;
    }
}
