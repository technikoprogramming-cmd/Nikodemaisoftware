package y;

import android.view.View;
import android.view.WindowInsets;
import r.C0158c;

public class Y extends X {

    /* renamed from: m  reason: collision with root package name */
    public C0158c f1973m = null;

    public Y(e0 e0Var, WindowInsets windowInsets) {
        super(e0Var, windowInsets);
    }

    public e0 b() {
        return e0.c(this.f1969c.consumeStableInsets(), (View) null);
    }

    public e0 c() {
        return e0.c(this.f1969c.consumeSystemWindowInsets(), (View) null);
    }

    public final C0158c h() {
        if (this.f1973m == null) {
            WindowInsets windowInsets = this.f1969c;
            this.f1973m = C0158c.a(windowInsets.getStableInsetLeft(), windowInsets.getStableInsetTop(), windowInsets.getStableInsetRight(), windowInsets.getStableInsetBottom());
        }
        return this.f1973m;
    }

    public boolean m() {
        return this.f1969c.isConsumed();
    }

    public void q(C0158c cVar) {
        this.f1973m = cVar;
    }
}
