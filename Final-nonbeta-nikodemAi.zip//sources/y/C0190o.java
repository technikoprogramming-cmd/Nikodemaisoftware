package y;

import android.view.View;

/* renamed from: y.o  reason: case insensitive filesystem */
public interface C0190o {
    e0 a(View view, e0 e0Var);
}
