package y;

import C.j;
import android.view.ContentInfo;
import android.view.OnReceiveContentListener;
import android.view.View;
import java.util.Objects;

public abstract class F {
    public static String[] a(View view) {
        return view.getReceiveContentMimeTypes();
    }

    public static C0182g b(View view, C0182g gVar) {
        ContentInfo r2 = gVar.f1987a.r();
        Objects.requireNonNull(r2);
        ContentInfo e2 = C0178c.e(r2);
        ContentInfo performReceiveContent = view.performReceiveContent(e2);
        if (performReceiveContent == null) {
            return null;
        }
        if (performReceiveContent == e2) {
            return gVar;
        }
        return new C0182g(new j(performReceiveContent));
    }

    public static void c(View view, String[] strArr, C0191p pVar) {
        if (pVar == null) {
            view.setOnReceiveContentListener(strArr, (OnReceiveContentListener) null);
        } else {
            view.setOnReceiveContentListener(strArr, new G(pVar));
        }
    }
}
