package y;

import android.view.View;
import android.view.WindowInsets;

public abstract class A {
    public static e0 a(View view) {
        WindowInsets rootWindowInsets = view.getRootWindowInsets();
        if (rootWindowInsets == null) {
            return null;
        }
        e0 c2 = e0.c(rootWindowInsets, (View) null);
        c0 c0Var = c2.f1986a;
        c0Var.p(c2);
        c0Var.d(view.getRootView());
        return c2;
    }

    public static int b(View view) {
        return view.getScrollIndicators();
    }

    public static void c(View view, int i2) {
        view.setScrollIndicators(i2);
    }

    public static void d(View view, int i2, int i3) {
        view.setScrollIndicators(i2, i3);
    }
}
