package y;

import android.view.DisplayCutout;
import android.view.View;
import android.view.WindowInsets;
import java.util.Objects;

public class Z extends Y {
    public Z(e0 e0Var, WindowInsets windowInsets) {
        super(e0Var, windowInsets);
    }

    public e0 a() {
        return e0.c(this.f1969c.consumeDisplayCutout(), (View) null);
    }

    public C0185j e() {
        DisplayCutout i2 = this.f1969c.getDisplayCutout();
        if (i2 == null) {
            return null;
        }
        return new C0185j(i2);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof Z)) {
            return false;
        }
        Z z2 = (Z) obj;
        if (!Objects.equals(this.f1969c, z2.f1969c) || !Objects.equals(this.f1972g, z2.f1972g)) {
            return false;
        }
        return true;
    }

    public int hashCode() {
        return this.f1969c.hashCode();
    }
}
