package y;

import android.view.View;
import androidx.core.widget.NestedScrollView;

/* renamed from: y.m  reason: case insensitive filesystem */
public interface C0188m {
    void a(View view, View view2, int i2, int i3);

    void b(View view, int i2);

    void d(NestedScrollView nestedScrollView, int i2, int i3, int i4, int i5, int i6);

    void e(int i2, int i3, int i4, int[] iArr);

    boolean f(View view, View view2, int i2, int i3);
}
