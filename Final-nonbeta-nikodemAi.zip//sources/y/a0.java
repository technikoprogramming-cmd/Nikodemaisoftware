package y;

import android.view.View;
import android.view.WindowInsets;
import r.C0158c;

public class a0 extends Z {

    /* renamed from: n  reason: collision with root package name */
    public C0158c f1975n = null;

    /* renamed from: o  reason: collision with root package name */
    public C0158c f1976o = null;

    /* renamed from: p  reason: collision with root package name */
    public C0158c f1977p = null;

    public a0(e0 e0Var, WindowInsets windowInsets) {
        super(e0Var, windowInsets);
    }

    public C0158c g() {
        if (this.f1976o == null) {
            this.f1976o = C0158c.b(this.f1969c.getMandatorySystemGestureInsets());
        }
        return this.f1976o;
    }

    public C0158c i() {
        if (this.f1975n == null) {
            this.f1975n = C0158c.b(this.f1969c.getSystemGestureInsets());
        }
        return this.f1975n;
    }

    public C0158c k() {
        if (this.f1977p == null) {
            this.f1977p = C0158c.b(this.f1969c.getTappableElementInsets());
        }
        return this.f1977p;
    }

    public e0 l(int i2, int i3, int i4, int i5) {
        return e0.c(this.f1969c.inset(i2, i3, i4, i5), (View) null);
    }

    public void q(C0158c cVar) {
    }
}
