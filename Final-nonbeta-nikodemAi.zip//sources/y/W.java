package y;

import r.C0158c;

public abstract class W {
    public W() {
        this(new e0());
    }

    public abstract e0 b();

    public abstract void c(C0158c cVar);

    public abstract void d(C0158c cVar);

    public W(e0 e0Var) {
    }

    public final void a() {
    }
}
