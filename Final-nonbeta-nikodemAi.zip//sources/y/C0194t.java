package y;

/* renamed from: y.t  reason: case insensitive filesystem */
public final class C0194t {

    /* renamed from: a  reason: collision with root package name */
    public final float[] f1996a = new float[20];
    public final long[] b = new long[20];

    /* renamed from: c  reason: collision with root package name */
    public float f1997c = 0.0f;

    /* renamed from: d  reason: collision with root package name */
    public int f1998d = 0;

    /* renamed from: e  reason: collision with root package name */
    public int f1999e = 0;
}
