package y;

import android.view.View;
import android.view.WindowInsets;
import r.C0158c;

public final class b0 extends a0 {

    /* renamed from: q  reason: collision with root package name */
    public static final e0 f1980q = e0.c(WindowInsets.CONSUMED, (View) null);

    public b0(e0 e0Var, WindowInsets windowInsets) {
        super(e0Var, windowInsets);
    }

    public C0158c f(int i2) {
        return C0158c.b(this.f1969c.getInsets(d0.a(i2)));
    }

    public final void d(View view) {
    }
}
