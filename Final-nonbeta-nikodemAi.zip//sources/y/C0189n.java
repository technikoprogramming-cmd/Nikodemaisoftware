package y;

import androidx.core.widget.NestedScrollView;

/* renamed from: y.n  reason: case insensitive filesystem */
public interface C0189n extends C0188m {
    void c(NestedScrollView nestedScrollView, int i2, int i3, int i4, int i5, int i6, int[] iArr);
}
