package u0;

import java.util.Comparator;
import t0.t;

public final class i implements Comparator {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ t f1881a;
    public final /* synthetic */ j b;

    public i(j jVar, t tVar) {
        this.b = jVar;
        this.f1881a = tVar;
    }

    public final int compare(Object obj, Object obj2) {
        t tVar = this.f1881a;
        j jVar = this.b;
        return Float.compare(jVar.a((t) obj2, tVar), jVar.a((t) obj, tVar));
    }
}
