package u0;

import B0.a;
import W.b;
import android.content.Context;
import android.hardware.Camera;
import android.os.Build;
import android.os.Handler;
import android.util.Log;
import i.C0108z;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import t0.t;

public final class f {

    /* renamed from: m  reason: collision with root package name */
    public static final /* synthetic */ int f1868m = 0;

    /* renamed from: a  reason: collision with root package name */
    public Camera f1869a;
    public Camera.CameraInfo b;

    /* renamed from: c  reason: collision with root package name */
    public b f1870c;

    /* renamed from: d  reason: collision with root package name */
    public b f1871d;

    /* renamed from: e  reason: collision with root package name */
    public boolean f1872e;
    public String f;

    /* renamed from: g  reason: collision with root package name */
    public g f1873g = new g();

    /* renamed from: h  reason: collision with root package name */
    public C0108z f1874h;

    /* renamed from: i  reason: collision with root package name */
    public t f1875i;

    /* renamed from: j  reason: collision with root package name */
    public t f1876j;

    /* renamed from: k  reason: collision with root package name */
    public int f1877k = -1;

    /* renamed from: l  reason: collision with root package name */
    public final e f1878l = new e(this);

    public f(Context context) {
    }

    public final int a() {
        int i2;
        int i3 = this.f1874h.f1492a;
        int i4 = 0;
        if (i3 != 0) {
            if (i3 == 1) {
                i4 = 90;
            } else if (i3 == 2) {
                i4 = 180;
            } else if (i3 == 3) {
                i4 = 270;
            }
        }
        Camera.CameraInfo cameraInfo = this.b;
        if (cameraInfo.facing == 1) {
            i2 = (360 - ((cameraInfo.orientation + i4) % 360)) % 360;
        } else {
            i2 = ((cameraInfo.orientation - i4) + 360) % 360;
        }
        Log.i("f", "Camera Display Orientation: " + i2);
        return i2;
    }

    public final void b() {
        if (this.f1869a != null) {
            try {
                int a2 = a();
                this.f1877k = a2;
                this.f1869a.setDisplayOrientation(a2);
            } catch (Exception unused) {
                Log.w("f", "Failed to set rotation.");
            }
            try {
                d(false);
            } catch (Exception unused2) {
                try {
                    d(true);
                } catch (Exception unused3) {
                    Log.w("f", "Camera rejected even safe-mode parameters! No configuration");
                }
            }
            Camera.Size previewSize = this.f1869a.getParameters().getPreviewSize();
            if (previewSize == null) {
                this.f1876j = this.f1875i;
            } else {
                this.f1876j = new t(previewSize.width, previewSize.height);
            }
            this.f1878l.b = this.f1876j;
            return;
        }
        throw new RuntimeException("Camera not open");
    }

    public final void c() {
        Camera camera;
        int o2 = a.o(this.f1873g.f1879a);
        if (o2 == -1) {
            camera = null;
        } else {
            camera = Camera.open(o2);
        }
        this.f1869a = camera;
        if (camera != null) {
            int o3 = a.o(this.f1873g.f1879a);
            Camera.CameraInfo cameraInfo = new Camera.CameraInfo();
            this.b = cameraInfo;
            Camera.getCameraInfo(o3, cameraInfo);
            return;
        }
        throw new RuntimeException("Failed to open camera");
    }

    public final void d(boolean z2) {
        String str;
        boolean z3;
        Camera.Parameters parameters = this.f1869a.getParameters();
        String str2 = this.f;
        if (str2 == null) {
            this.f = parameters.flatten();
        } else {
            parameters.unflatten(str2);
        }
        if (parameters == null) {
            Log.w("f", "Device error: no camera parameters are available. Proceeding without configuration.");
            return;
        }
        Log.i("f", "Initial camera parameters: " + parameters.flatten());
        if (z2) {
            Log.w("f", "In camera config safe mode -- most settings will not be honored");
        }
        this.f1873g.getClass();
        int i2 = X.a.f300a;
        List<String> supportedFocusModes = parameters.getSupportedFocusModes();
        String a2 = X.a.a("focus mode", supportedFocusModes, "auto");
        if (!z2 && a2 == null) {
            a2 = X.a.a("focus mode", supportedFocusModes, "macro", "edof");
        }
        if (a2 != null) {
            if (a2.equals(parameters.getFocusMode())) {
                Log.i("CameraConfiguration", "Focus mode already set to ".concat(a2));
            } else {
                parameters.setFocusMode(a2);
            }
        }
        if (!z2) {
            X.a.b(parameters, false);
            this.f1873g.getClass();
            this.f1873g.getClass();
            this.f1873g.getClass();
        }
        List<Camera.Size> supportedPreviewSizes = parameters.getSupportedPreviewSizes();
        ArrayList arrayList = new ArrayList();
        if (supportedPreviewSizes == null) {
            Camera.Size previewSize = parameters.getPreviewSize();
            if (previewSize != null) {
                arrayList.add(new t(previewSize.width, previewSize.height));
            }
        } else {
            for (Camera.Size next : supportedPreviewSizes) {
                arrayList.add(new t(next.width, next.height));
            }
        }
        int[] iArr = null;
        if (arrayList.size() == 0) {
            this.f1875i = null;
        } else {
            C0108z zVar = this.f1874h;
            int i3 = this.f1877k;
            if (i3 != -1) {
                if (i3 % 180 != 0) {
                    z3 = true;
                } else {
                    z3 = false;
                }
                t tVar = (t) zVar.b;
                if (tVar == null) {
                    tVar = null;
                } else if (z3) {
                    tVar = new t(tVar.b, tVar.f1839a);
                }
                j jVar = (j) zVar.f1493c;
                jVar.getClass();
                if (tVar != null) {
                    Collections.sort(arrayList, new i(jVar, tVar));
                }
                Log.i("j", "Viewfinder size: " + tVar);
                Log.i("j", "Preview in order of preference: " + arrayList);
                t tVar2 = (t) arrayList.get(0);
                this.f1875i = tVar2;
                parameters.setPreviewSize(tVar2.f1839a, tVar2.b);
            } else {
                throw new IllegalStateException("Rotation not calculated yet. Call configure() first.");
            }
        }
        if (Build.DEVICE.equals("glass-1")) {
            List<int[]> supportedPreviewFpsRange = parameters.getSupportedPreviewFpsRange();
            StringBuilder sb = new StringBuilder("Supported FPS ranges: ");
            if (supportedPreviewFpsRange == null || supportedPreviewFpsRange.isEmpty()) {
                str = "[]";
            } else {
                StringBuilder sb2 = new StringBuilder("[");
                Iterator<int[]> it = supportedPreviewFpsRange.iterator();
                while (it.hasNext()) {
                    sb2.append(Arrays.toString(it.next()));
                    if (it.hasNext()) {
                        sb2.append(", ");
                    }
                }
                sb2.append(']');
                str = sb2.toString();
            }
            sb.append(str);
            Log.i("CameraConfiguration", sb.toString());
            if (supportedPreviewFpsRange != null && !supportedPreviewFpsRange.isEmpty()) {
                Iterator<int[]> it2 = supportedPreviewFpsRange.iterator();
                while (true) {
                    if (!it2.hasNext()) {
                        break;
                    }
                    int[] next2 = it2.next();
                    int i4 = next2[0];
                    int i5 = next2[1];
                    if (i4 >= 10000 && i5 <= 20000) {
                        iArr = next2;
                        break;
                    }
                }
                if (iArr == null) {
                    Log.i("CameraConfiguration", "No suitable FPS range?");
                } else {
                    int[] iArr2 = new int[2];
                    parameters.getPreviewFpsRange(iArr2);
                    if (Arrays.equals(iArr2, iArr)) {
                        Log.i("CameraConfiguration", "FPS range already set to " + Arrays.toString(iArr));
                    } else {
                        Log.i("CameraConfiguration", "Setting FPS range to " + Arrays.toString(iArr));
                        parameters.setPreviewFpsRange(iArr[0], iArr[1]);
                    }
                }
            }
        }
        Log.i("f", "Final camera parameters: " + parameters.flatten());
        this.f1869a.setParameters(parameters);
    }

    public final void e(boolean z2) {
        boolean z3;
        String flashMode;
        Camera camera = this.f1869a;
        if (camera != null) {
            try {
                Camera.Parameters parameters = camera.getParameters();
                if (parameters == null || (flashMode = parameters.getFlashMode()) == null || (!"on".equals(flashMode) && !"torch".equals(flashMode))) {
                    z3 = false;
                } else {
                    z3 = true;
                }
                if (z2 != z3) {
                    b bVar = this.f1870c;
                    if (bVar != null) {
                        bVar.c();
                    }
                    Camera.Parameters parameters2 = this.f1869a.getParameters();
                    X.a.b(parameters2, z2);
                    this.f1873g.getClass();
                    this.f1869a.setParameters(parameters2);
                    b bVar2 = this.f1870c;
                    if (bVar2 != null) {
                        bVar2.f1850a = false;
                        bVar2.b();
                    }
                }
            } catch (RuntimeException e2) {
                Log.e("f", "Failed to set torch", e2);
            }
        }
    }

    /* JADX WARNING: type inference failed for: r0v3, types: [java.lang.Object, W.b] */
    public final void f() {
        Camera camera = this.f1869a;
        if (camera != null && !this.f1872e) {
            camera.startPreview();
            this.f1872e = true;
            this.f1870c = new b(this.f1869a, this.f1873g);
            g gVar = this.f1873g;
            ? obj = new Object();
            obj.f288a = this;
            obj.b = new Handler();
            this.f1871d = obj;
            gVar.getClass();
        }
    }
}
