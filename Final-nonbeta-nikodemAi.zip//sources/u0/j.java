package u0;

import android.graphics.Rect;
import t0.t;

public abstract class j {
    public abstract float a(t tVar, t tVar2);

    public abstract Rect b(t tVar, t tVar2);
}
