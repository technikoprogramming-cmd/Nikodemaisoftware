package u0;

import C.j;
import android.hardware.Camera;
import android.util.Log;
import ncs.nikodemai.ntabium.polskieoprogramowanie.R;
import t0.o;
import t0.t;
import t0.u;

public final class e implements Camera.PreviewCallback {

    /* renamed from: a  reason: collision with root package name */
    public j f1866a;
    public t b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ f f1867c;

    public e(f fVar) {
        this.f1867c = fVar;
    }

    public final void onPreviewFrame(byte[] bArr, Camera camera) {
        t tVar = this.b;
        j jVar = this.f1866a;
        if (tVar == null || jVar == null) {
            Log.d("f", "Got preview callback, but no handler or resolution available");
            if (jVar != null) {
                new Exception("No resolution available");
                jVar.z();
            }
        } else if (bArr != null) {
            try {
                byte[] bArr2 = bArr;
                u uVar = new u(bArr2, tVar.f1839a, tVar.b, camera.getParameters().getPreviewFormat(), this.f1867c.f1877k);
                synchronized (((o) jVar.b).f1834h) {
                    o oVar = (o) jVar.b;
                    if (oVar.f1833g) {
                        oVar.f1830c.obtainMessage(R.id.zxing_decode, uVar).sendToTarget();
                    }
                }
            } catch (RuntimeException e2) {
                Log.e("f", "Camera preview failed", e2);
                jVar.z();
            } catch (Throwable th) {
                throw th;
            }
        } else {
            throw new NullPointerException("No preview data received");
        }
    }
}
