package u0;

import G.a;
import android.graphics.SurfaceTexture;
import android.hardware.Camera;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.Log;
import android.view.SurfaceHolder;
import n0.e;
import ncs.nikodemai.ntabium.polskieoprogramowanie.R;
import t0.t;

public final class c implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f1854a;
    public final /* synthetic */ d b;

    public /* synthetic */ c(d dVar, int i2) {
        this.f1854a = i2;
        this.b = dVar;
    }

    public final void run() {
        boolean z2 = true;
        t tVar = null;
        switch (this.f1854a) {
            case 0:
                d dVar = this.b;
                try {
                    Log.d("d", "Opening camera");
                    dVar.f1857c.c();
                    return;
                } catch (Exception e2) {
                    Handler handler = dVar.f1858d;
                    if (handler != null) {
                        handler.obtainMessage(R.id.zxing_camera_error, e2).sendToTarget();
                    }
                    Log.e("d", "Failed to open camera", e2);
                    return;
                }
            case 1:
                d dVar2 = this.b;
                try {
                    Log.d("d", "Configuring camera");
                    dVar2.f1857c.b();
                    Handler handler2 = dVar2.f1858d;
                    if (handler2 != null) {
                        f fVar = dVar2.f1857c;
                        t tVar2 = fVar.f1876j;
                        if (tVar2 != null) {
                            int i2 = fVar.f1877k;
                            if (i2 != -1) {
                                if (i2 % 180 == 0) {
                                    z2 = false;
                                }
                                if (z2) {
                                    tVar = new t(tVar2.b, tVar2.f1839a);
                                } else {
                                    tVar = tVar2;
                                }
                            } else {
                                throw new IllegalStateException("Rotation not calculated yet. Call configure() first.");
                            }
                        }
                        handler2.obtainMessage(R.id.zxing_prewiew_size_ready, tVar).sendToTarget();
                        return;
                    }
                    return;
                } catch (Exception e3) {
                    Handler handler3 = dVar2.f1858d;
                    if (handler3 != null) {
                        handler3.obtainMessage(R.id.zxing_camera_error, e3).sendToTarget();
                    }
                    Log.e("d", "Failed to configure camera", e3);
                    return;
                }
            case 2:
                d dVar3 = this.b;
                try {
                    Log.d("d", "Starting preview");
                    f fVar2 = dVar3.f1857c;
                    a aVar = dVar3.b;
                    Camera camera = fVar2.f1869a;
                    SurfaceHolder surfaceHolder = (SurfaceHolder) aVar.b;
                    if (surfaceHolder != null) {
                        camera.setPreviewDisplay(surfaceHolder);
                    } else {
                        camera.setPreviewTexture((SurfaceTexture) aVar.f59c);
                    }
                    dVar3.f1857c.f();
                    return;
                } catch (Exception e4) {
                    Handler handler4 = dVar3.f1858d;
                    if (handler4 != null) {
                        handler4.obtainMessage(R.id.zxing_camera_error, e4).sendToTarget();
                    }
                    Log.e("d", "Failed to start preview", e4);
                    return;
                }
            default:
                try {
                    Log.d("d", "Closing camera");
                    f fVar3 = this.b.f1857c;
                    b bVar = fVar3.f1870c;
                    if (bVar != null) {
                        bVar.c();
                        fVar3.f1870c = null;
                    }
                    if (fVar3.f1871d != null) {
                        fVar3.f1871d = null;
                    }
                    Camera camera2 = fVar3.f1869a;
                    if (camera2 != null && fVar3.f1872e) {
                        camera2.stopPreview();
                        fVar3.f1878l.f1866a = null;
                        fVar3.f1872e = false;
                    }
                    f fVar4 = this.b.f1857c;
                    Camera camera3 = fVar4.f1869a;
                    if (camera3 != null) {
                        camera3.release();
                        fVar4.f1869a = null;
                    }
                } catch (Exception e5) {
                    Log.e("d", "Failed to close camera", e5);
                }
                d dVar4 = this.b;
                dVar4.f1860g = true;
                dVar4.f1858d.sendEmptyMessage(R.id.zxing_camera_closed);
                e eVar = this.b.f1856a;
                synchronized (eVar.f1659e) {
                    int i3 = eVar.b - 1;
                    eVar.b = i3;
                    if (i3 == 0) {
                        synchronized (eVar.f1659e) {
                            ((HandlerThread) eVar.f1658d).quit();
                            eVar.f1658d = null;
                            eVar.f1657c = null;
                        }
                    }
                }
                return;
        }
    }
}
