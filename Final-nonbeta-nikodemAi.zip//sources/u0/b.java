package u0;

import android.hardware.Camera;
import android.os.Handler;
import android.util.Log;
import java.util.ArrayList;
import t0.n;

public final class b {

    /* renamed from: g  reason: collision with root package name */
    public static final ArrayList f1849g;

    /* renamed from: a  reason: collision with root package name */
    public boolean f1850a;
    public boolean b;

    /* renamed from: c  reason: collision with root package name */
    public final boolean f1851c;

    /* renamed from: d  reason: collision with root package name */
    public final Camera f1852d;

    /* renamed from: e  reason: collision with root package name */
    public final Handler f1853e;
    public final a f = new a(this);

    static {
        ArrayList arrayList = new ArrayList(2);
        f1849g = arrayList;
        arrayList.add("auto");
        arrayList.add("macro");
    }

    public b(Camera camera, g gVar) {
        n nVar = new n(1, this);
        this.f1853e = new Handler(nVar);
        this.f1852d = camera;
        String focusMode = camera.getParameters().getFocusMode();
        gVar.getClass();
        boolean contains = f1849g.contains(focusMode);
        this.f1851c = contains;
        Log.i("b", "Current focus mode '" + focusMode + "'; use auto focus? " + contains);
        this.f1850a = false;
        b();
    }

    public final synchronized void a() {
        if (!this.f1850a && !this.f1853e.hasMessages(1)) {
            Handler handler = this.f1853e;
            handler.sendMessageDelayed(handler.obtainMessage(1), 2000);
        }
    }

    public final void b() {
        if (this.f1851c && !this.f1850a && !this.b) {
            try {
                this.f1852d.autoFocus(this.f);
                this.b = true;
            } catch (RuntimeException e2) {
                Log.w("b", "Unexpected exception while focusing", e2);
                a();
            }
        }
    }

    public final void c() {
        this.f1850a = true;
        this.b = false;
        this.f1853e.removeMessages(1);
        if (this.f1851c) {
            try {
                this.f1852d.cancelAutoFocus();
            } catch (RuntimeException e2) {
                Log.w("b", "Unexpected exception while cancelling focusing", e2);
            }
        }
    }
}
