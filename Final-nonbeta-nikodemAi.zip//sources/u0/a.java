package u0;

import D.b;
import android.hardware.Camera;

public final class a implements Camera.AutoFocusCallback {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ b f1848a;

    public a(b bVar) {
        this.f1848a = bVar;
    }

    public final void onAutoFocus(boolean z2, Camera camera) {
        this.f1848a.f1853e.post(new b(9, (Object) this));
    }
}
