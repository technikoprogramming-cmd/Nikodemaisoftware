package u0;

import android.graphics.Rect;
import android.util.Log;
import t0.t;

public final class h extends j {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f1880a;

    public /* synthetic */ h(int i2) {
        this.f1880a = i2;
    }

    public final float a(t tVar, t tVar2) {
        int i2;
        switch (this.f1880a) {
            case 0:
                if (tVar.f1839a <= 0 || tVar.b <= 0) {
                    return 0.0f;
                }
                t a2 = tVar.a(tVar2);
                float f = ((float) a2.f1839a) * 1.0f;
                float f2 = f / ((float) tVar.f1839a);
                if (f2 > 1.0f) {
                    f2 = (float) Math.pow((double) (1.0f / f2), 1.1d);
                }
                float f3 = ((((float) a2.b) * 1.0f) / ((float) tVar2.b)) + (f / ((float) tVar2.f1839a));
                return ((1.0f / f3) / f3) * f2;
            case 1:
                if (tVar.f1839a <= 0 || tVar.b <= 0) {
                    return 0.0f;
                }
                t b = tVar.b(tVar2);
                float f4 = (float) b.f1839a;
                float f5 = (f4 * 1.0f) / ((float) tVar.f1839a);
                if (f5 > 1.0f) {
                    f5 = (float) Math.pow((double) (1.0f / f5), 1.1d);
                }
                float f6 = ((((float) tVar2.b) * 1.0f) / ((float) b.b)) * ((((float) tVar2.f1839a) * 1.0f) / f4);
                return (((1.0f / f6) / f6) / f6) * f5;
            default:
                int i3 = tVar.f1839a;
                if (i3 <= 0 || (i2 = tVar.b) <= 0) {
                    return 0.0f;
                }
                int i4 = tVar2.f1839a;
                float f7 = (((float) i3) * 1.0f) / ((float) i4);
                if (f7 < 1.0f) {
                    f7 = 1.0f / f7;
                }
                float f8 = (float) i2;
                float f9 = (float) tVar2.b;
                float f10 = (f8 * 1.0f) / f9;
                if (f10 < 1.0f) {
                    f10 = 1.0f / f10;
                }
                float f11 = (1.0f / f7) / f10;
                float f12 = ((((float) i3) * 1.0f) / f8) / ((((float) i4) * 1.0f) / f9);
                if (f12 < 1.0f) {
                    f12 = 1.0f / f12;
                }
                return (((1.0f / f12) / f12) / f12) * f11;
        }
    }

    public final Rect b(t tVar, t tVar2) {
        switch (this.f1880a) {
            case 0:
                t a2 = tVar.a(tVar2);
                Log.i("h", "Preview: " + tVar + "; Scaled: " + a2 + "; Want: " + tVar2);
                int i2 = tVar2.f1839a;
                int i3 = a2.f1839a;
                int i4 = (i3 - i2) / 2;
                int i5 = tVar2.b;
                int i6 = a2.b;
                int i7 = (i6 - i5) / 2;
                return new Rect(-i4, -i7, i3 - i4, i6 - i7);
            case 1:
                t b = tVar.b(tVar2);
                Log.i("h", "Preview: " + tVar + "; Scaled: " + b + "; Want: " + tVar2);
                int i8 = tVar2.f1839a;
                int i9 = b.f1839a;
                int i10 = (i9 - i8) / 2;
                int i11 = tVar2.b;
                int i12 = b.b;
                int i13 = (i12 - i11) / 2;
                return new Rect(-i10, -i13, i9 - i10, i12 - i13);
            default:
                return new Rect(0, 0, tVar2.f1839a, tVar2.b);
        }
    }
}
