package u0;

public final class g {

    /* renamed from: a  reason: collision with root package name */
    public int f1879a = -1;
}
