package a0;

import B0.a;
import S.h;
import S.n;
import Z.b;

/* renamed from: a0.a  reason: case insensitive filesystem */
public final class C0001a {

    /* renamed from: a  reason: collision with root package name */
    public final b f329a;
    public final int b;

    /* renamed from: c  reason: collision with root package name */
    public final int f330c;

    /* renamed from: d  reason: collision with root package name */
    public final int f331d;

    /* renamed from: e  reason: collision with root package name */
    public final int f332e;
    public final int f;

    /* renamed from: g  reason: collision with root package name */
    public final int f333g;

    public C0001a(b bVar, int i2, int i3, int i4) {
        this.f329a = bVar;
        int i5 = bVar.b;
        this.b = i5;
        int i6 = bVar.f302a;
        this.f330c = i6;
        int i7 = i2 / 2;
        int i8 = i3 - i7;
        this.f331d = i8;
        int i9 = i3 + i7;
        this.f332e = i9;
        int i10 = i4 - i7;
        this.f333g = i10;
        int i11 = i4 + i7;
        this.f = i11;
        if (i10 < 0 || i8 < 0 || i11 >= i5 || i9 >= i6) {
            throw h.f252c;
        }
    }

    public final boolean a(int i2, int i3, int i4, boolean z2) {
        b bVar = this.f329a;
        if (z2) {
            while (i2 <= i3) {
                if (bVar.b(i2, i4)) {
                    return true;
                }
                i2++;
            }
            return false;
        }
        while (i2 <= i3) {
            if (bVar.b(i4, i2)) {
                return true;
            }
            i2++;
        }
        return false;
    }

    public final n[] b() {
        int i2;
        int i3;
        int i4 = this.f331d;
        int i5 = this.f332e;
        int i6 = this.f333g;
        int i7 = this.f;
        boolean z2 = false;
        int i8 = 1;
        boolean z3 = false;
        boolean z4 = false;
        boolean z5 = false;
        boolean z6 = false;
        boolean z7 = false;
        boolean z8 = true;
        while (true) {
            i2 = this.f330c;
            if (!z8) {
                break;
            }
            boolean z9 = false;
            boolean z10 = true;
            while (true) {
                if ((z10 || !z3) && i5 < i2) {
                    z10 = a(i6, i7, i5, false);
                    if (z10) {
                        i5++;
                        z3 = true;
                        z9 = true;
                    } else if (!z3) {
                        i5++;
                    }
                }
            }
            if (i5 >= i2) {
                break;
            }
            boolean z11 = true;
            while (true) {
                i3 = this.b;
                if ((z11 || !z4) && i7 < i3) {
                    z11 = a(i4, i5, i7, true);
                    if (z11) {
                        i7++;
                        z4 = true;
                        z9 = true;
                    } else if (!z4) {
                        i7++;
                    }
                }
            }
            if (i7 >= i3) {
                break;
            }
            boolean z12 = true;
            while (true) {
                if ((z12 || !z5) && i4 >= 0) {
                    z12 = a(i6, i7, i4, false);
                    if (z12) {
                        i4--;
                        z5 = true;
                        z9 = true;
                    } else if (!z5) {
                        i4--;
                    }
                }
            }
            if (i4 < 0) {
                break;
            }
            z8 = z9;
            boolean z13 = true;
            while (true) {
                if ((z13 || !z7) && i6 >= 0) {
                    z13 = a(i4, i5, i6, true);
                    if (z13) {
                        i6--;
                        z8 = true;
                        z7 = true;
                    } else if (!z7) {
                        i6--;
                    }
                }
            }
            if (i6 < 0) {
                break;
            } else if (z8) {
                z6 = true;
            }
        }
        z2 = true;
        if (z2 || !z6) {
            throw h.f252c;
        }
        int i9 = i5 - i4;
        n nVar = null;
        int i10 = 1;
        n nVar2 = null;
        while (nVar2 == null && i10 < i9) {
            nVar2 = c((float) i4, (float) (i7 - i10), (float) (i4 + i10), (float) i7);
            i10++;
        }
        if (nVar2 != null) {
            int i11 = 1;
            n nVar3 = null;
            while (nVar3 == null && i11 < i9) {
                nVar3 = c((float) i4, (float) (i6 + i11), (float) (i4 + i11), (float) i6);
                i11++;
            }
            if (nVar3 != null) {
                int i12 = 1;
                n nVar4 = null;
                while (nVar4 == null && i12 < i9) {
                    nVar4 = c((float) i5, (float) (i6 + i12), (float) (i5 - i12), (float) i6);
                    i12++;
                }
                if (nVar4 != null) {
                    while (nVar == null && i8 < i9) {
                        nVar = c((float) i5, (float) (i7 - i8), (float) (i5 - i8), (float) i7);
                        i8++;
                    }
                    if (nVar != null) {
                        float f2 = nVar.f271a;
                        int i13 = (f2 > (((float) i2) / 2.0f) ? 1 : (f2 == (((float) i2) / 2.0f) ? 0 : -1));
                        float f3 = nVar2.f271a;
                        float f4 = nVar4.f271a;
                        float f5 = nVar3.f271a;
                        float f6 = nVar.b;
                        float f7 = nVar2.b;
                        float f8 = nVar4.b;
                        float f9 = nVar3.b;
                        if (i13 < 0) {
                            return new n[]{new n(f5 - 1.0f, f9 + 1.0f), new n(f3 + 1.0f, f7 + 1.0f), new n(f4 - 1.0f, f8 - 1.0f), new n(f2 + 1.0f, f6 - 1.0f)};
                        }
                        return new n[]{new n(f5 + 1.0f, f9 + 1.0f), new n(f3 + 1.0f, f7 - 1.0f), new n(f4 - 1.0f, f8 + 1.0f), new n(f2 - 1.0f, f6 - 1.0f)};
                    }
                    throw h.f252c;
                }
                throw h.f252c;
            }
            throw h.f252c;
        }
        throw h.f252c;
    }

    public final n c(float f2, float f3, float f4, float f5) {
        float f6 = f2 - f4;
        float f7 = f3 - f5;
        int N2 = a.N((float) Math.sqrt((double) ((f7 * f7) + (f6 * f6))));
        float f8 = (float) N2;
        float f9 = (f4 - f2) / f8;
        float f10 = (f5 - f3) / f8;
        for (int i2 = 0; i2 < N2; i2++) {
            float f11 = (float) i2;
            int N3 = a.N((f11 * f9) + f2);
            int N4 = a.N((f11 * f10) + f3);
            if (this.f329a.b(N3, N4)) {
                return new n((float) N3, (float) N4);
            }
        }
        return null;
    }

    public C0001a(b bVar) {
        this(bVar, 10, bVar.f302a / 2, bVar.b / 2);
    }
}
