package g;

import android.view.View;
import android.view.animation.BaseInterpolator;
import java.util.ArrayList;
import x.b;
import y.P;

/* renamed from: g.j  reason: case insensitive filesystem */
public final class C0044j {

    /* renamed from: a  reason: collision with root package name */
    public final ArrayList f1076a = new ArrayList();
    public long b = -1;

    /* renamed from: c  reason: collision with root package name */
    public BaseInterpolator f1077c;

    /* renamed from: d  reason: collision with root package name */
    public b f1078d;

    /* renamed from: e  reason: collision with root package name */
    public boolean f1079e;
    public final C0043i f = new C0043i(this);

    public final void a() {
        if (this.f1079e) {
            ArrayList arrayList = this.f1076a;
            int size = arrayList.size();
            int i2 = 0;
            while (i2 < size) {
                Object obj = arrayList.get(i2);
                i2++;
                ((P) obj).b();
            }
            this.f1079e = false;
        }
    }

    public final void b() {
        View view;
        if (!this.f1079e) {
            ArrayList arrayList = this.f1076a;
            int size = arrayList.size();
            int i2 = 0;
            while (i2 < size) {
                Object obj = arrayList.get(i2);
                i2++;
                P p2 = (P) obj;
                long j2 = this.b;
                if (j2 >= 0) {
                    p2.c(j2);
                }
                BaseInterpolator baseInterpolator = this.f1077c;
                if (!(baseInterpolator == null || (view = (View) p2.f1955a.get()) == null)) {
                    view.animate().setInterpolator(baseInterpolator);
                }
                if (this.f1078d != null) {
                    p2.d(this.f);
                }
                View view2 = (View) p2.f1955a.get();
                if (view2 != null) {
                    view2.animate().start();
                }
            }
            this.f1079e = true;
        }
    }
}
