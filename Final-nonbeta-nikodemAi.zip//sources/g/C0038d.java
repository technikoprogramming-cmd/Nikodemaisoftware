package g;

import G.a;
import Q.t;
import android.content.Context;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import androidx.appcompat.widget.ActionBarContextView;
import h.l;
import h.n;
import i.C0081l;
import java.lang.ref.WeakReference;

/* renamed from: g.d  reason: case insensitive filesystem */
public final class C0038d extends C0035a implements l {

    /* renamed from: c  reason: collision with root package name */
    public Context f1032c;

    /* renamed from: d  reason: collision with root package name */
    public ActionBarContextView f1033d;

    /* renamed from: e  reason: collision with root package name */
    public a f1034e;
    public WeakReference f;

    /* renamed from: g  reason: collision with root package name */
    public boolean f1035g;

    /* renamed from: h  reason: collision with root package name */
    public n f1036h;

    public final void a() {
        if (!this.f1035g) {
            this.f1035g = true;
            this.f1034e.y(this);
        }
    }

    public final View b() {
        WeakReference weakReference = this.f;
        if (weakReference != null) {
            return (View) weakReference.get();
        }
        return null;
    }

    public final n c() {
        return this.f1036h;
    }

    public final MenuInflater d() {
        return new C0042h(this.f1033d.getContext());
    }

    public final CharSequence e() {
        return this.f1033d.getSubtitle();
    }

    public final CharSequence f() {
        return this.f1033d.getTitle();
    }

    public final void g(n nVar) {
        i();
        C0081l lVar = this.f1033d.f428d;
        if (lVar != null) {
            lVar.l();
        }
    }

    public final boolean h(n nVar, MenuItem menuItem) {
        return ((t) this.f1034e.b).c(this, menuItem);
    }

    public final void i() {
        this.f1034e.A(this, this.f1036h);
    }

    public final boolean j() {
        return this.f1033d.f442s;
    }

    public final void k(View view) {
        WeakReference weakReference;
        this.f1033d.setCustomView(view);
        if (view != null) {
            weakReference = new WeakReference(view);
        } else {
            weakReference = null;
        }
        this.f = weakReference;
    }

    public final void l(int i2) {
        m(this.f1032c.getString(i2));
    }

    public final void m(CharSequence charSequence) {
        this.f1033d.setSubtitle(charSequence);
    }

    public final void n(int i2) {
        o(this.f1032c.getString(i2));
    }

    public final void o(CharSequence charSequence) {
        this.f1033d.setTitle(charSequence);
    }

    public final void p(boolean z2) {
        this.b = z2;
        this.f1033d.setTitleOptional(z2);
    }
}
