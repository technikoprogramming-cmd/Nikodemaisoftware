package g;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.os.Build;
import android.util.Log;
import android.view.InflateException;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import h.p;
import h.q;
import h.u;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import t.C0169a;
import y.C0187l;

/* renamed from: g.g  reason: case insensitive filesystem */
public final class C0041g {

    /* renamed from: A  reason: collision with root package name */
    public CharSequence f1040A;

    /* renamed from: B  reason: collision with root package name */
    public CharSequence f1041B;

    /* renamed from: C  reason: collision with root package name */
    public ColorStateList f1042C = null;

    /* renamed from: D  reason: collision with root package name */
    public PorterDuff.Mode f1043D = null;

    /* renamed from: E  reason: collision with root package name */
    public final /* synthetic */ C0042h f1044E;

    /* renamed from: a  reason: collision with root package name */
    public final Menu f1045a;
    public int b;

    /* renamed from: c  reason: collision with root package name */
    public int f1046c;

    /* renamed from: d  reason: collision with root package name */
    public int f1047d;

    /* renamed from: e  reason: collision with root package name */
    public int f1048e;
    public boolean f;

    /* renamed from: g  reason: collision with root package name */
    public boolean f1049g;

    /* renamed from: h  reason: collision with root package name */
    public boolean f1050h;

    /* renamed from: i  reason: collision with root package name */
    public int f1051i;

    /* renamed from: j  reason: collision with root package name */
    public int f1052j;

    /* renamed from: k  reason: collision with root package name */
    public CharSequence f1053k;

    /* renamed from: l  reason: collision with root package name */
    public CharSequence f1054l;

    /* renamed from: m  reason: collision with root package name */
    public int f1055m;

    /* renamed from: n  reason: collision with root package name */
    public char f1056n;

    /* renamed from: o  reason: collision with root package name */
    public int f1057o;

    /* renamed from: p  reason: collision with root package name */
    public char f1058p;

    /* renamed from: q  reason: collision with root package name */
    public int f1059q;

    /* renamed from: r  reason: collision with root package name */
    public int f1060r;

    /* renamed from: s  reason: collision with root package name */
    public boolean f1061s;

    /* renamed from: t  reason: collision with root package name */
    public boolean f1062t;

    /* renamed from: u  reason: collision with root package name */
    public boolean f1063u;

    /* renamed from: v  reason: collision with root package name */
    public int f1064v;

    /* renamed from: w  reason: collision with root package name */
    public int f1065w;

    /* renamed from: x  reason: collision with root package name */
    public String f1066x;

    /* renamed from: y  reason: collision with root package name */
    public String f1067y;

    /* renamed from: z  reason: collision with root package name */
    public q f1068z;

    public C0041g(C0042h hVar, Menu menu) {
        this.f1044E = hVar;
        this.f1045a = menu;
        this.b = 0;
        this.f1046c = 0;
        this.f1047d = 0;
        this.f1048e = 0;
        this.f = true;
        this.f1049g = true;
    }

    public final Object a(String str, Class[] clsArr, Object[] objArr) {
        try {
            Constructor<?> constructor = Class.forName(str, false, this.f1044E.f1071c.getClassLoader()).getConstructor(clsArr);
            constructor.setAccessible(true);
            return constructor.newInstance(objArr);
        } catch (Exception e2) {
            Log.w("SupportMenuInflater", "Cannot instantiate class: " + str, e2);
            return null;
        }
    }

    /* JADX WARNING: type inference failed for: r0v33, types: [android.view.MenuItem$OnMenuItemClickListener, java.lang.Object, g.f] */
    public final void b(MenuItem menuItem) {
        boolean z2;
        MenuItem enabled = menuItem.setChecked(this.f1061s).setVisible(this.f1062t).setEnabled(this.f1063u);
        boolean z3 = false;
        if (this.f1060r >= 1) {
            z2 = true;
        } else {
            z2 = false;
        }
        enabled.setCheckable(z2).setTitleCondensed(this.f1054l).setIcon(this.f1055m);
        int i2 = this.f1064v;
        if (i2 >= 0) {
            menuItem.setShowAsAction(i2);
        }
        String str = this.f1067y;
        C0042h hVar = this.f1044E;
        if (str != null) {
            if (!hVar.f1071c.isRestricted()) {
                if (hVar.f1072d == null) {
                    hVar.f1072d = C0042h.a(hVar.f1071c);
                }
                Object obj = hVar.f1072d;
                String str2 = this.f1067y;
                ? obj2 = new Object();
                obj2.f1039a = obj;
                Class<?> cls = obj.getClass();
                try {
                    obj2.b = cls.getMethod(str2, C0040f.f1038c);
                    menuItem.setOnMenuItemClickListener(obj2);
                } catch (Exception e2) {
                    InflateException inflateException = new InflateException("Couldn't resolve menu item onClick handler " + str2 + " in class " + cls.getName());
                    inflateException.initCause(e2);
                    throw inflateException;
                }
            } else {
                throw new IllegalStateException("The android:onClick attribute cannot be used within a restricted context");
            }
        }
        if (this.f1060r >= 2) {
            if (menuItem instanceof p) {
                p pVar = (p) menuItem;
                pVar.f1205x = (pVar.f1205x & -5) | 4;
            } else if (menuItem instanceof u) {
                u uVar = (u) menuItem;
                try {
                    Method method = uVar.f1214d;
                    C0169a aVar = uVar.f1213c;
                    if (method == null) {
                        uVar.f1214d = aVar.getClass().getDeclaredMethod("setExclusiveCheckable", new Class[]{Boolean.TYPE});
                    }
                    uVar.f1214d.invoke(aVar, new Object[]{Boolean.TRUE});
                } catch (Exception e3) {
                    Log.w("MenuItemWrapper", "Error while calling setExclusiveCheckable", e3);
                }
            }
        }
        String str3 = this.f1066x;
        if (str3 != null) {
            menuItem.setActionView((View) a(str3, C0042h.f1069e, hVar.f1070a));
            z3 = true;
        }
        int i3 = this.f1065w;
        if (i3 > 0) {
            if (!z3) {
                menuItem.setActionView(i3);
            } else {
                Log.w("SupportMenuInflater", "Ignoring attribute 'itemActionViewLayout'. Action view already specified.");
            }
        }
        q qVar = this.f1068z;
        if (qVar != null) {
            if (menuItem instanceof C0169a) {
                ((C0169a) menuItem).b(qVar);
            } else {
                Log.w("MenuItemCompat", "setActionProvider: item does not implement SupportMenuItem; ignoring");
            }
        }
        CharSequence charSequence = this.f1040A;
        boolean z4 = menuItem instanceof C0169a;
        if (z4) {
            ((C0169a) menuItem).setContentDescription(charSequence);
        } else if (Build.VERSION.SDK_INT >= 26) {
            C0187l.h(menuItem, charSequence);
        }
        CharSequence charSequence2 = this.f1041B;
        if (z4) {
            ((C0169a) menuItem).setTooltipText(charSequence2);
        } else if (Build.VERSION.SDK_INT >= 26) {
            C0187l.m(menuItem, charSequence2);
        }
        char c2 = this.f1056n;
        int i4 = this.f1057o;
        if (z4) {
            ((C0169a) menuItem).setAlphabeticShortcut(c2, i4);
        } else if (Build.VERSION.SDK_INT >= 26) {
            C0187l.g(menuItem, c2, i4);
        }
        char c3 = this.f1058p;
        int i5 = this.f1059q;
        if (z4) {
            ((C0169a) menuItem).setNumericShortcut(c3, i5);
        } else if (Build.VERSION.SDK_INT >= 26) {
            C0187l.k(menuItem, c3, i5);
        }
        PorterDuff.Mode mode = this.f1043D;
        if (mode != null) {
            if (z4) {
                ((C0169a) menuItem).setIconTintMode(mode);
            } else if (Build.VERSION.SDK_INT >= 26) {
                C0187l.j(menuItem, mode);
            }
        }
        ColorStateList colorStateList = this.f1042C;
        if (colorStateList == null) {
            return;
        }
        if (z4) {
            ((C0169a) menuItem).setIconTintList(colorStateList);
        } else if (Build.VERSION.SDK_INT >= 26) {
            C0187l.i(menuItem, colorStateList);
        }
    }
}
