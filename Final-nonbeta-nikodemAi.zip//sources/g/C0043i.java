package g;

import i.d1;
import x.b;

/* renamed from: g.i  reason: case insensitive filesystem */
public final class C0043i extends b {

    /* renamed from: e  reason: collision with root package name */
    public final /* synthetic */ int f1073e = 0;
    public boolean f;

    /* renamed from: g  reason: collision with root package name */
    public int f1074g;

    /* renamed from: h  reason: collision with root package name */
    public final /* synthetic */ Object f1075h;

    public C0043i(C0044j jVar) {
        this.f1075h = jVar;
        this.f = false;
        this.f1074g = 0;
    }

    public final void a() {
        switch (this.f1073e) {
            case 0:
                int i2 = this.f1074g + 1;
                this.f1074g = i2;
                C0044j jVar = (C0044j) this.f1075h;
                if (i2 == jVar.f1076a.size()) {
                    b bVar = jVar.f1078d;
                    if (bVar != null) {
                        bVar.a();
                    }
                    this.f1074g = 0;
                    this.f = false;
                    jVar.f1079e = false;
                    return;
                }
                return;
            default:
                if (!this.f) {
                    ((d1) this.f1075h).f1354a.setVisibility(this.f1074g);
                    return;
                }
                return;
        }
    }

    public void b() {
        switch (this.f1073e) {
            case 1:
                this.f = true;
                return;
            default:
                return;
        }
    }

    public final void c() {
        switch (this.f1073e) {
            case 0:
                if (!this.f) {
                    this.f = true;
                    b bVar = ((C0044j) this.f1075h).f1078d;
                    if (bVar != null) {
                        bVar.c();
                        return;
                    }
                    return;
                }
                return;
            default:
                ((d1) this.f1075h).f1354a.setVisibility(0);
                return;
        }
    }

    public C0043i(d1 d1Var, int i2) {
        this.f1075h = d1Var;
        this.f1074g = i2;
        this.f = false;
    }
}
