package g;

/* renamed from: g.b  reason: case insensitive filesystem */
public interface C0036b {
}
